﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.Member.Domain
{
    public partial class MemberDetail
    {
        public PlanInfo PlanInfo { get; set; }
        public MemberInfo MemberInfo { get; set; }
        public POAInfo? POAInfo { get; set; }
        public bool IsAor { get; set; }
        public bool IsPOA { get; set; }
        public DateTime CreatedDate { get; set; }
        public long? LastModifiedBy { get; set; }
        public DateTime? LastModifiedDate { get; set; }
        public AorInfo? AorInfo { get; set; }
        public long CustomerId { get; set; }
        public long CreatedBy { get; set; }
    }

    public partial class AorInfo
    {
        public string? AorFirstName { get; set; }
        public string? AorMiddleName { get; set; }
        public string? AorLastName { get; set; }
        public string? AorEmail { get; set; }
        public DateTime? MemberSignatureDate { get; set; }
        public DateTime? ApointeeSignatureDate { get; set; }
        public string? AorCity { get; set; }
        public string? AorAddressLine1 { get; set; }
        public string? AorAddressLine2 { get; set; }
        public long? AorPhone { get; set; }
        public string? AorZip { get; set; }
        public string? AorState { get; set; }
        public string? AorRelationship { get; set; }
        public bool? formReceived { get; set; }
        public DateTime? AorFormReceivedDate { get; set; }
        public string? AorFormReceivedTime { get; set; }
        public int? RepresentativeTypeId { get; set; }
        public string? AorGroupName { get; set; }
    }

    public partial class MemberInfo
    {
        public string FirstName { get; set; }
        public string? MiddleName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string AddressLine1 { get; set; }
        public string? AddressLine2 { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string? Zip { get; set; }
        public string? HomePhone { get; set; }
        public string? WorkPhone { get; set; }
        public string? Fax { get; set; }
        public string? CellPhone { get; set; }
        public string? CommunicationPrefrence { get; set; }
        public string? Email { get; set; }
        public string? LanguagePrefrence { get; set; }
    }

    public partial class PlanInfo
    {
        public string? AltMemberId { get; set; }
        public string? MemberNumber { get; set; }
        public string Mbi { get; set; }
        public string? RelationCode { get; set; }
        public string? CardHolder { get; set; }
        public string? PersonNumber { get; set; }
        public string? GroupNumber { get; set; }
        public DateTime EligibilityEndDate { get; set; }
        public DateTime EligibilityEffectiveDate { get; set; }
        public string CardHolderContractNumber { get; set; }
        public string CmsContractNumber { get; set; }
        //public string Client { get; set; }
        //	public string PlanName { get; set; }
        public int ClientId { get; set; }
        public int PlanId { get; set; }
    }

    public partial class POAInfo
    {
        public string? POAFirstName { get; set; }
        public string? POAMiddleName { get; set; }
        public string? POALastName { get; set; }
        public int? POARelationship { get; set; }
        public string? POAAddrLine1 { get; set; }
        public string? POAAddrLine2 { get; set; }
        public string? POAState { get; set; }
        public string? POACity { get; set; }
        public string? POAZip { get; set; }
        public string? POACountry { get; set; }
        public string? POAEmail { get; set; }
        public string? POAPhone { get; set; }
        public DateTime? POAFormReceivedDate { get; set; }
        public DateTime? POAEffectiveDate { get; set; }
        public DateTime? POATerminationDate { get; set; }
        public bool? POAFormReceived { get; set; }
        public DateTime? POACreatedDate { get; set; }
        public string? POACreatedBy { get; set; }
        public DateTime? POALastModified { get; set; }
        public string? POALastModifiedBy { get; set; }
       

    }
}
