﻿using Aspose.Pdf.Operators;
using GrievanceData.Case.Domain;
using GrievanceData.Common.Infrastructure.Service;
using GrievanceData.Common.Infrastructure.Settings;
using GrievanceData.GrievanceDbContext;
using GrievanceData.Member.Domain;
using GrievanceData.Member.Infrastructure.Interfaces;
using GrievanceData.Member.Infrastructure.Repositories;
using GrievanceData.Member.Infrastructure.Settings;
using GrievanceData.User.Domain;
using Newtonsoft.Json.Linq;

namespace GrievanceData.Member.Services
{
    public class MemberService : IMemberService
    {
        private readonly IMemberUnitOfWork uow;
        private readonly ICommonService _cservice;
        private readonly MemberSettings _membersettings;

        public MemberService(GrievancesContext context, CommonSettings commonsettings, MemberSettings membersettings, ICommonService cservice)
        {
            if (uow == null)
                uow = uow ?? new MemberUnitOfWork(new MemberUnitOfWorkSettings
                {
                    membersettings = membersettings,
                    commonsettings = commonsettings,
                    commonservice = cservice
                });

            _cservice = cservice;                          
            _membersettings = membersettings;
        }
        
        public async Task<string> SearchMemberEligibility()
        {
            string resp = await uow.MemberSqlRepo.SearchMemberEligibility();
            return resp;
        }

		public async Task<List<usp_GetEligibilityMemberDataResult>> GetEligibilityMemberData(string? mbi, string? memberNumber, DateTime? dob, string? firstName, string? lastName, long userId)
		{
			return await uow.MemberSqlRepo.GetEligibilityMemberData(mbi, memberNumber, dob, firstName, lastName, userId);

		}

		public async Task<int> CreateMember(MemberDetail req) {
            return await uow.MemberSqlRepo.CreateMember(req);
        }

        public async Task<CaseDetailDto> GetEligibilityMemberDetailById(long memberId)
        {
			return await uow.MemberSqlRepo.GetEligibilityMemberDetailById(memberId);
		}
    }
}
