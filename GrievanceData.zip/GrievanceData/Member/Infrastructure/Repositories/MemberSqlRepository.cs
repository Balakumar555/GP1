﻿using System.Security.Cryptography;
using RestSharp;
using GrievanceData.Common.Infrastructure.Service;
using System.Text;
using GrievanceData.Member.Infrastructure.Settings;
using GrievanceData.Member.Infrastructure.Interfaces;
using GrievanceData.Member.Domain;
using GrievanceData.Common.Infrastructure.Settings;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Microsoft.Data.SqlClient;
using AutoMapper.Internal;
using GrievanceData.GrievanceDbContext;
using System.Net;
using GrievanceData.User.Domain;
using System.Net.NetworkInformation;
using System.Threading;
using Aspose.Pdf.Operators;
using GrievanceData.Case.Domain;

namespace GrievanceData.Member.Infrastructure.Repositories
{
    internal class MemberSqlRepository : IMemberSqlRepository
    {
        private ICustomerFactory customerFactory = null;
        private readonly ICommonService _cservice;
        //private readonly MemberSettings _membersettings;
        private readonly SQLRepoSettings _sqlsettings;
        private CommonSettings _commonsettings;
        public OutputParameter<string> errorDescription = new OutputParameter<string>();
        public OutputParameter<int?> errorCode = new OutputParameter<int?>();

        public MemberSqlRepository(CommonSettings commonsettings, MemberSettings membersettings, ICommonService service)
        {
            _commonsettings = commonsettings;
            _cservice = service;
            _sqlsettings = membersettings.MemberRepo;
        }

        public async Task<string> SearchMemberEligibility()
        {
            //List<> resp = await _cservice.GrievancesContext.Procedures.usp_GetMemberEligibilityByCustomerId(CustId, errorCode, errorDescription);

            //if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
            //{
            //    throw new Exception("Error while fetching users for Customer ID: " + CustId);
            //}

            //if (resp == null)
            //{
            //    throw new Exception("Error while fetching users for Customer ID: " + CustId);
            //}


            string ret = string.Empty;
            //if (custId == "Humana") // tblServiceAgentLog 
            //{
            //    customerFactory = new HumanaFactory();
            //    ret = $"Customer: {custName} and we are {customerFactory.HumanaWrapper().GetHumanaInfo()}";
            //}
            //else if (custName == "BCBS")
            //{
            //    customerFactory = new BCBSFactory();
            //    ret = $"Customer: {custName} and we are {customerFactory.BCBSWrapper().GetBCBSInfo()}";
            //}
            return ret;

        }

        public async Task<int> CreateMember(MemberDetail req)
        {
            List<usp_CreateMemberPlanAoRResult> result = new List<usp_CreateMemberPlanAoRResult>();
            try
            {
                OutputParameter<int> returnValue = new OutputParameter<int>();
                OutputParameter<int?> errorCode = new OutputParameter<int?>();
                try
                {
                    result = await _cservice.GrievancesContext.Procedures.usp_CreateMemberPlanAoRAsync(
                                    Convert.ToInt32(req?.AorInfo?.AorRelationship),
                                   req?.AorInfo?.AorFirstName,
                                   req?.AorInfo?.AorLastName,
                                   req?.AorInfo?.AorPhone.ToString(), req?.AorInfo?.AorAddressLine1, req?.AorInfo?.AorAddressLine2, req?.AorInfo?.AorCity,
                                   req?.AorInfo?.AorState, req?.AorInfo?.AorZip, req?.MemberInfo?.AddressLine1, req?.MemberInfo?.AddressLine2, req?.MemberInfo?.City, req?.MemberInfo?.State,
                                   req?.MemberInfo?.Zip.ToString(), req?.AorInfo?.formReceived, req?.AorInfo?.AorFormReceivedDate,
                                   req?.AorInfo?.MemberSignatureDate,
                                   req?.AorInfo?.ApointeeSignatureDate, req?.PlanInfo?.Mbi, req?.PlanInfo?.MemberNumber, req?.PlanInfo?.AltMemberId, req?.PlanInfo?.RelationCode,
                                   req?.PlanInfo?.PersonNumber, req?.PlanInfo?.GroupNumber, req?.PlanInfo?.EligibilityEffectiveDate, req?.PlanInfo?.EligibilityEndDate,
                                   req?.PlanInfo?.CardHolderContractNumber, req?.PlanInfo?.CmsContractNumber, req.PlanInfo.ClientId, req.PlanInfo.PlanId, req?.MemberInfo?.FirstName,
                                   req?.MemberInfo?.LastName, req?.MemberInfo?.MiddleName, req?.MemberInfo?.DateOfBirth, req?.MemberInfo?.Gender, req?.MemberInfo?.LanguagePrefrence, req?.MemberInfo?.CommunicationPrefrence,
                                   req?.MemberInfo.CellPhone.ToString(), req?.MemberInfo.HomePhone.ToString(), req.MemberInfo.WorkPhone.ToString(), req.MemberInfo.Fax, req.IsAor,
                                   req?.POAInfo?.POAFirstName,  req?.POAInfo?.POALastName,
                                   req?.POAInfo?.POARelationship, req?.POAInfo?.POAAddrLine1, req?.POAInfo?.POAAddrLine2,
                                   req?.POAInfo?.POAState, req?.POAInfo?.POACity, req?.POAInfo?.POAZip, req?.POAInfo?.POACountry,
                                   req?.POAInfo?.POAEmail, req?.POAInfo?.POAPhone, req?.POAInfo?.POAFormReceivedDate,
                                   req?.POAInfo?.POAEffectiveDate, req?.POAInfo?.POATerminationDate,
                                   req?.POAInfo?.POAFormReceived,  req?.IsPOA,

                                   Convert.ToInt32(req.CreatedBy), req?.AorInfo?.AorEmail, req?.MemberInfo?.Email, errorCode, errorDescription, returnValue);
                }
                catch (Exception ex)
                {
                   
                }

                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while creating a member ");

                }
                if (result.Count > 0)
                    return Convert.ToInt32(result.First().MemberPlanInfoID);
                else
                    throw new Exception("Error while creating a member ");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<usp_GetEligibilityMemberDataResult>> GetEligibilityMemberData(string? mbi, string? memberNumber, DateTime? dob, string? firstName, string? lastName, long userId)
        {
            try
            {
                var result = await _cservice.GrievancesContext.Procedures.usp_GetEligibilityMemberDataAsync(mbi, memberNumber, dob, lastName, firstName, userId, errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while fetching member data ");
                }
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<CaseDetailDto> GetEligibilityMemberDetailById(long memberId)
        {
            try
            {
                var data = await _cservice.GrievancesContext.Procedures.usp_GetEligibilityMemberDetailByIdAsync(memberId, errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while fetching member data ");
                }
                var result = data.FirstOrDefault();

                CaseDetailDto memberDetail = new CaseDetailDto()
                {
                    IsAor = Convert.ToBoolean(result.IsAOR),
                    MemberInfo = new MemberInfoDetailDto()
                    {
                        Email = result.Email != null ? result.Email : String.Empty,
                        CellPhone = result.CellPhoneNbr != null ? result.CellPhoneNbr : String.Empty,
                        CommunicationPrefrence = result.CommunicationPreference != null ? result.CommunicationPreference : String.Empty,
                        DateOfBirth = result.DOB != null ? result.DOB.Value : DateTime.MinValue,
                        FirstName = result.FirstName != null ? result.FirstName : String.Empty,
                        lastName = result.LastName != null ? result.LastName : String.Empty,
                        MiddleName = result.MiddleName != null ? result.MiddleName : String.Empty,
                        Gender = result.Gender != null ? result.Gender : String.Empty,
                        HomePhone = result.HomePhoneNbr != null ? result.HomePhoneNbr : String.Empty,
                        Fax = result.FaxNbr != null ? result.FaxNbr : String.Empty,
                        AddressLine1 = result.AddrLine1 != null ? result.AddrLine1 : String.Empty,
                        AddressLine2 = result.AddrLine2 != null ? result.AddrLine2 : String.Empty,
                        City = result.City != null ? result.City : String.Empty,
                        State = result.State != null ? result.State : String.Empty,
                        Zip = result.Zip != null ? result.Zip : String.Empty,
                        LanguagePrefrence = result.LanguagePreference != null ? result.LanguagePreference : String.Empty,
                        MemberNumber = result.MemberNumber != null ? result.MemberNumber : String.Empty,
                        MBI = result.MBI != null ? result.MBI : String.Empty,
                        ClientId = result.ClientId != null ? result.ClientId : 0,
                        PlanId = result.PlanId != null ? result.PlanId : 0,
                        ClientName = result.ClientName != null ? result.ClientName : String.Empty,
                        PlanName = result.PlanName != null ? result.PlanName : String.Empty,
                    },
                    AorInfo = new AorDetailDto()
                    {
                        aorAddressLine1 = result.aorAddressLine1 != null ? result.aorAddressLine1 : null,
                        aorAddressLine2 = result.aorAddressLine2 != null ? result.aorAddressLine2 : null,
                        aorCity = result.aorCity != null ? result.aorCity : null,
                        aorZip = result.aorZip != null ? result.aorZip : null,
                        aorState = result.aorState != null ? result.aorState : null,
                        aorFirstName = result.aorFirstName != null ? result.aorFirstName : null,
                        aorLastName = result.aorLastName != null ? result.aorLastName : null,
                        aorEmail = result.aorEmail != null ? result.aorEmail : null,
                        aorPhone = result.aorPhone != null ? result.aorPhone : null,
                        aorMiddleName = String.Empty,
                        aorFormReceivedDate = result.DateReceived != null ? result.DateReceived.Value : null,
                        aorRelationship = result.aorRelationship != null ? result.aorRelationship.Value.ToString() : null,
                        memberSignatureDate = result.MemberSignatureDate != null ? result.MemberSignatureDate : null,
                        apointeeSignatureDate = result.AppointeeSignatureDate != null ? result.AppointeeSignatureDate : null,
                        formReceived = result.RepresentativeFormReceived != null ? result.RepresentativeFormReceived : false
                    }

                };

                return memberDetail;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
