﻿using GrievanceData.User.Infrastructure.Interfaces;
using GrievanceData.Member.Infrastructure.Settings;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GrievanceData.Member.Infrastructure.Interfaces;

namespace GrievanceData.Member.Infrastructure.Repositories
{
    internal class MemberUnitOfWork : IMemberUnitOfWork
    {
        //You will need UnitOfWork when you have transactions through a repo;
        private readonly IMemberSqlRepository _MemberRepo;
        IMemberSqlRepository IMemberUnitOfWork.MemberSqlRepo => _MemberRepo;
        public MemberUnitOfWork(MemberUnitOfWorkSettings uows)
        {
            _MemberRepo = new MemberSqlRepository(uows.commonsettings, uows.membersettings, uows.commonservice);
        }
    }
}
