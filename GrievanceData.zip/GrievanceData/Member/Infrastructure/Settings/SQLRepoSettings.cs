namespace GrievanceData.Member.Infrastructure.Settings
{
    public class SQLRepoSettings
    {
        // public string GetUserToken { get; set; }
    }
}