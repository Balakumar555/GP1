﻿using GrievanceData.Common.Infrastructure.Service;
using GrievanceData.Common.Infrastructure.Settings;

namespace GrievanceData.Member.Infrastructure.Settings
{
    public class MemberUnitOfWorkSettings
    {
        public CommonSettings commonsettings { get; set; }
        public ICommonService commonservice { get; set; }
        public MemberSettings membersettings { get; set; }
    }
}
