﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.Member.Infrastructure.Interfaces
{
    interface ICustomerFactory
    {
        IHumana HumanaWrapper();
        IBCBS BCBSWrapper();
    }
}
