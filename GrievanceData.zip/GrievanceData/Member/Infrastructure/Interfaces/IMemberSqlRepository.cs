﻿using GrievanceData.Case.Domain;
using GrievanceData.Member.Domain;
using GrievanceData.Member.Services;
using GrievanceData.User.Domain;

namespace GrievanceData.Member.Infrastructure.Interfaces
{
    internal interface IMemberSqlRepository : IMemberEntity
    {        
        Task<string> SearchMemberEligibility();
        Task<int> CreateMember(MemberDetail req);
		Task<List<usp_GetEligibilityMemberDataResult>> GetEligibilityMemberData(string? mbi, string? memberNumber, DateTime? dob, string? firstName, string? lastName, long userId);
		Task<CaseDetailDto> GetEligibilityMemberDetailById(long memberId);
    }
}
