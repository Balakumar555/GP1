﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.Member.Infrastructure.Interfaces
{
    internal interface IMemberUnitOfWork
    {
        IMemberSqlRepository MemberSqlRepo { get; }
    }
}
