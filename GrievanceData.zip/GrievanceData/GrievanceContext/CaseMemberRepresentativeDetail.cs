﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
	public class CaseMemberRepresentativeDetail
	{
		public CaseMemberRepresentativeDetail()
		{
			CaseDetail = new HashSet<CaseDetail>();
		}

		public long MemberRepresentativeId { get; set; }
		public string AddrLine1 { get; set; }
		public string State { get; set; }
		public string City { get; set; }
		public string Zip { get; set; }
		public string Country { get; set; }
		public string Email { get; set; }
		public bool? IsAor { get; set; }
		public bool? FormReceived { get; set; }
		public string Aorrelationship { get; set; }
		public DateTime? AorformReceivedDate { get; set; }
		public string Aorphone { get; set; }
		public string AoraddrLine1 { get; set; }
		public string Aorstate { get; set; }
		public string Aorcity { get; set; }
		public string Aorzip { get; set; }
		public string Aorcountry { get; set; }
		public string Aoremail { get; set; }
		public DateTime CreatedDate { get; set; }
		public string CreatedBy { get; set; }
		public DateTime? LastModified { get; set; }
		public string LastModifiedBy { get; set; }
		public string FirstName { get; set; }
		public string MiddleName { get; set; }
		public string LastName { get; set; }
		public DateTime? Dob { get; set; }
		public string AddrLine2 { get; set; }
		public string HomePhone { get; set; }
		public string WorkPhone { get; set; }
		public string Fax { get; set; }
		public string CellPhone { get; set; }
		public string CommunicationPreference { get; set; }
		public string LanguagePrefrence { get; set; }
		public string AorfirstName { get; set; }
		public string AormiddleName { get; set; }
		public string AorlastName { get; set; }
		public string AoraddrLine2 { get; set; }
		public DateTime? MemberSignatureDate { get; set; }
		public DateTime? ApointeeSignatureDate { get; set; }
		public string Gender { get; set; }
		public string Mbi { get; set; }
		public string MemberNumber { get; set; }
		public int? PlanId { get; set; }
		public int? ClientId { get; set; }
		public virtual ICollection<CaseDetail> CaseDetail { get; set; }
	}
}
