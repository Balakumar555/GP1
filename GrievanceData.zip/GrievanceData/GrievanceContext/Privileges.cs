﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
	public partial class Privileges
	{
		public Privileges()
		{
			RolePrivileges = new HashSet<RolePrivileges>();
			UserPrivileges = new HashSet<UserPrivileges>();
		}

		public int PrivilegeId { get; set; }
		public string Description { get; set; }
		public short CustomerId { get; set; }
		public string Name { get; set; }
		public DateTime? LastModifiedDate { get; set; }
		public long? LastModifiedBy { get; set; }
		public DateTime CreatedDate { get; set; }
		public long CreatedBy { get; set; }

		public virtual TblCustomer Customer { get; set; }
		public virtual ICollection<RolePrivileges> RolePrivileges { get; set; }
		public virtual ICollection<UserPrivileges> UserPrivileges { get; set; }
	}
}
