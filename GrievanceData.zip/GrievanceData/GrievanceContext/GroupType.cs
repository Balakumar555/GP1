﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
	public partial class GroupType
	{
		public GroupType()
		{
			ClientPlanGroup = new HashSet<ClientPlanGroup>();
		}

		public short GroupTypeId { get; set; }
		public string GroupTypeCode { get; set; }
		public string Description { get; set; }

		public virtual ICollection<ClientPlanGroup> ClientPlanGroup { get; set; }
	}
}
