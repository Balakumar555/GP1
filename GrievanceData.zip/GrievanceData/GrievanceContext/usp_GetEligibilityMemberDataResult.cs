﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
	public partial class usp_GetEligibilityMemberDataResult
	{
		public long MemberPlanInfoID { get; set; }
		public string MemberNumber { get; set; }
		public string MemberName { get; set; }
		public DateTime? MemberDOB { get; set; }
		public string MBI { get; set; }
		public string PlanName { get; set; }
		public DateTime EligibilityStart { get; set; }
		public DateTime EligibilityEnd { get; set; }
		public string ClientName { get; set; }
		public string EligibleStatus { get; set; }
	}
}
