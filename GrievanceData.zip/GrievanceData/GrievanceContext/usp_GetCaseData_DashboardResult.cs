﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
	public partial class usp_GetCaseData_DashboardResult
	{
		public string CaseID { get; set; }
		public long CaseDetailId { get; set; }
		public DateTime ReceivedDate { get; set; }
		public string? MemberNumber { get; set; }
		public string MemberName { get; set; }
		public DateTime? MemberDOB { get; set; }
		public string? MBI { get; set; }
		public DateTime? ClosedDate { get; set; }
		public string? CaseOutcome { get; set; }
		public string CategoryName { get; set; }
	}
}
