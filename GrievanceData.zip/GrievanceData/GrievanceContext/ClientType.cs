﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
	public partial class ClientType
	{
		public ClientType()
		{
			Client = new HashSet<Client>();
		}

		public short ClientTypeId { get; set; }
		public string ClientTypeCode { get; set; }
		public string Description { get; set; }

		public virtual ICollection<Client> Client { get; set; }
	}
}
