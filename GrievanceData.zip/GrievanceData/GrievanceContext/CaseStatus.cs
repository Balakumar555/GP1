﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
	public class CaseStatus
	{
		public CaseStatus()
		{
			CaseDetail = new HashSet<CaseDetail>();
		}

		public short CaseStatusId { get; set; }
		public string Status { get; set; }
		public string Description { get; set; }
		public DateTime CreatedDate { get; set; }
		public long CreatedBy { get; set; }
		public DateTime? LastModifiedDate { get; set; }
		public long? LastModifiedBy { get; set; }

		public virtual ICollection<CaseDetail> CaseDetail { get; set; }
	}
}
