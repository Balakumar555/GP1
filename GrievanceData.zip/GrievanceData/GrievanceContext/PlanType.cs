﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
	public partial class PlanType
	{
		public PlanType()
		{
			ClientPlan = new HashSet<ClientPlan>();
		}

		public short PlanTypeId { get; set; }
		public string PlanTypeCode { get; set; }
		public string Description { get; set; }

		public virtual ICollection<ClientPlan> ClientPlan { get; set; }
	}
}
