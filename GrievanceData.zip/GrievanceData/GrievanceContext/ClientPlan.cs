﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
	public partial class ClientPlan
	{
		public ClientPlan()
		{
			ClientPlanGroup = new HashSet<ClientPlanGroup>();
		}

		public long ClientPlanId { get; set; }
		public short? PlanTypeId { get; set; }
		public long? ClientId { get; set; }
		public string PlanName { get; set; }
		public string PlanCode { get; set; }
		public string Description { get; set; }
		public DateTime EffectiveDate { get; set; }
		public DateTime EndDate { get; set; }
		public DateTime CreatedDate { get; set; }
		public long CreatedBy { get; set; }
		public DateTime? LastModifiedDate { get; set; }
		public long? LastModifiedBy { get; set; }

		public virtual Client Client { get; set; }
		public virtual PlanType PlanType { get; set; }
		public virtual ICollection<ClientPlanGroup> ClientPlanGroup { get; set; }
	}
}
