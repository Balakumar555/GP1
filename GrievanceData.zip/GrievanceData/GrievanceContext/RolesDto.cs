﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
	public partial class RolesDto
	{		
		public short RoleId { get; set; }
		public string Description { get; set; }
		public bool? IsAdmin { get; set; }
		public short CustomerId { get; set; }
		public DateTime? RoleLastLastModifiedDate { get; set; }
		public long? RoleLastModifiedBy { get; set; }
		public DateTime RoleCreatedDate { get; set; }
		public long RoleCreatedBy { get; set; }
		public string RoleName { get; set; }
		

	}
}
