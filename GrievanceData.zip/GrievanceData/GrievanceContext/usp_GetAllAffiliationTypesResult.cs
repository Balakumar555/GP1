﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
	public partial class usp_GetAllAffiliationTypesResult
	{
		public int UserTypeId { get; set; }
		public string Description { get; set; }
	}
}
