﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
	public class CaseDetail
	{
		public short CaseDetailId { get; set; }
		public short? StatusId { get; set; }
		public short? CustomerId { get; set; }
		public long? MemberRepresentativeId { get; set; }
		public DateTime? IncidentDate { get; set; }
		public DateTime? DueDate { get; set; }
		public DateTime ReceivedDate { get; set; }
		public string Method { get; set; }
		public string Requestor { get; set; }
		public string RequestType { get; set; }
		public short CategoryId { get; set; }
		public string SubCategory { get; set; }
		public string Source { get; set; }
		public string Urgency { get; set; }
		public bool? HighPriority { get; set; }
		public bool? ExtensionTaken { get; set; }
		public string PartType { get; set; }
		public bool? ComplianceCase { get; set; }
		public bool? GoodCause { get; set; }
		public string Description { get; set; }
		public string FirstTier { get; set; }
		public DateTime CreatedDate { get; set; }
		public long CreatedBy { get; set; }
		public DateTime? LastModifiedDate { get; set; }
		public long? LastModifiedBy { get; set; }
		public string CaseId { get; set; }
		public long? AssigneeId { get; set; }
		public DateTime? ClosedDate { get; set; }
		public virtual Category Category { get; set; }
		public virtual TblCustomer Customer { get; set; }
		public virtual CaseMemberRepresentativeDetail MemberRepresentative { get; set; }
		public virtual CaseStatus Status { get; set; }
		public virtual TblUsers? Assignee { get; set; }
	}
}
