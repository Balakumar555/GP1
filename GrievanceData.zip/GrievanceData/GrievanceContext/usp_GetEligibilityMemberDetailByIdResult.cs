﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
	public partial class usp_GetEligibilityMemberDetailByIdResult
	{
		public long MemberPlanInfoID { get; set; }
		public long? AORInfoID { get; set; }
		public int? IsAOR { get; set; }
		public string? MBI { get; set; }
		public string? MemberNumber { get; set; }
		public int? ClientId { get; set; }
		public int? PlanId { get; set; }
		public string? FirstName { get; set; }
		public string? LastName { get; set; }
		public string? MiddleName { get; set; }
		public DateTime? DOB { get; set; }
		public string? Gender { get; set; }
		public string? LanguagePreference { get; set; }
		public string? CommunicationPreference { get; set; }
		public string? CellPhoneNbr { get; set; }
		public string? HomePhoneNbr { get; set; }
		public string? WorkPhoneNbr { get; set; }
		public string? FaxNbr { get; set; }
		public string? AddrLine1 { get; set; }
		public string? AddrLine2 { get; set; }
		public string? City { get; set; }
		public string? State { get; set; }
		public string? Zip { get; set; }
		public string? Email { get; set; }
		public int? aorRelationship { get; set; }
		public string? aorFirstName { get; set; }
		public string? aorLastName { get; set; }
		public string? aorPhone { get; set; }
		public string? aorAddressLine1 { get; set; }
		public string? aorAddressLine2 { get; set; }
		public string? aorCity { get; set; }
		public string? aorState { get; set; }
		public string? aorZip { get; set; }
		public bool? RepresentativeFormReceived { get; set; }
		public DateTime? DateReceived { get; set; }
		public DateTime? MemberSignatureDate { get; set; }
		public DateTime? AppointeeSignatureDate { get; set; }
		public string? aorEmail { get; set; }
		public string? ClientName { get; set; }
		public string? PlanName { get; set; }
	}
}
