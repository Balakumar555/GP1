﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
	public partial class usp_CreateDraftGrievancesCaseResult
	{
		public int? DraftCaseDetailId { get; set; }
	}
}
