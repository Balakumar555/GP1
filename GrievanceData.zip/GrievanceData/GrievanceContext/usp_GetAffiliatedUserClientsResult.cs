﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
	public partial class usp_GetAffiliatedUserClientsResult
	{
		public long ClientId { get; set; }
		public string ClientName { get; set; }
	}
}
