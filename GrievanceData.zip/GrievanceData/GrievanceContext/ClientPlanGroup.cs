﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
	public partial class ClientPlanGroup
	{
		public long ClientPlanGroupId { get; set; }
		public short? GroupTypeId { get; set; }
		public long? ClientPlanId { get; set; }
		public string GroupName { get; set; }
		public string GroupNumber { get; set; }
		public string Description { get; set; }
		public DateTime EffectiveDate { get; set; }
		public DateTime EndDate { get; set; }
		public DateTime CreatedDate { get; set; }
		public long CreatedBy { get; set; }
		public DateTime? LastModifiedDate { get; set; }
		public long? LastModifiedBy { get; set; }

		public virtual ClientPlan ClientPlan { get; set; }
		public virtual GroupType GroupType { get; set; }
	}
}
