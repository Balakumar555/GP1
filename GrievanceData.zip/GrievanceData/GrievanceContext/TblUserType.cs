﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
	public partial class TblUserType
	{
		public TblUserType()
		{
			TblUsers = new HashSet<TblUsers>();
		}

		public int UserTypeId { get; set; }
		public string UserTypeCode { get; set; }
		public string Description { get; set; }
		public DateTime? LastModifiedDate { get; set; }
		public long? LastModifiedBy { get; set; }
		public DateTime CreatedDate { get; set; }
		public long CreatedBy { get; set; }

		public virtual ICollection<TblUsers> TblUsers { get; set; }
	}
}
