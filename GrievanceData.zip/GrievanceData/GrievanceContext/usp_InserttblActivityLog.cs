﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
    public partial class usp_InserttblActivityLog
    {
        public long ActivityLogId { get; set; }
        public int CustomerId { get; set; }
        public int SectionId { get; set; }
        public string? Action { get; set; }
        public string? FieldName { get; set; }
        public string? OldValue { get; set; }
        public string? NewValue { get; set; }
        public int ChangedBy { get; set; }
        public DateTime ChangedDate { get; set; }
    }
}
