﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceContext
{
	public partial class usp_GetCaseCommentByCaseIdResult
	{
		public int CaseCommentId { get; set; }
		public long? CaseDetailId { get; set; }
		public int? CaseAttachmentId { get; set; }
		public string Comment { get; set; }
		public bool? IsDelete { get; set; }
		public DateTime? LastModifiedDate { get; set; }
		public long? LastModifiedBy { get; set; }
		public DateTime CreatedDate { get; set; }
		public long CreatedBy { get; set; }
		public string UserName { get; set; }
		public string? AttachmentFileName { get; set; }
	}
}
