﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.Entities
{  
    public interface IBaseEntity<T> where T : class, new()
    {
        Task<T> Get(decimal id);
        Task<T> Get(int nbr);
        Task<List<T>> GetAll();
        Task<T> Save(T e);
        Task<T> Delete(T e);
    }
}
