﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceHubAspose
{
    public static class AsposeLicense
    {
        public static bool IsLicenseSet { get; set; }
    }
}
