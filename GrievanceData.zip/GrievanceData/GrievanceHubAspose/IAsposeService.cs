﻿using System.Data;
using System.Drawing;
using System.IO;
using System.Xml;

namespace GrievanceData.GrievanceHubAspose
{
    public interface IAsposeService
    {
        bool IsProduction { set; }
        string UploadImagesPath { get; set; }
        void SetAsposeLicense();
        byte[] AddDocID(byte[] byte_img, string DocumentId, string ReceivedOn = "");
        byte[] AddText(byte[] byte_img, string Text);
        void BindHTMLfromURL(string URL);
        byte[] ConvertHTMLToPDF(Stream htmlStream, string basePath);
        MemoryStream ConvertPDFtoTIFF(byte[] byte_img);
        byte[] ConvertPDFToWordToPDF(string filePath, out int noofPages);
        void ConverttoPDF(string ext, byte[] arrByteImageOrPdf, out MemoryStream msImageorPdfStream, out int noOfPages);
        void DocumentMailMergeExecuteUsingDataTable(DataTable TableData);
        void DocumentMailMergeExecuteUsingKeyValues(string[] Key, object[] Values);
        void ExecuteMailMerge(DataTable dtPlaceholders, ref object wordDoc);
        void FieldMergingCallbackForHTML();
        void FieldMergingCallbackForImage();
        void GenerateFaxFromSupportingDocuments(string pdfFileName, string ext, byte[] arrByteImageOrPdf, bool iscustomeCoverPage, byte[] customerCoverPage, out MemoryStream msImageorPdfStream, out int noOfPages, PageSetupStruct pageSetupstruct, string sinputfile, string soutputfile);
        void GenerateFaxFromSupportingDocuments(string pdfFileName, string ext, byte[] arrByteImageOrPdf, bool iscustomeCoverPage, byte[] customerCoverPage, out MemoryStream msImageorPdfStream, out int noOfPages, string sinputfile, string soutputfile);
        MemoryStream GenerateStreamFromXML(XmlDocument xmlDoc, PageSetupStruct pageSetup);
        string[] GetDocFieldName();
        string[] GetDocFieldName(Stream WordStream);
        AsposeService getInstance(bool isProduction);
        //RR - TODO: Find the way to insert the image tot he document using another method other than system.drawing whic is not supported
        //byte[] VerifyDocExtension(string ext, MemoryStream memoryStream, byte[] byte_img, string uploadImagesPath);
        string[] GetMailMergeFields(Stream wordStream, out object wordDoc);
        int GetPDFFileInfoWidthHeight(ref int pageWidth, ref int pageHight, FileStream fileInputStream);
        void HoldFaxData(string barImagePath);
        Stream MergeDocfiles(Stream Source, Stream Dest);
        MemoryStream MergePDF(MemoryStream msFirst, MemoryStream msSecond);
        MemoryStream MergePDF(Stream msFirst, Stream msSecond);
        int NumberOfBlankPages(MemoryStream inputStream);
        void OpenPDFusingPDFViewer(string filePath, byte[] document, ref int iPrimaryPDF);
        int PageCount(MemoryStream inputStream);
        int PageCount(string FilePath);
        string PDFFilEditorOperation(MemoryStream ms, int[] PageNo, out byte[] byte_SplitDoc, out byte[] byte_RemainingDoc);
        string PDFFilEditorOperation(MemoryStream ms, int[] PageNo, out byte[] byte_SplitDoc, out byte[] byte_RemainingDoc, int[] remainingPageNo);
        MemoryStream PDFFileEditorConcatenate(Stream[] inStreamsArray, MemoryStream outFileStream);
        void PDFFileMendAddImage(FileStream inputStream, FileStream outputStream, string pdffilepath, int[] pageNO, int pageWidth, int pageHight);
        void PDFFileSave(float width, float Height, MemoryStream memoryStream, string imagelocation);
        MemoryStream SaveDocument(MemoryStream streamData, Format fileFormat);
        void SaveNewPdf(MemoryStream inMemoryStream, Image objDrawImage, string ext, MemoryStream ms3);
        void SavePDf(string FilePath);
        void SavePDf(XmlDocument xmlDoc, MemoryStream mStrTempFullreport);
        void SavePDFFileEditor(string filePath, int Rotationvalue, int[] PageNo, string filePathnew);
        void SaveToLetterPrintingTable(string Path, byte[] Document);
        MemoryStream SaveWordtoPdf(object wordDoc);
        Stream SaveWordtoPdfStream(Stream wordStream);
        void SendFax();
        void setDocumentObject(MemoryStream objMemoryStream);
        void setDocumentObject(Stream objStream);
        void setDocumentObject(string filePath);

        MemoryStream SaveWordDocument(MemoryStream streamData);
        MemoryStream SavePDFDocument(MemoryStream streamData);
        byte[] VerifyDocExtension(string ext, MemoryStream memoryStream, byte[] byte_img, string uploadImagePath);
        MemoryStream AddDocID(MemoryStream byte_img, string DocumentId, string ReceivedOn = "");
        Image GetDrawImageFromStream(MemoryStream inMemoryStream);
    }
}