﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.GrievanceHubAspose
{
    public enum Format
    {
        //Unknown = 0,
        ////
        //// Summary:
        ////     Saves the document in the Microsoft Word 97 - 2003 Document format.
        //Doc = 1,
        ////
        //// Summary:
        ////     Saves the document in the plain text format.
        //Text = 2,
        ////
        //// Summary:
        ////     Saves the document in the HTML format. Uses UTF8 encoding.
        //Html = 4,
        ////
        //// Summary:
        ////     Saves the document in the Microsoft Word 2003 WordprocessingML format. Uses
        ////     UTF8 encoding.
        //WordML = 5,
        ////
        //// Summary:
        ////     Saves the document in the RTF format. All characters above 7-bits are escaped
        ////     as hexadecimal or Unicode characters.
        //Rtf = 6,
        ////
        //// Summary:
        ////     Saves the document in the Microsoft Office 2007 Open XML format.
        //Docx = 8,
        //Docm = 9,
        //FlatOpc = 10,
        //Odt = 12,
        //Mhtml = 13,
        //Epub = 14,
        //Pdf = 15,
        //Xps = 16,
        //XamlFixed = 17,
        //Swf = 18,
        //XamlFlow = 20,
        //Dot = 200,
        //Dotx = 201,
        //Dotm = 202,
        //Ott = 203,
        //Tiff = 300,
        //Png = 301,
        //Bmp = 302,
        //Emf = 303,
        //Jpeg = 304,
        // Summary:
        //     Default, invalid value for file format.
        Unknown = 0,
        //
        // Summary:
        //     Saves the document in the Microsoft Word 97 - 2007 Document format.
        Doc = 10,
        //
        // Summary:
        //     Saves the document in the Microsoft Word 97 - 2007 Template format.
        Dot = 11,
        //
        // Summary:
        //     Saves the document as an Office Open XML WordprocessingML Document (macro-free).
        Docx = 20,
        //
        // Summary:
        //     Saves the document as an Office Open XML WordprocessingML Macro-Enabled Document.
        Docm = 21,
        //
        // Summary:
        //     Saves the document as an Office Open XML WordprocessingML Template (macro-free).
        Dotx = 22,
        //
        // Summary:
        //     Saves the document as an Office Open XML WordprocessingML Macro-Enabled Template.
        Dotm = 23,
        //
        // Summary:
        //     Saves the document as an Office Open XML WordprocessingML stored in a flat
        //     XML file instead of a ZIP package.
        FlatOpc = 24,
        //
        // Summary:
        //     Saves the document as an Office Open XML WordprocessingML Macro-Enabled Document
        //     stored in a flat XML file instead of a ZIP package.
        FlatOpcMacroEnabled = 25,
        //
        // Summary:
        //     Saves the document as an Office Open XML WordprocessingML Template (macro-free)
        //     stored in a flat XML file instead of a ZIP package.
        FlatOpcTemplate = 26,
        //
        // Summary:
        //     Saves the document as an Office Open XML WordprocessingML Macro-Enabled Template
        //     stored in a flat XML file instead of a ZIP package.
        FlatOpcTemplateMacroEnabled = 27,
        //
        // Summary:
        //     Saves the document in the RTF format. All characters above 7-bits are escaped
        //     as hexadecimal or Unicode characters.
        Rtf = 30,
        //
        // Summary:
        //     Saves the document in the Microsoft Word 2003 WordprocessingML format.
        WordML = 31,
        //
        // Summary:
        //     Saves the document as PDF (Adobe Portable Document) format.
        Pdf = 40,
        //
        // Summary:
        //     Saves the document in the XPS (XML Paper Specification) format.
        Xps = 41,
        //
        // Summary:
        //     Saves the document in the Extensible Application Markup Language (XAML) format
        //     as a fixed document.
        XamlFixed = 42,
        //
        // Summary:
        //     Saves the document in the SWF (Adobe Flash Player) format.
        Swf = 43,
        //
        // Summary:
        //     Saves the document in the Svg (Scalable Vector Graphics) format.
        Svg = 44,
        //
        // Summary:
        //     Saves the document in the HTML format using absolutely positioned elements
        HtmlFixed = 45,
        //
        // Summary:
        //     Saves the document in the OpenXPS (Ecma-388) format.
        OpenXps = 46,
        //
        // Summary:
        //     Saves the document in the PS (PostScript) format.
        Ps = 47,
        //
        // Summary:
        //     Saves the document in the HTML format.
        Html = 50,
        //
        // Summary:
        //     Saves the document in the MHTML (Web archive) format.
        Mhtml = 51,
        //
        // Summary:
        //     Saves the document in the IDPF EPUB format.
        Epub = 52,
        //
        // Summary:
        //     Saves the document as an ODF Text Document.
        Odt = 60,
        //
        // Summary:
        //     Saves the document as an ODF Text Document Template.
        Ott = 61,
        //
        // Summary:
        //     Saves the document in the plain text format.
        Text = 70,
        //
        // Summary:
        //     Beta. Saves the document in the Extensible Application Markup Language (XAML)
        //     format as a flow document.
        XamlFlow = 71,
        //
        // Summary:
        //     Beta. Saves the document in the Extensible Application Markup Language (XAML)
        //     package format as a flow document.
        XamlFlowPack = 72,
        //
        // Summary:
        //     Renders a page or pages of the document and saves them into a single or multipage
        //     TIFF file.
        Tiff = 100,
        //
        // Summary:
        //     Renders a page of the document and saves it as a PNG file.
        Png = 101,
        //
        // Summary:
        //     Renders a page of the document and saves it as a BMP file.
        Bmp = 102,
        //
        // Summary:
        //     Renders a page of the document and saves it as a vector EMF (Enhanced Meta
        //     File) file.
        // [  ("Rendering to EMF is not ported to Java.")]
        Emf = 103,
        //
        // Summary:
        //     Renders a page of the document and saves it as a JPEG file.
        Jpeg = 104,
    }

    public struct PageSetupStruct
    {
        public float PageHeight;
        public bool SetPageHeight;
        public float PageWidth;
        public bool SetPageWidth;
        public float MarginLeft;
        public bool SetMarginLeft;
        public float MarginRight;
        public bool SetMarginRight;
        public float Top;
        public float Left;
        public float Right;
        public float Bottom;

        public PageSetupStruct(float PageHeight,
            bool SetPageHeight,
            float PageWidth,
            bool SetPageWidth,
            float MarginLeft,
            bool SetMarginLeft,
            float MarginRight,
            bool SetMarginRight,
            float Top,
            float Left,
            float Right,
            float Bottom)
        {
            this.PageHeight = PageHeight;
            this.SetPageHeight = SetPageHeight;
            this.PageWidth = PageWidth;
            this.SetPageWidth = SetPageWidth;
            this.MarginLeft = MarginLeft;
            this.SetMarginLeft = SetMarginLeft;
            this.MarginRight = MarginRight;
            this.SetMarginRight = SetMarginRight;
            this.Top = Top;
            this.Left = Left;
            this.Right = Right;
            this.Bottom = Bottom;


        }
    }
}
