﻿using System;
using System.Data;
using System.IO;
using System.Xml;
using word = Aspose.Words;
using pdfFacedes = Aspose.Pdf.Facades;
using wordMailMerging = Aspose.Words.MailMerging;
using System.Web;
using pdf = Aspose.Pdf;
using Aspose.Words.Drawing;
using Aspose.Words.Saving;
using Aspose.Pdf.Devices;
//using Microsoft.Extensions.Logging;
using SkiaSharp;
using System.Drawing;

namespace GrievanceData.GrievanceHubAspose
{
    public class AsposeService : IAsposeService
    {
        private AsposeService instance = null;

        private bool isProduction;

        private object lockThis = new object();

        private word.Document srcDoc = null;
        //private readonly ILogger<DocumentsService> _logger;
      
        public AsposeService()
        {
            //_logger = logger;
            //SetAsposeLicense(); // Don't want to do this every time
            
        }

        public AsposeService(bool isProduction)
        {
            IsProduction = isProduction;
            SetAsposeLicense();
        }

        public bool IsProduction
        {
            set
            {
                isProduction = value;
                SetAsposeLicense();
            }
        }

        public string UploadImagesPath { get; set; }

        public void DocumentMailMergeExecuteUsingDataTable(DataTable TableData)
        {

            srcDoc.MailMerge.Execute(TableData);
        }

        public void DocumentMailMergeExecuteUsingKeyValues(string[] Key, object[] Values)
        {
            srcDoc.MailMerge.Execute(Key, Values);
        }

        public byte[] AddText(byte[] byte_img, string Text)
        {
            MemoryStream msoriginalPdfstream1 = new MemoryStream();
            MemoryStream finalStr = new MemoryStream();
            msoriginalPdfstream1.Write(byte_img, 0, byte_img.Length);
            //Apr 2021 Kalyan CR#2125 ASPOSE PDF Ugprade 
            // Aspose.Pdf.Generator.Pdf pdfFile = new Aspose.Pdf.Generator.Pdf();
            Aspose.Pdf.Document pdfDocument = new Aspose.Pdf.Document(msoriginalPdfstream1);
            pdf.TextStamp textStamp = null;

            textStamp = new pdf.TextStamp(Text);
            textStamp.TextState.ForegroundColor = pdf.Color.Red;
            textStamp.TextState.FontStyle = pdf.Text.FontStyles.Bold;
            textStamp.TopMargin = 15;
            textStamp.HorizontalAlignment = pdf.HorizontalAlignment.Right;
            textStamp.VerticalAlignment = pdf.VerticalAlignment.Top;

            pdfDocument.Pages[1].AddStamp(textStamp);
            pdfDocument.Save(finalStr);
            byte_img = finalStr.ToArray();
            return byte_img;
        }

        public MemoryStream AddDocID(MemoryStream byte_img, string DocumentId, string ReceivedOn = "")
        {
            byte[] arrbyte = byte_img.ToArray();
            string Doc_Rec = string.Empty;
            byte[] output = null;
            try
            {
                if (ReceivedOn != "")
                {
                    var timeUtc = Convert.ToDateTime(ReceivedOn);
                    //TimeZoneInfo easternZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
                    //DateTime easternTime = TimeZoneInfo.ConvertTimeFromUtc(timeUtc, easternZone);
                    // Doc_Rec = easternTime.ToString("MM/dd/yyyy HH:mm:ss");
                    Doc_Rec = timeUtc.ToString("MM/dd/yyyy HH:mm:ss");
                }
                output = AddDocID(arrbyte, DocumentId, Doc_Rec);
            }
            catch (Exception ex)
            {
                throw;
            }
            return new MemoryStream(output);
        }

        public byte[] AddDocID(byte[] byte_img, string DocumentId, string ReceivedOn = "")
        {
            MemoryStream msoriginalPdfstream1 = new MemoryStream();
            MemoryStream finalStr = new MemoryStream();
            msoriginalPdfstream1.Write(byte_img, 0, byte_img.Length);
            //Apr 2021 Kalyan CR#2125 ASPOSE PDF Ugprade 
            // Aspose.Pdf.Generator.Pdf pdfFile = new Aspose.Pdf.Generator.Pdf();
            Aspose.Pdf.Document pdfDocument = new Aspose.Pdf.Document(msoriginalPdfstream1);
            pdf.TextStamp textStamp = null;
            if (!string.IsNullOrEmpty(ReceivedOn))
            {
                textStamp = new pdf.TextStamp("Doc ID: " + DocumentId + "   " + "Received on: " + ReceivedOn + " ET ");
            }
            else
            {
                textStamp = new pdf.TextStamp("Doc ID:" + DocumentId);
            }
            textStamp.TopMargin = 15;
            textStamp.HorizontalAlignment = pdf.HorizontalAlignment.Right;
            textStamp.VerticalAlignment = pdf.VerticalAlignment.Top;

            pdfDocument.Pages[1].AddStamp(textStamp);
            pdfDocument.Save(finalStr);
            byte_img = finalStr.ToArray();
            return byte_img;
        }
        public void ExecuteMailMerge(DataTable dtPlaceholders, ref object wordDoc)
        {
            word.Document srcDoc = wordDoc as word.Document;
            if (srcDoc != null)
                srcDoc.MailMerge.Execute(dtPlaceholders);
        }

        public void FieldMergingCallbackForHTML()
        {
            srcDoc.MailMerge.FieldMergingCallback = new HandleMergeFieldInsertHtml();
        }

        public void FieldMergingCallbackForImage()
        {
            srcDoc.MailMerge.FieldMergingCallback = new HandleMergeFieldInsertImage();
        }

        //RR - If needed fix method
        //public System.Drawing.Image GenerateBarcodeImage(string barString)
        //{
        //    BarcodeGenerator objBarCode = new BarcodeGenerator();
        //    System.Drawing.Image imgBar = objBarCode.barCode(barString);
        //    return imgBar;
        //}

        public void GenerateFaxFromSupportingDocuments(string pdfFileName, string ext, byte[] arrByteImageOrPdf, bool iscustomeCoverPage, byte[] customerCoverPage,
            out MemoryStream msImageorPdfStream, out int noOfPages, string sinputfile, string soutputfile)
        {
            MemoryStream objFileStream = new MemoryStream();
            noOfPages = 0;
            // Aspose Pdf object declaration
            msImageorPdfStream = new MemoryStream();
            //Apr 2021 Kalyan CR#2125 ASPOSE PDF Ugprade 
            //pdfGenerator.Pdf objPdf = new pdfGenerator.Pdf();
            //objPdf.PageSetup.PageHeight = pdfGenerator.PageSize.LetterHeight;
            //objPdf.PageSetup.PageWidth = pdfGenerator.PageSize.LetterWidth;
            //objPdf.PageSetup.Margin.Left = 70;
            //objPdf.PageSetup.Margin.Right = 100;
            Aspose.Pdf.Document objPdf = new Aspose.Pdf.Document();
            objPdf.PageInfo.Margin.Left = 70;
            objPdf.PageInfo.Margin.Right = 100;

            /* *

             * If we are sending image file as  fax , we have to create aspose pdf image  object.

             * If we want to send pdf as fax the we need to create pdf object.

             * */

            // Adding new section to hold fax data

            // pdfGenerator.Section secImg = objPdf.Sections.Add();
            Aspose.Pdf.Page secImg = objPdf.Pages.Add();
            // Adding Header and Footer as per point 6 of issue 793

            //pdfGenerator.HeaderFooter objHeader = secImg.InsertHeader(pdfGenerator.HeaderFooterType.Both);
            // pdfGenerator.Table objHeaderTable = new pdfGenerator.Table();
            // pdfGenerator.Row objHeaderRow = objHeaderTable.Rows.Add();
            //pdfGenerator.Cell objHeaderTableLeftCell = objHeaderRow.Cells.Add();
            //pdfGenerator.Cell objHeaderTableRightCell = objHeaderRow.Cells.Add();
            //pdfGenerator.Image objHeaderImageRight = new pdfGenerator.Image(secImg);
            //pdfGenerator.HeaderFooter objFooter = secImg.InsertFooter(pdfGenerator.HeaderFooterType.Both);
            //pdfGenerator.Image objFooterImage = new pdfGenerator.Image(secImg);

            Aspose.Pdf.HeaderFooter objHeader = new pdf.HeaderFooter();
            Aspose.Pdf.Table objHeaderTable = new pdf.Table();
            Aspose.Pdf.Row objHeaderRow = objHeaderTable.Rows.Add();
            Aspose.Pdf.Cell objHeaderTableLeftCell = objHeaderRow.Cells.Add();
            Aspose.Pdf.Cell objHeaderTableRightCell = objHeaderRow.Cells.Add();
            Aspose.Pdf.Image objHeaderImageRight = new Aspose.Pdf.Image();// secImg);
            Aspose.Pdf.HeaderFooter objFooter = new pdf.HeaderFooter();// secImg.InsertFooter(pdfGenerator.HeaderFooterType.Both);
            Aspose.Pdf.Image objFooterImage = new Aspose.Pdf.Image();// secImg);

            secImg.PageInfo.Margin.Left = 0;//PageBorderMargin.Left = 0;
            secImg.PageInfo.Margin.Right = 0;// PageBorderMargin.Right = 0;
            secImg.PageInfo.Margin.Top = 0;// PageBorderMargin.Top = 0;
            secImg.PageInfo.Width = 612;// PageWidth = 612;
            secImg.PageInfo.Height = 792;// PageHeight = 792;
                                         //secImg.IsNewPage = true;


            objHeader.Margin.Top = 50;
            objHeader.Margin.Left = 0;
            objHeader.Margin.Right = 0;
            objHeader.Margin.Bottom = 10;
            objHeader.Paragraphs.Add(objHeaderTable);
            objHeaderTable.ColumnWidths = "50% 56%";
            //objHeaderTable.DefaultCellPadding.Left = 0;
            //objHeaderTable.DefaultCellPadding.Top = 0;
            objHeaderTable.Margin.Top = 0;
            objHeaderTable.Margin.Left = 0;
            objHeaderTable.Margin.Right = 0;
            //objHeaderTableLeftCell.Margin.Left = 0;////Padding.Left = 0;
            //objHeaderTableRightCell.Margin.Left = 0;
            objHeaderImageRight.Margin.Left = 0;

            //objHeaderImageRight.ImageInfo.Alignment = pdfGenerator.AlignmentType.Right;
            //objHeaderImageRight.ImageInfo.IsImageNotFoundErrorIgnored = false;
            //objHeaderImageRight.ImageInfo.File = pdfFileName;
            //objHeaderTableRightCell.Paragraphs.Add(objHeaderImageRight);
            //objFooterImage.Left = 0;
            //objFooterImage.ImageInfo.Alignment = pdfGenerator.AlignmentType.Left;
            //objFooterImage.ImageInfo.IsImageNotFoundErrorIgnored = false;
            // objFooterImage.ImageInfo.File = pdfFileName;

            objHeaderImageRight.HorizontalAlignment = pdf.HorizontalAlignment.Right;
            objHeaderImageRight.File = pdfFileName;
            objHeaderTableRightCell.Paragraphs.Add(objHeaderImageRight);
            objFooterImage.Margin.Left = 0;
            objFooterImage.HorizontalAlignment = pdf.HorizontalAlignment.Left;
            objFooterImage.File = pdfFileName;
            objFooter.Margin.Top = 10;
            objFooter.Margin.Left = 0;
            objFooter.Margin.Right = 0;
            objFooter.Margin.Bottom = 50;
            objFooter.Paragraphs.Add(objFooterImage);
            //End of Adding Header and Footer
            //pdfGenerator.Image imgPDF = null;
            Aspose.Pdf.Image imgPDF = null;

            //pdfGenerator.Pdf secPDF = null;
            if (ext.ToLower() != "pdf" && ext != string.Empty)
            {
                objFileStream.Seek(0, SeekOrigin.Begin);
                objFileStream.Write(arrByteImageOrPdf, 0, arrByteImageOrPdf.Length);
                objFileStream.Flush();
                imgPDF = new Aspose.Pdf.Image();// secImg);
                imgPDF.ImageStream = objFileStream;
                //ImageInfo.ImageStream = objFileStream;
                System.Drawing.Image objDrawImage = null;
                try
                {
                    objDrawImage = System.Drawing.Image.FromStream(objFileStream);
                }
                catch (Exception ex)
                {
                    string strexmsg = ex.Message;
                }
                //if (objDrawImage.Width > 465)
                //{
                //    secImg.PageInfo.PageWidth = secImg.PageInfo.PageWidth + objDrawImage.Width - 465;
                //}
                //if (objDrawImage.Height > 570)
                //{
                //    secImg.PageInfo.PageHeight = secImg.PageInfo.PageHeight + (objDrawImage.Height - 570);
                //}
                if (objDrawImage.Width > secImg.PageInfo.Width)//.PageWidth)
                {
                    //imgPDF.ImageInfo.FixWidth = secImg.PageInfo.PageWidth - secImg.PageInfo.Margin.Left - secImg.PageInfo.Margin.Right;
                    //imgPDF.ImageInfo.FixHeight = secImg.PageInfo.PageHeight - secImg.PageInfo.Margin.Top - secImg.PageInfo.Margin.Bottom;
                    imgPDF.FixWidth = secImg.PageInfo.Width - secImg.PageInfo.Margin.Left - secImg.PageInfo.Margin.Right;
                    imgPDF.FixHeight = secImg.PageInfo.Height - secImg.PageInfo.Margin.Top - secImg.PageInfo.Margin.Bottom;
                }
                //
                //switch (ext.ToLower())
                //{
                //    case "jpeg":
                //    case "jpg":
                //        imgPDF.ImageInfo.ImageFileType = pdfGenerator.ImageFileType.Jpeg;
                //        break;

                //    case "bmp":
                //        imgPDF.ImageInfo.ImageFileType = pdfGenerator.ImageFileType.Bmp;
                //        break;

                //    case "gif":
                //        imgPDF.ImageInfo.ImageFileType = pdfGenerator.ImageFileType.Gif;
                //        break;

                //    case "tif":
                //    case "tiff":
                //        imgPDF.ImageInfo.ImageFileType = pdfGenerator.ImageFileType.Tiff;
                //        break;
                //}

                //imgPDF.ImageInfo.BitsPerComponent = 8;
                //imgPDF.ImageInfo.ComponentNumber = 3;
                //imgPDF.ImageInfo.TiffFrame = -1;
                //adding section to pdf
                secImg.Paragraphs.Add(imgPDF);

                objPdf.Save(msImageorPdfStream); // save to stream
            }
            else
            {
                //string outFileName;
                //= Server.MapPath("./");
                // outFileName = outFileName.Replace("ajaxpro\\", "");
                string inputFile = sinputfile;//"";// = outFileName + @"UploadImages\" + "Inputfile" + rndImageName + ".pdf";
                string outputFile = soutputfile;//"";// = outFileName + @"UploadImages\" + "Outputfile " + rndImageName + ".pdf";

                FileStream inputStream = new FileStream(inputFile, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                inputStream.Write(arrByteImageOrPdf, 0, arrByteImageOrPdf.Length);

                inputStream.Seek(0, SeekOrigin.Begin);
                pdfFacedes.PdfFileInfo objpdfFileInfo = new pdfFacedes.PdfFileInfo(inputStream);
                int NumberofPages = 0;
                //UAT Ticket :  EnvisionRxOptions - Production - Medium Incident# 41303 : Garbled information on the coversheet Sravana
                try
                {
                    NumberofPages = objpdfFileInfo.NumberOfPages;
                }
                catch// AGADIACR-3216: Global: Warning messages APR 2022 Naresh Thota 02/02/2022
                {
                    inputStream.Dispose();
                    return;
                }
                int pageHight = 0;
                int pageWidth = 0;

                if (NumberofPages > 0)
                {
                    pageHight = (int)objpdfFileInfo.GetPageHeight(1);
                    pageWidth = (int)objpdfFileInfo.GetPageWidth(1);
                }

                pdfFacedes.PdfPageEditor pageeditor = new pdfFacedes.PdfPageEditor();

                FileStream outputStream = new FileStream(outputFile, FileMode.OpenOrCreate, FileAccess.ReadWrite);

                inputStream.Seek(0, SeekOrigin.Begin);
                pdfFacedes.PdfFileMend mendor = new pdfFacedes.PdfFileMend(inputStream, outputStream);
                // pdfFacedes.PdfFileMend mendor = new pdfFacedes.PdfFileMend();
                mendor.BindPdf(inputStream);
                mendor.Save(outputStream);

                int[] pageNO = new int[NumberofPages];
                for (int i = 0; i < NumberofPages; i++)
                {
                    pageNO[i] = i + 1;
                }

                string pdffilepath = pdfFileName;
                //mendor.AddImage(@pdffilepath, pageNO, 0, 0, 50, 50);
                //mendor.AddImage(@pdffilepath, pageNO, pageWidth - 50, pageHight - 50, pageWidth, pageHight);

                mendor.AddImage(@pdffilepath, pageNO, 0, 10, 50, 50);
                mendor.AddImage(@pdffilepath, pageNO, pageWidth - 70, pageHight - 60, pageWidth, pageHight - 25);
                mendor.Close();
                outputStream.Close();

                FileStream outputStream1 = new FileStream(outputFile, FileMode.OpenOrCreate, FileAccess.ReadWrite);

                arrByteImageOrPdf = new byte[Convert.ToInt32(outputStream1.Length.ToString())];
                if (iscustomeCoverPage)
                {
                    arrByteImageOrPdf = Combine(customerCoverPage, arrByteImageOrPdf);
                }
                outputStream1.Read(arrByteImageOrPdf, 0, arrByteImageOrPdf.Length);
                outputStream1.Flush();

                //creating memory stream to hold binary data. converting Image to Pdf
                msImageorPdfStream.Seek(0, SeekOrigin.Begin);
                msImageorPdfStream.Write(arrByteImageOrPdf, 0, arrByteImageOrPdf.Length);
                msImageorPdfStream.Flush();

                inputStream.Close();
                outputStream.Close();
                outputStream1.Close();
            }
            noOfPages = objPdf.Pages.Count;//objPdf.PageCount;
        }

        public void GenerateFaxFromSupportingDocuments(string pdfFileName, string ext, byte[] arrByteImageOrPdf, bool iscustomeCoverPage, byte[] customerCoverPage,
          out MemoryStream msImageorPdfStream, out int noOfPages, PageSetupStruct pageSetupstruct, string sinputfile, string soutputfile)
        {
            MemoryStream objFileStream = new MemoryStream();
            noOfPages = 0;
            // Aspose Pdf object declaration
            msImageorPdfStream = new MemoryStream();
            //pdfGenerator.Pdf objPdf = new pdfGenerator.Pdf();
            //objPdf.PageSetup.PageHeight = pdfGenerator.PageSize.LetterHeight;
            //objPdf.PageSetup.PageWidth = pdfGenerator.PageSize.LetterWidth;
            //objPdf.PageSetup.Margin.Left = 70;
            //objPdf.PageSetup.Margin.Right = 100;
            Aspose.Pdf.Document objPdf = new Aspose.Pdf.Document();
            objPdf.PageInfo.Margin.Left = 70;
            objPdf.PageInfo.Margin.Right = 100;
            /* *

             * If we are sending image file as  fax , we have to create aspose pdf image  object.

             * If we want to send pdf as fax the we need to create pdf object.

             * */

            // Adding new section to hold fax data

            //  pdfGenerator.Section secImg = objPdf.Sections.Add();
            // Adding Header and Footer as per point 6 of issue 793
            Aspose.Pdf.Page secImg = objPdf.Pages.Add();

            // pdfGenerator.HeaderFooter objHeader = secImg.InsertHeader(pdfGenerator.HeaderFooterType.Both);
            //pdfGenerator.Table objHeaderTable = new pdfGenerator.Table();
            //pdfGenerator.Row objHeaderRow = objHeaderTable.Rows.Add();
            //pdfGenerator.Cell objHeaderTableLeftCell = objHeaderRow.Cells.Add();
            //pdfGenerator.Cell objHeaderTableRightCell = objHeaderRow.Cells.Add();
            //pdfGenerator.Image objHeaderImageRight = new pdfGenerator.Image(secImg);
            //pdfGenerator.HeaderFooter objFooter = secImg.InsertFooter(pdfGenerator.HeaderFooterType.Both);
            //pdfGenerator.Image objFooterImage = new pdfGenerator.Image(secImg);

            Aspose.Pdf.HeaderFooter objHeader = new pdf.HeaderFooter();

            Aspose.Pdf.Table objHeaderTable = new pdf.Table();
            Aspose.Pdf.Row objHeaderRow = objHeaderTable.Rows.Add();
            Aspose.Pdf.Cell objHeaderTableLeftCell = objHeaderRow.Cells.Add();
            Aspose.Pdf.Cell objHeaderTableRightCell = objHeaderRow.Cells.Add();

            Aspose.Pdf.Image objHeaderImageRight = new Aspose.Pdf.Image();//secImg);

            Aspose.Pdf.HeaderFooter objFooter = new pdf.HeaderFooter();// secImg.InsertFooter(pdfGenerator.HeaderFooterType.Both);
            Aspose.Pdf.Image objFooterImage = new Aspose.Pdf.Image();// secImg);

            secImg.PageInfo.Margin.Left = 0;//PageBorderMargin.Left = 0;
            secImg.PageInfo.Margin.Right = 0;// PageBorderMargin.Right = 0;
            secImg.PageInfo.Margin.Top = 0;// PageBorderMargin.Top = 0;
            secImg.PageInfo.Width = 612;// PageWidth = 612;
            secImg.PageInfo.Height = 792;// PageHeight = 792;

            //Aspose.Pdf.HeaderFooter objHeader = new pdf.HeaderFooter();

            //secImg.PageInfo.PageBorderMargin.Left = 0;
            //secImg.PageInfo.PageBorderMargin.Right = 0;
            //secImg.PageInfo.PageBorderMargin.Top = 0;
            //secImg.PageInfo.PageWidth = 612;
            //secImg.PageInfo.PageHeight = 792;
            //secImg.IsNewPage = true;

            objHeader.Margin.Top = 50;
            objHeader.Margin.Left = 0;
            objHeader.Margin.Right = 0;
            objHeader.Margin.Bottom = 10;
            objHeader.Paragraphs.Add(objHeaderTable);
            objHeaderTable.ColumnWidths = "50% 56%";
            //objHeaderTable.DefaultCellPadding.Left = 0;
            //objHeaderTable.DefaultCellPadding.Top = 0;
            objHeaderTable.Margin.Top = 0;
            objHeaderTable.Margin.Left = 0;
            objHeaderTable.Margin.Right = 0;
            // objHeaderTableLeftCell.Margin.Left = 0;
            // objHeaderTableRightCell.Margin.Left = 0;
            objHeaderImageRight.Margin.Left = 0;

            objHeaderImageRight.HorizontalAlignment = Aspose.Pdf.HorizontalAlignment.Right;

            // objHeaderImageRight.ImageInfo.File = pdfFileName;
            objHeaderTableRightCell.Paragraphs.Add(objHeaderImageRight);
            // objFooterImage.Margin.Left = 0;
            objFooterImage.HorizontalAlignment = Aspose.Pdf.HorizontalAlignment.Left;
            // objFooterImage.ImageInfo.IsImageNotFoundErrorIgnored = false;
            //  objFooterImage.ImageInfo.File = pdfFileName;

            objFooter.Margin.Top = 10;
            objFooter.Margin.Left = 0;
            objFooter.Margin.Right = 0;
            objFooter.Margin.Bottom = 50;
            objFooter.Paragraphs.Add(objFooterImage);
            //End of Adding Header and Footer

            //pdfGenerator.Image imgPDF = null;
            Aspose.Pdf.Image imgPDF = null;
            //pdfGenerator.Pdf secPDF = null;
            if (ext.ToLower() != "pdf" && ext != string.Empty)
            {
                objFileStream.Seek(0, SeekOrigin.Begin);
                objFileStream.Write(arrByteImageOrPdf, 0, arrByteImageOrPdf.Length);
                objFileStream.Flush();
                imgPDF = new Aspose.Pdf.Image();// secImg);
                imgPDF.ImageStream = objFileStream;
                System.Drawing.Image objDrawImage = null;
                try
                {
                    objDrawImage = System.Drawing.Image.FromStream(objFileStream);
                }
                catch (Exception ex)
                {
                    string strexmsg = ex.Message;
                }
                //if (objDrawImage.Width > 465)
                //{
                //    secImg.PageInfo.PageWidth = secImg.PageInfo.PageWidth + objDrawImage.Width - 465;
                //}
                //if (objDrawImage.Height > 570)
                //{
                //    secImg.PageInfo.PageHeight = secImg.PageInfo.PageHeight + (objDrawImage.Height - 570);
                //}
                if (objDrawImage.Width > secImg.PageInfo.Width)
                {
                    imgPDF.FixWidth = secImg.PageInfo.Width - secImg.PageInfo.Margin.Left - secImg.PageInfo.Margin.Right;
                    imgPDF.FixHeight = secImg.PageInfo.Height - secImg.PageInfo.Margin.Top - secImg.PageInfo.Margin.Bottom;
                }
                //
                //switch (ext.ToLower())
                //{
                //    case "jpeg":
                //    case "jpg":
                //        imgPDF.ImageInfo.ImageFileType = pdfGenerator.ImageFileType.Jpeg;
                //        break;

                //    case "bmp":
                //        imgPDF.ImageInfo.ImageFileType = pdfGenerator.ImageFileType.Bmp;
                //        break;

                //    case "gif":
                //        imgPDF.ImageInfo.ImageFileType = pdfGenerator.ImageFileType.Gif;
                //        break;

                //    case "tif":
                //    case "tiff":
                //        imgPDF.ImageInfo.ImageFileType = pdfGenerator.ImageFileType.Tiff;
                //        break;
                //}

                //imgPDF.ImageInfo.BitsPerComponent = 8;
                //imgPDF.ImageInfo.ComponentNumber = 3;
                //imgPDF.ImageInfo.TiffFrame = -1;

                ////adding section to pdf
                secImg.Paragraphs.Add(imgPDF);

                objPdf.Save(msImageorPdfStream); // save to stream
            }
            else
            {
                string inputFile = sinputfile;// = outFileName + @"UploadImages\" + "Inputfile" + rndImageName + ".pdf";
                string outputFile = soutputfile;// = outFileName + @"UploadImages\" + "Outputfile " + rndImageName + ".pdf";

                FileStream inputStream = new FileStream(inputFile, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                inputStream.Write(arrByteImageOrPdf, 0, arrByteImageOrPdf.Length);

                inputStream.Seek(0, SeekOrigin.Begin);
                pdfFacedes.PdfFileInfo objpdfFileInfo = new pdfFacedes.PdfFileInfo(inputStream);
                int NumberofPages = objpdfFileInfo.NumberOfPages;

                int pageHight = 0;
                int pageWidth = 0;

                if (NumberofPages > 0)
                {
                    pageHight = (int)objpdfFileInfo.GetPageHeight(1);
                    pageWidth = (int)objpdfFileInfo.GetPageWidth(1);
                }

                pdfFacedes.PdfPageEditor pageeditor = new pdfFacedes.PdfPageEditor();

                FileStream outputStream = new FileStream(outputFile, FileMode.OpenOrCreate, FileAccess.ReadWrite);

                inputStream.Seek(0, SeekOrigin.Begin);
                pdfFacedes.PdfFileMend mendor = new pdfFacedes.PdfFileMend(inputStream, outputStream);
                //pdfFacedes.PdfFileMend mendor = new pdfFacedes.PdfFileMend();
                //mendor.BindPdf(inputStream);
                //mendor.Save(outputStream);

                int[] pageNO = new int[NumberofPages];
                for (int i = 0; i < NumberofPages; i++)
                {
                    pageNO[i] = i + 1;
                }

                string pdffilepath = pdfFileName;
                //mendor.AddImage(@pdffilepath, pageNO, 0, 0, 50, 50);
                //mendor.AddImage(@pdffilepath, pageNO, pageWidth - 50, pageHight - 50, pageWidth, pageHight);

                mendor.AddImage(@pdffilepath, pageNO, 0, 10, 50, 50);
                mendor.AddImage(@pdffilepath, pageNO, pageWidth - 70, pageHight - 60, pageWidth, pageHight - 25);

                mendor.Close();
                outputStream.Close();

                FileStream outputStream1 = new FileStream(outputFile, FileMode.OpenOrCreate, FileAccess.ReadWrite);

                arrByteImageOrPdf = new byte[Convert.ToInt32(outputStream1.Length.ToString())];
                if (iscustomeCoverPage)
                {
                    arrByteImageOrPdf = Combine(customerCoverPage, arrByteImageOrPdf);
                }
                outputStream1.Read(arrByteImageOrPdf, 0, arrByteImageOrPdf.Length);
                outputStream1.Flush();

                //creating memory stream to hold binary data. converting Image to Pdf
                msImageorPdfStream.Seek(0, SeekOrigin.Begin);
                msImageorPdfStream.Write(arrByteImageOrPdf, 0, arrByteImageOrPdf.Length);
                msImageorPdfStream.Flush();

                inputStream.Close();
                outputStream.Close();
                outputStream1.Close();
            }
            //noOfPages = objPdf.PageCount;
            noOfPages = objPdf.Pages.Count;
        }

        //S.K
        public void ConverttoPDF(string ext, byte[] arrByteImageOrPdf, out MemoryStream msImageorPdfStream, out int noOfPages)
        {
            MemoryStream objFileStream = new MemoryStream();
            noOfPages = 0;
            // Aspose Pdf object declaration
            msImageorPdfStream = new MemoryStream();
            //pdfGenerator.Pdf objPdf = new pdfGenerator.Pdf();
            //objPdf.PageSetup.PageHeight = pdfGenerator.PageSize.LetterHeight;
            //objPdf.PageSetup.PageWidth = pdfGenerator.PageSize.LetterWidth;
            //objPdf.PageSetup.Margin.Left = 70;
            //objPdf.PageSetup.Margin.Right = 100;
            Aspose.Pdf.Document objPdf = new Aspose.Pdf.Document();
            objPdf.PageInfo.Margin.Left = 70;
            objPdf.PageInfo.Margin.Right = 100;
            /* *

             * If we are sending image file as  fax , we have to create aspose pdf image  object.

             * If we want to send pdf as fax the we need to create pdf object.

             * */

            // Adding new section to hold fax data

            //pdfGenerator.Section secImg = objPdf.Sections.Add();
            Aspose.Pdf.Page secImg = objPdf.Pages.Add();
            // Adding Header and Footer as per point 6 of issue 793

            //pdfGenerator.HeaderFooter objHeader = secImg.InsertHeader(pdfGenerator.HeaderFooterType.Both);
            //pdfGenerator.Table objHeaderTable = new pdfGenerator.Table();
            // pdfGenerator.Row objHeaderRow = objHeaderTable.Rows.Add();
            //pdfGenerator.Cell objHeaderTableLeftCell = objHeaderRow.Cells.Add();
            // pdfGenerator.Cell objHeaderTableRightCell = objHeaderRow.Cells.Add();
            // pdfGenerator.Image objHeaderImageRight = new pdfGenerator.Image(secImg);
            // pdfGenerator.HeaderFooter objFooter = secImg.InsertFooter(pdfGenerator.HeaderFooterType.Both);
            // pdfGenerator.Image objFooterImage = new pdfGenerator.Image(secImg);

            // secImg.PageInfo.PageBorderMargin.Left = 0;
            //secImg.PageInfo.PageBorderMargin.Right = 0;
            //secImg.PageInfo.PageBorderMargin.Top = 0;
            //secImg.PageInfo.PageWidth = 612;
            //secImg.PageInfo.PageHeight = 792;
            //secImg.IsNewPage = true;


            Aspose.Pdf.HeaderFooter objHeader = new pdf.HeaderFooter();
            Aspose.Pdf.Table objHeaderTable = new pdf.Table();
            Aspose.Pdf.Row objHeaderRow = objHeaderTable.Rows.Add();
            Aspose.Pdf.Cell objHeaderTableLeftCell = objHeaderRow.Cells.Add();
            Aspose.Pdf.Cell objHeaderTableRightCell = objHeaderRow.Cells.Add();
            Aspose.Pdf.Image objHeaderImageRight = new Aspose.Pdf.Image();//secImg);
            Aspose.Pdf.HeaderFooter objFooter = new pdf.HeaderFooter();// secImg.InsertFooter(pdfGenerator.HeaderFooterType.Both);
            Aspose.Pdf.Image objFooterImage = new Aspose.Pdf.Image();// secImg);

            secImg.PageInfo.Margin.Left = 0;//PageBorderMargin.Left = 0;
            secImg.PageInfo.Margin.Right = 0;// PageBorderMargin.Right = 0;
            secImg.PageInfo.Margin.Top = 0;// PageBorderMargin.Top = 0;
            secImg.PageInfo.Width = 612;// PageWidth = 612;
            secImg.PageInfo.Height = 792;// PageHeight = 792;

            objHeader.Margin.Top = 50;
            objHeader.Margin.Left = 0;
            objHeader.Margin.Right = 0;
            objHeader.Margin.Bottom = 10;
            objHeader.Paragraphs.Add(objHeaderTable);
            objHeaderTable.ColumnWidths = "50% 56%";
            objHeaderTable.DefaultCellPadding.Left = 0;
            objHeaderTable.DefaultCellPadding.Top = 0;
            objHeaderTable.Margin.Top = 0;
            objHeaderTable.Margin.Left = 0;
            objHeaderTable.Margin.Right = 0;
            // objHeaderTableLeftCell.Padding.Left = 0;
            //objHeaderTableRightCell.Padding.Left = 0;
            objHeaderImageRight.Margin.Left = 0;//Left = 0;

            //objHeaderImageRight.ImageInfo.Alignment = pdfGenerator.AlignmentType.Right;
            //objHeaderImageRight.ImageInfo.IsImageNotFoundErrorIgnored = false;
            // objHeaderImageRight.ImageInfo.File = pdfFileName;
            objHeaderImageRight.HorizontalAlignment = pdf.HorizontalAlignment.Right;
            objHeaderTableRightCell.Paragraphs.Add(objHeaderImageRight);
            objFooterImage.Margin.Left = 0;
            //objFooterImage.ImageInfo.Alignment = pdfGenerator.AlignmentType.Left;
            //objFooterImage.ImageInfo.IsImageNotFoundErrorIgnored = false;
            objFooterImage.HorizontalAlignment = pdf.HorizontalAlignment.Left;
            //  objFooterImage.ImageInfo.File = pdfFileName;

            objFooter.Margin.Top = 10;
            objFooter.Margin.Left = 0;
            objFooter.Margin.Right = 0;
            objFooter.Margin.Bottom = 50;
            objFooter.Paragraphs.Add(objFooterImage);
            //End of Adding Header and Footer

            //  pdfGenerator.Image imgPDF = null;
            Aspose.Pdf.Image imgPDF = null;
            //pdfGenerator.Pdf secPDF = null;
            if (ext.ToLower() != "pdf" && ext != string.Empty)
            {
                objFileStream.Seek(0, SeekOrigin.Begin);
                objFileStream.Write(arrByteImageOrPdf, 0, arrByteImageOrPdf.Length);
                objFileStream.Flush();
                imgPDF = new Aspose.Pdf.Image(); //pdfGenerator.Image(secImg);
                                                 //imgPDF.ImageInfo.ImageStream = objFileStream;
                imgPDF.ImageStream = objFileStream;
                System.Drawing.Image objDrawImage = null;
                try
                {
                    objDrawImage = System.Drawing.Image.FromStream(objFileStream);
                }
                catch (Exception ex)
                {
                    string strexmsg = ex.Message;
                }
                //if (objDrawImage.Width > 465)
                //{
                //    secImg.PageInfo.PageWidth = secImg.PageInfo.PageWidth + objDrawImage.Width - 465;
                //}
                //if (objDrawImage.Height > 570)
                //{
                //    secImg.PageInfo.PageHeight = secImg.PageInfo.PageHeight + (objDrawImage.Height - 570);
                //}
                if (objDrawImage.Width > secImg.PageInfo.Width)
                {
                    imgPDF.FixWidth = secImg.PageInfo.Width - secImg.PageInfo.Margin.Left - secImg.PageInfo.Margin.Right;
                    imgPDF.FixHeight = secImg.PageInfo.Height - secImg.PageInfo.Margin.Top - secImg.PageInfo.Margin.Bottom;
                }
                //if (objDrawImage.Width > secImg.PageInfo.PageWidth)
                //{
                //    imgPDF.ImageInfo.FixWidth = secImg.PageInfo.PageWidth - secImg.PageInfo.Margin.Left - secImg.PageInfo.Margin.Right;
                //    imgPDF.ImageInfo.FixHeight = secImg.PageInfo.PageHeight - secImg.PageInfo.Margin.Top - secImg.PageInfo.Margin.Bottom;
                //}
                ////
                //switch (ext.ToLower())
                //{
                //    case "jpeg":
                //    case "jpg":
                //        imgPDF.ImageInfo.ImageFileType = pdfGenerator.ImageFileType.Jpeg;
                //        break;

                //    case "bmp":
                //        imgPDF.ImageInfo.ImageFileType = pdfGenerator.ImageFileType.Bmp;
                //        break;

                //    case "gif":
                //        imgPDF.ImageInfo.ImageFileType = pdfGenerator.ImageFileType.Gif;
                //        break;

                //    case "tif":
                //    case "tiff":
                //        imgPDF.ImageInfo.ImageFileType = pdfGenerator.ImageFileType.Tiff;
                //        break;
                //}

                //imgPDF.ImageInfo.BitsPerComponent = 8;
                //imgPDF.ImageInfo.ComponentNumber = 3;
                //imgPDF.ImageInfo.TiffFrame = -1;
                //adding section to pdf
                secImg.Paragraphs.Add(imgPDF);

                objPdf.Save(msImageorPdfStream); // save to stream
            }

            //noOfPages = objPdf.PageCount;
            noOfPages = objPdf.Pages.Count;// PageCount;
        }

        public MemoryStream GenerateStreamFromXML(XmlDocument xmlDoc, PageSetupStruct pageSetup)
        {
            MemoryStream msCCform = new MemoryStream();
            //pdfGenerator.Pdf objPdf = new pdfGenerator.Pdf();
            //if (pageSetup.SetPageHeight)
            //    objPdf.PageSetup.PageHeight = pdfGenerator.PageSize.LetterHeight;
            //if (pageSetup.SetPageWidth)
            //    objPdf.PageSetup.PageWidth = pdfGenerator.PageSize.LetterWidth;
            //if (pageSetup.SetMarginLeft)
            //    objPdf.PageSetup.Margin.Left = 70;
            //if (pageSetup.SetMarginRight)
            //    objPdf.PageSetup.Margin.Right = 100;
            //objPdf.BindXML(xmlDoc, null);
            Aspose.Pdf.Document objPdf = new Aspose.Pdf.Document();
            objPdf.BindXml(xmlDoc.ToString(), null);
            objPdf.Save(msCCform);

            return msCCform;
        }

        public string[] GetDocFieldName(Stream WordStream)
        {
            srcDoc = new word.Document(WordStream);
            return srcDoc.MailMerge.GetFieldNames();
        }

        public string[] GetDocFieldName()
        {
            return srcDoc.MailMerge.GetFieldNames();
        }

        public AsposeService getInstance(bool isProduction)
        {
            lock (lockThis)
            {
                if (instance == null)
                    instance = new AsposeService(isProduction);

                return instance;
            }
        }

        public string[] GetMailMergeFields(Stream wordStream, out object wordDoc)
        {
            word.Document srcDoc = new word.Document(wordStream);
            string[] strFiledNames = srcDoc.MailMerge.GetFieldNames();
            wordDoc = srcDoc;
            return strFiledNames;
        }

        public int GetPDFFileInfoWidthHeight(ref int pageWidth, ref int pageHight, FileStream fileInputStream)
        {
            pdfFacedes.PdfFileInfo objpdfFileInfo = new pdfFacedes.PdfFileInfo(fileInputStream);

            int NumberofPages = objpdfFileInfo.NumberOfPages;
            //int pageHight = 0;
            //int pageWidth = 0;

            if (NumberofPages > 0)
            {
                pageHight = (int)objpdfFileInfo.GetPageHeight(1);
                pageWidth = (int)objpdfFileInfo.GetPageWidth(1);
            }
            return NumberofPages;
        }

        public void HoldFaxData(string barImagePath)
        {
            //pdfGenerator.Pdf objPdf = new pdfGenerator.Pdf();
            //objPdf.PageSetup.PageHeight = pdfGenerator.PageSize.LetterHeight;
            //objPdf.PageSetup.PageWidth = pdfGenerator.PageSize.LetterWidth;
            //objPdf.PageSetup.Margin.Left = 70;
            //objPdf.PageSetup.Margin.Right = 100;


            // pdfGenerator.Section secImg = objPdf.Sections.Add();

            // Adding Header and Footer as per point 6 of issue 793
            //pdfGenerator.HeaderFooter objHeader = secImg.InsertHeader(pdfGenerator.HeaderFooterType.Both);
            //pdfGenerator.Table objHeaderTable = new pdfGenerator.Table();
            //pdfGenerator.Row objHeaderRow = objHeaderTable.Rows.Add();
            //pdfGenerator.Cell objHeaderTableLeftCell = objHeaderRow.Cells.Add();
            //pdfGenerator.Cell objHeaderTableRightCell = objHeaderRow.Cells.Add();
            //pdfGenerator.Image objHeaderImageRight = new pdfGenerator.Image(secImg);
            //pdfGenerator.HeaderFooter objFooter = secImg.InsertFooter(pdfGenerator.HeaderFooterType.Both);
            //pdfGenerator.Image objFooterImage = new pdfGenerator.Image(secImg);

            //secImg.PageInfo.PageBorderMargin.Left = 0;
            //secImg.PageInfo.PageBorderMargin.Right = 0;
            //secImg.PageInfo.PageBorderMargin.Top = 0;
            //secImg.PageInfo.PageWidth = 612;
            //secImg.PageInfo.PageHeight = 792;
            //secImg.IsNewPage = true;

            Aspose.Pdf.Document objPdf = new pdf.Document();
            objPdf.PageInfo.Margin.Left = 70;
            objPdf.PageInfo.Margin.Right = 100;
            Aspose.Pdf.Page secImg = objPdf.Pages.Add();

            Aspose.Pdf.HeaderFooter objHeader = new pdf.HeaderFooter(); //secImg.InsertHeader(Aspose.Pdf.HeaderFooterType.Both);
            Aspose.Pdf.Table objHeaderTable = new Aspose.Pdf.Table();
            Aspose.Pdf.Row objHeaderRow = objHeaderTable.Rows.Add();
            Aspose.Pdf.Cell objHeaderTableLeftCell = objHeaderRow.Cells.Add();
            Aspose.Pdf.Cell objHeaderTableRightCell = objHeaderRow.Cells.Add();
            Aspose.Pdf.Image objHeaderImageRight = new pdf.Image();// Aspose.Pdf.Image(secImg);

            Aspose.Pdf.HeaderFooter objFooter = new pdf.HeaderFooter();//secImg.InsertFooter(pdfGenerator.HeaderFooterType.Both);
            Aspose.Pdf.Image objFooterImage = new Aspose.Pdf.Image();// secImg);

            secImg.PageInfo.Margin.Left = 0;
            secImg.PageInfo.Margin.Right = 0;
            secImg.PageInfo.Margin.Top = 0;
            secImg.PageInfo.Width = 612;
            secImg.PageInfo.Height = 792;


            objHeader.Margin.Top = 50;
            objHeader.Margin.Left = 0;
            objHeader.Margin.Right = 0;
            objHeader.Margin.Bottom = 50;
            objHeader.Paragraphs.Add(objHeaderTable);
            objHeaderTable.ColumnWidths = "50% 56%";
            //objHeaderTable.DefaultCellPadding.Left = 0;
            //objHeaderTable.DefaultCellPadding.Top = 0;
            objHeaderTable.Margin.Top = 0;
            objHeaderTable.Margin.Left = 0;
            objHeaderTable.Margin.Right = 0;
            //objHeaderTableLeftCell.Padding.Left = 0;
            //objHeaderTableRightCell.Padding.Left = 0;
            //objHeaderImageRight.Left = 0;

            //objHeaderImageRight.ImageInfo.Alignment = pdfGenerator.AlignmentType.Right;
            //objHeaderImageRight.ImageInfo.IsImageNotFoundErrorIgnored = false;
            //objHeaderImageRight.ImageInfo.File = barImagePath;// Session["pdffilename"].ToString();
            //objHeaderTableRightCell.Paragraphs.Add(objHeaderImageRight);
            //objFooterImage.Left = 0;
            //objFooterImage.ImageInfo.Alignment = pdfGenerator.AlignmentType.Left;
            //objFooterImage.ImageInfo.IsImageNotFoundErrorIgnored = false;
            //objFooterImage.ImageInfo.File = barImagePath;// Session["pdffilename"].ToString();


            //objHeaderTableLeftCell.Margin.Left = 0;
            //objHeaderTableRightCell.Margin.Left = 0;

            objHeaderImageRight.HorizontalAlignment = Aspose.Pdf.HorizontalAlignment.Right;
            objHeaderImageRight.File = barImagePath;// Session["pdffilename"].ToString();
            objHeaderTableRightCell.Paragraphs.Add(objHeaderImageRight);

            objFooterImage.HorizontalAlignment = Aspose.Pdf.HorizontalAlignment.Left;
            objFooterImage.File = barImagePath;

            objFooter.Margin.Top = 10;
            objFooter.Margin.Left = 0;
            objFooter.Margin.Right = 0;
            objFooter.Margin.Bottom = 50;
            objFooter.Paragraphs.Add(objFooterImage);
            //End of Adding Header and Footer

            // pdfGenerator.Image imgPDF = null;
            //pdfGenerator.Pdf secPDF = null;
        }

        public MemoryStream MergePDF(MemoryStream msFirst, MemoryStream msSecond)
        {
            MemoryStream msFinal = new MemoryStream();
            try
            {
                //Aspose.Pdf.Document doc = new Aspose.Pdf.Document(msFirst);

                //doc.Save(msSecond);
                pdfFacedes.PdfFileEditor pdfEditor;
                try
                {
                    pdfEditor = new pdfFacedes.PdfFileEditor();
                    pdfEditor.Concatenate(msFirst, msSecond, msFinal);
                }
                catch (Exception ex)
                {
                    //_logger.Error(ex, "Error while merging PDF in MergePDF");
                    throw;
                }
                finally
                {
                    pdfEditor = null;
                }
            }
            catch (Exception ex)
            {
                string str = ex.Message;
            }
            return msFinal;
        }

        public MemoryStream MergePDF(Stream msFirst, Stream msSecond)
        {
            MemoryStream msFinal = new MemoryStream();
            try
            {
                pdfFacedes.PdfFileEditor pdfEditor;
                try
                {
                    pdfEditor = new pdfFacedes.PdfFileEditor();
                    pdfEditor.Concatenate(msFirst, msSecond, msFinal);
                }
                catch (Exception ex)
                {
                    throw;
                }
                finally
                {
                    pdfEditor = null;
                }
            }
            catch (Exception ex)
            {
                string str = ex.Message;
            }
            return msFinal;
        }

        public void OpenPDFusingPDFViewer(string filePath, byte[] document, ref int iPrimaryPDF)
        {
        PrimaryPDF:
            using (FileStream fs = new FileStream(filePath, FileMode.Create, FileAccess.ReadWrite))
            {
                using (BinaryWriter bw = new BinaryWriter(fs))
                {
                    bw.Write(document);
                    bw.Close();
                    fs.Close();
                }
            }
            //Code to validate that file is saved successfully without any corruption
            //if found currupted or not saved successfully then retry saving upto 3 times
            if (File.Exists(filePath))
            {
                pdfFacedes.PdfViewer pdfv = new pdfFacedes.PdfViewer();
                try
                {
                    pdfv.BindPdf(filePath);
                    //pdfv.OpenPdfFile(filePath);
                }
                catch (Exception)
                {
                    iPrimaryPDF++;

                    if (iPrimaryPDF > 3)
                    {
                        //throw new Exception("Saving PDF file Failed. " + strFilePath + strFileName + docExtension);
                    }
                    else
                    {
                        try
                        {
                            pdfv.Close();
                        }
                        catch (Exception exx) { string s = exx.Message; }
                        pdfv = null;
                        goto PrimaryPDF;
                    }
                }
                finally
                {
                    try
                    {
                        pdfv.Close();
                    }
                    catch (Exception exx) { string s = exx.Message; }
                    pdfv = null;
                }
            }
            else
            {
                iPrimaryPDF++;
                if (iPrimaryPDF > 2)
                {
                    throw new Exception("Saving PDF file Failed. " + filePath);
                }
                else
                {
                    goto PrimaryPDF;
                }
            }
        }

        public int PageCount(MemoryStream inputStream)
        {
            inputStream.Position = 0;

            pdfFacedes.PdfFileInfo objFileInfo = new pdfFacedes.PdfFileInfo(inputStream);
            return objFileInfo.NumberOfPages;
        }

        public int PageCount(string FilePath)
        {
            pdfFacedes.PdfFileInfo objFileInfo = new pdfFacedes.PdfFileInfo(FilePath);
            return objFileInfo.NumberOfPages;
        }

        public string PDFFilEditorOperation(MemoryStream ms, int[] PageNo, out byte[] byte_SplitDoc, out byte[] byte_RemainingDoc)
        {
            pdfFacedes.PdfFileEditor objPdfFileEditor = new pdfFacedes.PdfFileEditor();

            MemoryStream outStream = new MemoryStream();
            objPdfFileEditor.Extract(ms, PageNo, outStream);
            byte_SplitDoc = outStream.GetBuffer();
            MemoryStream msRemainingDocument = new MemoryStream();
            objPdfFileEditor.Delete(ms, PageNo, msRemainingDocument);
            byte_RemainingDoc = new byte[msRemainingDocument.Length];
            byte_RemainingDoc = msRemainingDocument.GetBuffer();
            return objPdfFileEditor.SplitToPages(msRemainingDocument).Length.ToString();
        }

        /// <summary>
        /// Method will extract pages from pdf
        /// </summary>
        /// <param name="ms">Source memory stream</param>
        /// <param name="PageNo">Page nos to split</param>
        /// <param name="byte_SplitDoc">byte array of split pages</param>
        /// <param name="byte_RemainingDoc">byte array of remaining pages</param>
        /// <param name="remainingPageNo">remaining page nos</param>
        /// <returns></returns>
        public string PDFFilEditorOperation(MemoryStream ms, int[] PageNo, out byte[] byte_SplitDoc, out byte[] byte_RemainingDoc, int[] remainingPageNo)
        {
            string returnValue = "";
            try
            {
                pdfFacedes.PdfFileEditor objPdfFileEditor = new pdfFacedes.PdfFileEditor();
                objPdfFileEditor.AllowConcatenateExceptions = true;
                MemoryStream outStream = new MemoryStream();
                objPdfFileEditor.Extract(ms, PageNo, outStream);
                byte_SplitDoc = outStream.GetBuffer();
                MemoryStream msRemainingDocument = new MemoryStream();
                //objPdfFileEditor.Delete(ms, PageNo, msRemainingDocument);
                objPdfFileEditor.Extract(ms, remainingPageNo, msRemainingDocument);
                byte_RemainingDoc = new byte[msRemainingDocument.Length];
                byte_RemainingDoc = msRemainingDocument.GetBuffer();
                returnValue = objPdfFileEditor.SplitToPages(msRemainingDocument).Length.ToString();

                if (objPdfFileEditor.LastException != null)
                {
                    throw objPdfFileEditor.LastException;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return returnValue;
        }

        public MemoryStream PDFFileEditorConcatenate(Stream[] inStreamsArray, MemoryStream outFileStream)
        {
            //Aspose.Pdf.Document doc = new Aspose.Pdf.Document(inStreamsArray[0]);
            //doc.Save(outFileStream);
            try
            {
                pdfFacedes.PdfFileEditor objPdfFileEditor = new pdfFacedes.PdfFileEditor();
                objPdfFileEditor.Concatenate(inStreamsArray, outFileStream);

                pdf.Document doc = new pdf.Document(outFileStream);
                doc.OpenAction = null;
                doc.Save();
                //outFileStream.Position = 0;
                return outFileStream;
            }
            catch(Exception)
            {
                throw;
            }
        }

        public void PDFFileMendAddImage(FileStream inputStream, FileStream outputStream, string pdffilepath, int[] pageNO, int pageWidth, int pageHight)
        {
            pdfFacedes.PdfPageEditor pageeditor = new pdfFacedes.PdfPageEditor();
            pdfFacedes.PdfFileMend mendor = new pdfFacedes.PdfFileMend(inputStream, outputStream);
            //pdfFacedes.PdfFileMend mendor = new pdfFacedes.PdfFileMend();
            //mendor.BindPdf(inputStream);
            //mendor.Save(outputStream);
            mendor.AddImage(@pdffilepath, pageNO, 0, 10, 50, 50);
            mendor.AddImage(@pdffilepath, pageNO, pageWidth - 70, pageHight - 60, pageWidth, pageHight - 25);
            mendor.Close();
        }

        public void PDFFileSave(float width, float Height, MemoryStream memoryStream, string imagelocation)
        {
            //pdfGenerator.Pdf pdfFile = new pdfGenerator.Pdf();
            //pdfGenerator.Section section = new pdfGenerator.Section(pdfFile);
            pdf.Document pdfFile = new pdf.Document();
            pdf.Page section = pdfFile.Pages.Add();

            // Set margins so image will fit
            section.PageInfo.Margin.Top = 5;
            section.PageInfo.Margin.Bottom = 5;
            section.PageInfo.Margin.Left = 5;
            section.PageInfo.Margin.Right = 5;
            section.PageInfo.Width = width;
            section.PageInfo.Height = Height;
            if (section.PageInfo.Height < 1000)
                section.PageInfo.Height = 1200;
            //section.PageInfo.PageWidth = (bitmapImg.Width / bitmapImg.HorizontalResolution) * 90;
            //section.PageInfo.PageHeight = (bitmapImg.Height / bitmapImg.VerticalResolution) * 95;

            //Add the section in the sections collection of the Pdf document
            //pdfFile.Sections.Add(section);
            pdfFile.Pages.Add(section);
            //Create an image object
            //pdfGenerator.Image image = new pdfGenerator.Image(section);
            Aspose.Pdf.Image image = new pdf.Image();

            //Add the image into paragraphs collection of the section
            section.Paragraphs.Add(image);
            //image.ImageInfo.ImageFileType = pdfGenerator.ImageFileType.Tiff;
            image.FileType = pdf.ImageFileType.Unknown;// Tiff;
                                                       // set IsBlackWhite property to true for performance improvement
                                                       //image.ImageInfo.IsBlackWhite = true;
                                                       //Set the ImageStream to a MemoryStream object
                                                       // image.ImageInfo.ImageStream = memoryStream;
            image.ImageStream = memoryStream;
            //Set desired image scale
            //image.ImageScale = 0.95F;
            //image.ImageInfo.IsAllFramesInNewPage = true;
            //image.ImageInfo.TiffFrame = -1;
            image.IsInNewPage = true;
            //imageLocation = strPath + rndImageName + ".pdf";
            pdfFile.Save(imagelocation);
        }

        public MemoryStream SaveDocument(MemoryStream streamData, Format fileFormat)
        {
            try
            {
                MemoryStream outputStreamData = new MemoryStream();
                if (srcDoc == null)
                    srcDoc = new word.Document(streamData);
                //srcDoc.Save(outputStreamData, Aspose.Words.SaveFormat.Pdf);
                srcDoc.Save(outputStreamData, (word.SaveFormat)fileFormat);
                return outputStreamData;
                //if (srcDoc == null)
                //    srcDoc = new word.Document(streamData);
                //srcDoc.Save(streamData, Aspose.Words.SaveFormat.Pdf);
            }
            catch (OutOfMemoryException ex)
            {
                //_logger.Error(ex, "Error in SaveDocument");
                throw new Exception("Error in SaveDocument");
            }
        }

        public MemoryStream SaveWordDocument(MemoryStream streamData)
        {
            try
            {
                MemoryStream outputStreamData = new MemoryStream();
                if (srcDoc == null)
                    srcDoc = new word.Document(streamData);
                //srcDoc.Save(outputStreamData, Aspose.Words.SaveFormat.Pdf);
                srcDoc.Save(outputStreamData, word.SaveFormat.Docx);
                return outputStreamData;
                //if (srcDoc == null)
                //    srcDoc = new word.Document(streamData);
                //srcDoc.Save(streamData, Aspose.Words.SaveFormat.Pdf);
            }
            catch (OutOfMemoryException ex)
            {
                //_logger.Error(ex, "Error in SaveDocument");
                throw new Exception("Error in SaveDocument");
            }
        }

        public MemoryStream SavePDFDocument(MemoryStream streamData)
        {
            try
            {
                MemoryStream outputStreamData = new MemoryStream();
                if (srcDoc == null)
                    srcDoc = new word.Document(streamData);
                //srcDoc.Save(outputStreamData, Aspose.Words.SaveFormat.Pdf);
                //VA: Need geberuc saveFormat
                srcDoc.Save(outputStreamData, word.SaveFormat.Pdf);
                return outputStreamData;
                //if (srcDoc == null)
                //    srcDoc = new word.Document(streamData);
                //srcDoc.Save(streamData, Aspose.Words.SaveFormat.Pdf);
            }
            catch (OutOfMemoryException ex)
            {
                //_logger.Error(ex, "Error in SaveDocument");
                throw new Exception("Error in SaveDocument");
            }
        }

        public void SaveNewPdf(MemoryStream inMemoryStream, System.Drawing.Image objDrawImage, string ext, MemoryStream ms3)
        {
            try
            {
                //pdfGenerator.Image imgPDF = null;
                //pdfGenerator.Pdf newobjPdf = new pdfGenerator.Pdf();
                //pdfGenerator.Section secImg = newobjPdf.Sections.Add();

                //imgPDF = new pdfGenerator.Image(secImg);
                //imgPDF.ImageInfo.ImageStream = inMemoryStream;
                Aspose.Pdf.Document newobjPdf = new Aspose.Pdf.Document();
                Aspose.Pdf.Page secImg = newobjPdf.Pages.Add();
                // Set margins so image will fit

                //  System.Drawing.Bitmap Bitmap = new System.Drawing.Bitmap(inMemoryStream);
                Aspose.Pdf.Image imgPDF = new Aspose.Pdf.Image();
                //UAT#26557 Kalyan 25-Jan-2022 Assign the MemoryStream
                imgPDF.ImageStream = inMemoryStream;
                //if (objDrawImage.Width > 465)
                //{
                //    secImg.PageInfo.PageWidth = secImg.PageInfo.PageWidth + objDrawImage.Width - 465;
                //}
                //if (objDrawImage.Height > 570)
                //{
                //    secImg.PageInfo.PageHeight = secImg.PageInfo.PageHeight + (objDrawImage.Height - 570);
                //}
                //secImg.IsLandscape = false;
                if (objDrawImage.Width > secImg.PageInfo.Width)//PageWidth)
                {
                    //secImg.IsLandscape = true;
                    //imgPDF.ImageInfo.FixWidth = secImg.PageInfo.PageWidth - secImg.PageInfo.Margin.Left - secImg.PageInfo.Margin.Right;
                    imgPDF.FixWidth = secImg.PageInfo.Width - secImg.PageInfo.Margin.Left - secImg.PageInfo.Margin.Right;
                }
                if (objDrawImage.Height > secImg.PageInfo.Height)//PageHeight)
                {
                    //imgPDF.ImageInfo.FixHeight = secImg.PageInfo.PageHeight - secImg.PageInfo.Margin.Top - secImg.PageInfo.Margin.Bottom;
                    imgPDF.FixHeight = secImg.PageInfo.Height - secImg.PageInfo.Margin.Top - secImg.PageInfo.Margin.Bottom;
                }

                //switch (ext.ToLower())
                //{
                //    case "jpeg":
                //    case "jpg":
                //        imgPDF.ImageInfo.ImageFileType = pdfGenerator.ImageFileType.Jpeg;
                //        break;

                //    case "bmp":
                //        imgPDF.ImageInfo.ImageFileType = pdfGenerator.ImageFileType.Bmp;
                //        break;

                //    case "gif":
                //        imgPDF.ImageInfo.ImageFileType = pdfGenerator.ImageFileType.Gif;
                //        break;

                //    case "tif":
                //    case "tiff":
                //        imgPDF.ImageInfo.ImageFileType = pdfGenerator.ImageFileType.Tiff;
                //        break;
                //}
                //imgPDF.ImageInfo.BitsPerComponent = 8;
                //imgPDF.ImageInfo.ComponentNumber = 3;
                //imgPDF.ImageInfo.TiffFrame = -1;
                //adding section to pdf
                secImg.Paragraphs.Add(imgPDF);

                newobjPdf.Save(ms3);
            }
            catch(Exception ex)
            {
                throw;
            }
        }

        public void SavePDf(XmlDocument xmlDoc, MemoryStream mStrTempFullreport)
        {
            //pdfGenerator.Pdf objCoverPdf = new pdfGenerator.Pdf();
            //objCoverPdf.PageSetup.Margin.Left = 0;
            //objCoverPdf.PageSetup.Margin.Right = 0;
            //objCoverPdf.BindXML(xmlDoc, null);
            //objCoverPdf.Save(mStrTempFullreport);

        }

        public void SaveToLetterPrintingTable(string Path, byte[] Document)
        {
            int iPrimaryPDF = 0;
        //Store the PDF letter to SAN
        PrimaryPDF:
            using (FileStream fs = new FileStream(Path, FileMode.Create, FileAccess.ReadWrite))
            {
                using (BinaryWriter bw = new BinaryWriter(fs))
                {
                    bw.Write(Document);
                    bw.Close();
                    fs.Close();
                }
            }
            //Code to validate that file is saved successfully without any corruption
            //if found currupted or not saved successfully then retry saving upto 3 times
            if (File.Exists(Path))
            {
                pdfFacedes.PdfViewer pdfv = new pdfFacedes.PdfViewer();
                try
                {
                    pdfv.BindPdf(Path);
                    // pdfv.OpenPdfFile(Path);
                }
                catch (Exception)
                {
                    iPrimaryPDF++;

                    if (iPrimaryPDF > 3)
                    {
                        //throw new Exception("Saving PDF file Failed. " + strFilePath + strFileName + docExtension);
                    }
                    else
                    {
                        try
                        {
                            pdfv.Close();
                        }
                        catch (Exception exx) { string s = exx.Message; }
                        pdfv = null;
                        goto PrimaryPDF;
                    }
                }
                finally
                {
                    try
                    {
                        pdfv.Close();
                    }
                    catch (Exception exx) { string s = exx.Message; }
                    pdfv = null;
                }
            }
            else
            {
                iPrimaryPDF++;
                if (iPrimaryPDF > 2)
                {
                    throw new Exception("Saving PDF file Failed. " + Path);
                }
                else
                {
                    goto PrimaryPDF;
                }
            }
        }

        public MemoryStream SaveWordtoPdf(object wordDoc)
        {
            MemoryStream msCoverStream = new MemoryStream();
            word.Document srcDoc = wordDoc as word.Document;
            if (srcDoc != null)
                srcDoc.Save(msCoverStream, word.SaveFormat.Pdf);
            return msCoverStream;
        }

        public void SendFax()
        {
            // Aspose Pdf object declaration

            //pdfGenerator.Pdf objPdf = new pdfGenerator.Pdf();
            //objPdf.PageSetup.PageHeight = pdfGenerator.PageSize.LetterHeight;
            //objPdf.PageSetup.PageWidth = pdfGenerator.PageSize.LetterWidth;
            //objPdf.PageSetup.Margin.Left = 70;
            //objPdf.PageSetup.Margin.Right = 100;
            Aspose.Pdf.Document objPdf = new Aspose.Pdf.Document();
            objPdf.PageInfo.Margin.Left = 70;
            objPdf.PageInfo.Margin.Right = 100;
        }

        public void setDocumentObject(MemoryStream objMemoryStream)
        {
            srcDoc = new word.Document(objMemoryStream);
        }

        public void setDocumentObject(Stream objStream)
        {
            srcDoc = new word.Document(objStream);
        }

        public void setDocumentObject(string filePath)
        {
            srcDoc = new word.Document(filePath);
        }

        public void BindHTMLfromURL(string URL)
        {
            //pdfGenerator.Pdf objPdf = new pdfGenerator.Pdf();
            //objPdf.PageSetup.PageHeight = pdfGenerator.PageSize.LetterHeight;
            //objPdf.PageSetup.PageWidth = pdfGenerator.PageSize.LetterWidth;
            //objPdf.BindHTML("", URL);
            pdf.HtmlLoadOptions options = new pdf.HtmlLoadOptions(URL);
            pdf.Document objPdf = new pdf.Document("", options);
        }
        //CR#AGADIACR-647 July 2019 Sasidhar.K Generic method HTML to PDF
        public byte[] ConvertHTMLToPDF(Stream htmlStream, string basePath)
        {
            MemoryStream pdfStream = new MemoryStream();
            //pdfGenerator.Pdf objPdf = new pdfGenerator.Pdf();
            //objPdf.PageSetup.PageHeight = pdfGenerator.PageSize.LetterHeight;
            //objPdf.PageSetup.PageWidth = pdfGenerator.PageSize.LetterWidth;
            pdf.Document objPdf = new pdf.Document(htmlStream);
            objPdf.Save(pdfStream);

            //objPdf.BindHTML(htmlStream, basePath);
            //objPdf.Save(pdfStream);
            return pdfStream.ToArray();
        }
        public void SavePDf(string FilePath)
        {
            // pdfGenerator.Pdf objPdf = new pdfGenerator.Pdf();
            pdf.Document objPdf = new pdf.Document();
            objPdf.Save(FilePath);
        }

        //RR - Fix code if needed
        //public void SavePDfWithResponse(string pdffilename, HttpResponse CurrentResponse)
        //{
        //    // pdfGenerator.Pdf objPdf = new pdfGenerator.Pdf();
        //    //objPdf.Save(pdffilename, pdfGenerator.SaveType.OpenInBrowser, CurrentResponse);
        //    pdf.Document objPdf = new pdf.Document();
        //    objPdf.Save(CurrentResponse, pdffilename, pdf.ContentDisposition.Inline, null);
        //}

        public void SavePDFFileEditor(string filePath, int Rotationvalue, int[] PageNo, string filePathnew)
        {
            pdfFacedes.PdfPageEditor pdfpg = new pdfFacedes.PdfPageEditor();
            pdfpg.BindPdf(filePath);
            pdfpg.Rotation = Rotationvalue;
            pdfpg.ProcessPages = PageNo;
            string fileNamenew = "Rotated" + Guid.NewGuid().ToString() + ".PDF";
            pdfpg.Save(filePathnew);
        }

        private byte[] Combine(byte[] a, byte[] b)
        {
            //byte[] c = new byte[a.Length + b.Length];
            //System.Buffer.BlockCopy(a, 0, c, 0, a.Length);
            //System.Buffer.BlockCopy(b, 0, c, a.Length, b.Length);
            //return c;

            int newSize = a.Length + b.Length;
            MemoryStream ms = new MemoryStream(new byte[newSize], 0, newSize, true, true);
            ms.Write(a, 0, a.Length);
            ms.Write(b, 0, b.Length);
            byte[] merged = ms.GetBuffer();
            return merged;
        }

        //RR - TODO: Find the way to insert the image to the document using another method other than system.drawing whic is not supported
        public Byte[] VerifyDocExtension(string ext, MemoryStream memoryStream, Byte[] byte_img, String uploadImagePath)
        {
            string strPath = string.Empty;
            string rndImageName = string.Empty;
            //#67560 Veruva
            if (ext.ToLower() == "tif" || ext.ToLower() == "tiff")
            {
                try
                {
                    Aspose.Pdf.Document pdfDoc = new Aspose.Pdf.Document(memoryStream);
                    double Width = pdfDoc.PageInfo.Width;
                    double Height = pdfDoc.PageInfo.Height;
                    ext = "pdf";
                }
                catch
                {

                }
            }

            if (ext.ToLower() != "pdf" && ext != string.Empty)
            {
                string imageLocation = string.Empty;
                string imageLocation_jpg = string.Empty;
                //  Aspose.Pdf.Generator.Pdf pdfFile = new Aspose.Pdf.Generator.Pdf();
                Aspose.Pdf.Document pdfFile = new Aspose.Pdf.Document();
                try
                {
                    // strPath = ConfigurationManager.AppSettings["UploadImagesPath"].ToString();
                    strPath = uploadImagePath;
                    rndImageName = System.IO.Path.GetRandomFileName();
                    System.Drawing.Bitmap bitmapImg = new System.Drawing.Bitmap(memoryStream);
                    //Aspose.Pdf.Generator.Section section = new Aspose.Pdf.Generator.Section(pdfFile);
                    Aspose.Pdf.Page section = pdfFile.Pages.Add();

                    // Set margins so image will fit
                    section.PageInfo.Margin.Top = 5;
                    section.PageInfo.Margin.Bottom = 5;
                    section.PageInfo.Margin.Left = 5;
                    section.PageInfo.Margin.Right = 5;
                    //section.PageInfo.PageWidth = bitmapImg.Width;
                    //section.PageInfo.PageHeight = bitmapImg.Height;
                    //System.Drawing.Image objDrawImage = null;
                    //try
                    //{
                    //    objDrawImage = System.Drawing.Image.FromStream(memoryStream);
                    //}
                    //catch (Exception ex)
                    //{

                    //    string strexmsg = ex.Message;
                    //}

                    Image objDrawImage = Image.FromStream(memoryStream);

                    //if (objDrawImage.Width > 465)
                    //{
                    //    int i = 1000;
                    //    //section.PageInfo.PageWidth = section.PageInfo.PageWidth + objDrawImage.Width - 465; 
                    //    section.PageInfo.PageWidth = section.PageInfo.PageWidth + objDrawImage.Width - i;
                    //}
                    //if (objDrawImage.Height > 570)
                    //{
                    //    int i = 1000;
                    //    // section.PageInfo.PageHeight = section.PageInfo.PageHeight + (objDrawImage.Height - 570);
                    //    section.PageInfo.PageHeight = section.PageInfo.PageHeight + (objDrawImage.Height - i);
                    //}
                    ////if (section.PageInfo.PageHeight < 1000)
                    ////    section.PageInfo.PageHeight = 1200;
                    ////Add the section in the sections collection of the Pdf document
                    // Aspose.Pdf.Generator.Image image = new Aspose.Pdf.Generator.Image(section);
                    Aspose.Pdf.Image image = new pdf.Image();
                    if (bitmapImg.Width > section.PageInfo.Width && (ext.ToLower() == "doc" || ext.ToLower() == "docx")) // TODO
                    {
                        word.Document doc = new word.Document();
                        foreach (word.Section section1 in doc)
                        {
                            section1.PageSetup.PaperSize = word.PaperSize.Letter;
                        }

                        word.DocumentBuilder builder = new word.DocumentBuilder(doc);
                        builder.CurrentSection.PageSetup.PaperSize = word.PaperSize.Letter;
                        builder.CurrentSection.ClearHeadersFooters();
                        builder.CurrentSection.PageSetup.LeftMargin = 5;
                        builder.CurrentSection.PageSetup.RightMargin = 5;
                        builder.CurrentSection.PageSetup.TopMargin = 5;
                        builder.CurrentSection.PageSetup.BottomMargin = 5;
                        //builder.PageSetup.PageHeight = pdfGenerator.PageSize.A4Height;
                        //builder.PageSetup.PageWidth = pdfGenerator.PageSize.A4Width;
                        //Read image from file to Image object
                        //Image img = Image.FromFile(@"Common\large.jpg");
                        double targetHeight;
                        double targetWidth;
                        CalculateImageSize(builder, objDrawImage, out targetHeight, out targetWidth);
                        //Add the image to the document and set it's position and size
                        //RR- Insert the image from the stream straight into the builder
                        //Shape shp = builder.InsertImage(objDrawImage, targetWidth, targetHeight);
                        Shape shp = builder.InsertImage(memoryStream, targetWidth, targetHeight);
                        shp.WrapType = WrapType.Inline;
                        shp.BehindText = true;
                        //Save document
                        imageLocation = strPath + rndImageName + ".pdf";
                        doc.Save(strPath + rndImageName + ".pdf");
                        //image.ImageInfo.FixWidth = section.PageInfo.PageWidth - section.PageInfo.Margin.Left - section.PageInfo.Margin.Right;
                        //image.ImageInfo.FixHeight = section.PageInfo.PageHeight - section.PageInfo.Margin.Top - section.PageInfo.Margin.Bottom;
                    }
                    else
                    {
                        //section.IsLandscape = false;
                        //if (bitmapImg.Width > section.PageInfo.Width)
                        //{
                        //    // section.IsLandscape = true;
                        //    image.ImageInfo.FixWidth = section.PageInfo.Width - section.PageInfo.Margin.Left - section.PageInfo.Margin.Right;
                        //}
                        //else
                        //    image.ImageInfo.FixWidth = bitmapImg.Width;
                        //if (bitmapImg.Height > section.PageInfo.PageHeight)
                        //{ image.ImageInfo.FixHeight = section.PageInfo.PageHeight - section.PageInfo.Margin.Top - section.PageInfo.Margin.Bottom; }
                        //else
                        //    image.ImageInfo.FixHeight = bitmapImg.Height;

                        //pdfFile.Sections.Add(section);

                        if (bitmapImg.Width > section.PageInfo.Width)
                        {
                            // section.IsLandscape = true;
                            image.FixWidth = section.PageInfo.Width - section.PageInfo.Margin.Left - section.PageInfo.Margin.Right;
                        }
                        else
                            image.FixWidth = bitmapImg.Width;
                        if (bitmapImg.Height > section.PageInfo.Height)
                        { image.FixHeight = section.PageInfo.Height - section.PageInfo.Margin.Top - section.PageInfo.Margin.Bottom; }
                        else
                            image.FixHeight = bitmapImg.Height;
                        pdfFile.Pages.Add(section);

                        //Add the image into paragraphs collection of the section
                        section.Paragraphs.Add(image);

                        switch (ext.ToLower())
                        {
                            //case "jpeg":
                            //case "jpg":
                            //    image.ImageInfo.ImageFileType = Aspose.Pdf.Generator.ImageFileType.Jpeg;
                            //    break;
                            //case "bmp":
                            //    image.ImageInfo.ImageFileType = Aspose.Pdf.Generator.ImageFileType.Bmp;
                            //    break;
                            //case "gif":
                            //    image.ImageInfo.ImageFileType = Aspose.Pdf.Generator.ImageFileType.Gif;
                            //    break;
                            case "tif":
                            case "tiff":
                                //UAT Ticket:41896 increasing section width to load tiff file 
                                //image.ImageInfo.ImageFileType = Aspose.Pdf.Generator.ImageFileType.Tiff;
                                if (bitmapImg.Width > 650)
                                {
                                    section.PageInfo.Width = 650; //PageWidth = 650;
                                }
                                break;
                        }
                        //Set the ImageStream to a MemoryStream object
                        //image.ImageInfo.ImageStream = memoryStream;
                        image.ImageStream = memoryStream;
                        //Set desired image scale
                        //image.ImageScale = 0.95F;                                
                        //image.ImageInfo.IsAllFramesInNewPage = true;
                        //image.ImageInfo.TiffFrame = -1;

                        image.IsInNewPage = true;
                        imageLocation = strPath + rndImageName + ".pdf";
                        pdfFile.Save(imageLocation);
                    }
                    //RR - TODO: Check if this is needed
                    //if (ext.ToLower().Trim() == "pdf")
                    //    HttpContext.Current.Response.ContentType = "application/pdf";
                    //read from filelocation and add into memorystream or byte[]

                    FileStream fileStream = new FileStream(imageLocation, FileMode.Open, FileAccess.Read);
                    try
                    {
                        int length = (int)fileStream.Length;  // get file length
                        byte_img = new byte[length];            // create buffer
                        int count;                            // actual number of bytes read
                        int sum = 0;                          // total number of bytes read

                        // read until Read method returns 0 (end of the stream has been reached)
                        while ((count = fileStream.Read(byte_img, sum, length - sum)) > 0)
                            sum += count;  // sum is a buffer offset for next reading
                    }
                    finally
                    {
                        fileStream.Close();
                    }
                    ext = "pdf";
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (System.IO.File.Exists(imageLocation))
                    {
                        try
                        {
                            System.IO.File.Delete(imageLocation);
                        }
                        catch (Exception ex)
                        {
                            string str = ex.Message;
                        }
                    }
                    if (System.IO.File.Exists(imageLocation_jpg))
                    {
                        try
                        {
                            System.IO.File.Delete(imageLocation_jpg);
                        }
                        catch (Exception ex)
                        {
                            string str = ex.Message;
                        }
                    }
                }
            }
            //RR - TODO: Check if this is needed
            //else if (ext.ToLower().Equals("bmp"))
            //    HttpContext.Current.Response.ContentType = "Image/bmp";
            //else if (ext.ToLower().Equals("gif"))
            //    HttpContext.Current.Response.ContentType = "Image/gif";
            //else
            //    HttpContext.Current.Response.ContentType = "application/pdf";
            return byte_img;
        }

        private void CalculateImageSize(word.DocumentBuilder builder, System.Drawing.Image img, out double targetHeight, out double targetWidth)
        {
            //Calculate width and height of the page
            //word.PageSetup ps = builder.CurrentSection.PageSetup;
            targetHeight = builder.PageSetup.PageHeight; //ps.PageHeight - ps.TopMargin - ps.BottomMargin;
            targetWidth = builder.PageSetup.PageWidth;//ps.PageWidth - ps.LeftMargin - ps.RightMargin;
                                                      //Get size of an image
            double imgHeight = word.ConvertUtil.PixelToPoint(img.Height);
            double imgWidth = word.ConvertUtil.PixelToPoint(img.Width);
            if (imgHeight < targetHeight && imgWidth < targetWidth)
            {
                targetHeight = imgHeight;
                targetWidth = imgWidth;
            }
            else
            {
                //Calculate size of an image in the document
                double ratioWidth = imgWidth / targetWidth;
                double ratioHeight = imgHeight / targetHeight;
                if (ratioWidth > ratioHeight)
                    targetHeight = (targetHeight * (ratioHeight / ratioWidth));
                else
                    targetHeight = (targetWidth * (ratioWidth / ratioHeight));
            }
        }

        private void ResizeImage(System.Drawing.Bitmap bitmapImage, string imageLocationtoSave)
        {
            System.Drawing.Imaging.FrameDimension dimension = new System.Drawing.Imaging.FrameDimension(bitmapImage.FrameDimensionsList[0]);
            pdf.Document pdfDoc = new pdf.Document();
            int framesCount = bitmapImage.GetFrameCount(dimension);
            System.Drawing.Imaging.ImageFormat imgFormat = bitmapImage.RawFormat;
            for (int frameindex = 0; frameindex <= framesCount - 1; frameindex++)
            {
                Aspose.Pdf.Page sec = null;
                bitmapImage.SelectActiveFrame(dimension, frameindex);
                MemoryStream currentImage = new MemoryStream();
                bitmapImage.Save(currentImage, imgFormat);// System.Drawing.Imaging.ImageFormat.Tiff);
                sec = pdfDoc.Pages.Add();
                sec.PageInfo.Height = bitmapImage.Height;
                sec.PageInfo.Width = bitmapImage.Width;

                pdf.Image imageHt = new pdf.Image();
                imageHt.ImageStream = currentImage;
                imageHt.IsBlackWhite = false;
                sec.Paragraphs.Add(imageHt);
            }
            pdfDoc.Save(imageLocationtoSave);
        }

        public void SetAsposeLicense()
        {
            #region Aspose Licenses
            //if (isProduction)
            //{
                if (AsposeLicense.IsLicenseSet == false)
                {
                    Aspose.Pdf.License lic = new Aspose.Pdf.License();
                    word.License licWord = new word.License();
                    //barcode.License licBarcode = new barcode.License();

                    try
                    {
                        lic.SetLicense("Aspose.Pdf.lic");
                        licWord.SetLicense("Aspose.Words.lic");
                        //licBarcode.SetLicense("Aspose.BarCode.lic"); //RR - TODO: Canot read this lic file.  Need to figure out why

                        AsposeLicense.IsLicenseSet = true;
                    }
                    catch (Exception ex)
                    {
                        //_logger.Error(ex, "Error while retieving PDF in SetAsposeLicense");
                        throw new Exception("Issue with aspose, please contact your supervisor.");
                    }
                }
            //}
            #endregion Aspose Licenses
        }

        public byte[] ConvertPDFToWordToPDF(string filePath, out int noofPages)
        {
            byte[] finalResult = { 0 };
            Aspose.Pdf.Document pdfDocument = new Aspose.Pdf.Document(filePath + ".pdf");
            if (pdfDocument.Version == "1.3")
            {
                pdfDocument.Save(filePath + ".docx", Aspose.Pdf.SaveFormat.Doc);
                Aspose.Words.Document doc = new Aspose.Words.Document(filePath + ".docx");
                doc.Save(filePath + "1.pdf");
                //41413	Humana - Production	When document is uploaded formatting changes removing J-Code Column sravana 12/4/2019
                noofPages = PageCount(filePath + ".pdf");
                finalResult = System.IO.File.ReadAllBytes(filePath + ".pdf");
            }
            else
            {
                noofPages = PageCount(filePath + ".pdf");
                finalResult = System.IO.File.ReadAllBytes(filePath + ".pdf");
            }
            return finalResult;
        }

        public Stream MergeDocfiles(Stream Source, Stream Dest)
        {
            Stream appendedStream = ((Stream)(new MemoryStream()));
            Aspose.Words.Document srcDoc = new Aspose.Words.Document(Source);
            Aspose.Words.Document srcDest = new Aspose.Words.Document(Dest);
            srcDoc.AppendDocument(srcDest, Aspose.Words.ImportFormatMode.KeepSourceFormatting);
            srcDoc.Save(appendedStream, Aspose.Words.SaveFormat.Docx);
            return appendedStream;
        }

        public Stream SaveWordtoPdfStream(Stream wordStream)
        {
            Stream msCoverStream = ((Stream)(new MemoryStream()));
            word.Document srcDoc = new word.Document(wordStream);
            if (srcDoc != null)
            {
                srcDoc.Save(msCoverStream, word.SaveFormat.Pdf);
            }
            return msCoverStream;
        }
        // AGADIACR889   Neha      Aug 2019  Code added for  Pdf to Tiff Conversion
        public MemoryStream ConvertPDFtoTIFF(byte[] byte_img)
        {
            MemoryStream msoriginalPdfstream1 = new MemoryStream();
            msoriginalPdfstream1.Write(byte_img, 0, byte_img.Length);
            // Aspose.Pdf.Generator.Pdf pdfFile = new Aspose.Pdf.Generator.Pdf();
            Aspose.Pdf.Document pdfDocument = new Aspose.Pdf.Document(msoriginalPdfstream1); // This is PDF DOC
                                                                                             // Create Resolution object
            Resolution resolution = new Resolution(200);
            // Create TiffSettings object
            TiffSettings tiffSettings = new TiffSettings();
            tiffSettings.Compression = CompressionType.CCITT4;
            tiffSettings.Depth = ColorDepth.Default;
            tiffSettings.Shape = pdf.Devices.ShapeType.Landscape;
            tiffSettings.SkipBlankPages = false;
            // Create TIFF device
            TiffDevice tiffDevice = new TiffDevice(resolution, tiffSettings);
            MemoryStream myfinalTIFF = new MemoryStream();
            // Convert a particular page and save the image to stream
            //tiffDevice.Process(pdfDocument, @"D:\Projects\PahubBOB\PAHubBoBProjects-v4.6_QA\Jobs\DocumentsMovedtoESI\DocumentsMovedtoESI\bin\Debug\abc.tiff");
            tiffDevice.Process(pdfDocument, myfinalTIFF);
            return myfinalTIFF;
        }

        //AGADIACR2787 Roberto Reinoso 11/24/2021.  Blanks pages document should not be sent out
        public int NumberOfBlankPages(MemoryStream inputStream)
        {
            int intBlankPagesTotalCount = 0;
            inputStream.Position = 0;
            Aspose.Pdf.Document pdfDocument = new Aspose.Pdf.Document(inputStream);
            //Check each page
            foreach (pdf.Page page in pdfDocument.Pages)
            {
                if (page.IsBlank(0.01d))
                    intBlankPagesTotalCount++;
            }
            return intBlankPagesTotalCount;
        }

        public Image GetDrawImageFromStream(MemoryStream inMemoryStream)
        {
            try
            {
                System.Drawing.Image objDrawImage = null;
                objDrawImage = System.Drawing.Image.FromStream(inMemoryStream);
                return objDrawImage;
            }
            catch (Exception ex)
            {
                throw new Exception("Exception in GetDrawImageFromStream():" + ex);
            }
        }

    }

    internal class HandleMergeFieldInsertHtml : wordMailMerging.IFieldMergingCallback
    {
        /// <summary>
        /// This is called when merge field is actually merged with data in the document.
        /// </summary>
        void wordMailMerging.IFieldMergingCallback.FieldMerging(wordMailMerging.FieldMergingArgs e)
        {
            //string fontStyle = "<head></head><body><font isUnicode='true' face='Arial' size=2><table><tr><td>Sample text with Custome font Embedded </td></tr></table></font><br><font isUnicode='true' face='Courier New' size=10><s>Sample Text </s>in <u>Courier New</u> font</font></body>";
            // All merge fields that expect HTML data should be marked with some prefix, e.g. 'html'.
            if (string.Compare(e.FieldName, "Clinical Questionnaire (blank)", true) == 0 && e.FieldValue != null)
            {
                // Insert the text for this merge field as HTML data, using DocumentBuilder.
                word.DocumentBuilder builder = new word.DocumentBuilder(e.Document);
                builder.MoveToMergeField(e.DocumentFieldName);
                e.Document.NodeChangingCallback = new HandleFontNodeChanging(e.Field.Start.Font);
                builder.InsertHtml(e.FieldValue.ToString() + "</font></body>", true);
                e.Document.NodeChangingCallback = null;
                e.Text = "";
            }

            if (string.Compare(e.FieldName, "NMI Reasons", true) == 0 || string.Compare(e.FieldName, "Maryland Denial Type", true) == 0 || string.Compare(e.FieldName, "Maryland Spanish Denial Type", true) == 0)
            {
                if (e.FieldValue != null)
                {
                    word.DocumentBuilder builder = new word.DocumentBuilder(e.Document);
                    builder.MoveToMergeField(e.DocumentFieldName);
                    builder.InsertHtml(e.FieldValue.ToString(), true);
                    e.Document.NodeChangingCallback = null;
                    e.Text = "";
                }
            }
            if (string.Compare(e.FieldName, "Patient Reason", true) == 0)
            {
                if (e.FieldValue != null)
                {
                    word.DocumentBuilder builder = new word.DocumentBuilder(e.Document);
                    builder.MoveToMergeField(e.DocumentFieldName);
                    builder.InsertHtml(e.FieldValue.ToString(), true);
                    e.Document.NodeChangingCallback = null;
                    e.Text = "";
                }
            }
            if (string.Compare(e.FieldName, "Patient Spanish Reason", true) == 0)
            {
                if (e.FieldValue != null)
                {
                    word.DocumentBuilder builder = new word.DocumentBuilder(e.Document);
                    builder.MoveToMergeField(e.DocumentFieldName);
                    builder.InsertHtml(e.FieldValue.ToString(), true);
                    e.Document.NodeChangingCallback = null;
                    e.Text = "";
                }
            }

            if (string.Compare(e.FieldName, "DMR drugs with explanations", true) == 0)
            {
                if (e.FieldValue != null)
                {
                    word.DocumentBuilder builder = new word.DocumentBuilder(e.Document);
                    builder.MoveToMergeField(e.DocumentFieldName);
                    builder.InsertHtml(e.FieldValue.ToString(), true);
                    e.Document.NodeChangingCallback = null;
                    e.Text = "";
                }
            }

            if (string.Compare(e.FieldName, "DMR drugs with explanations Spanish", true) == 0)
            {
                if (e.FieldValue != null)
                {
                    word.DocumentBuilder builder = new word.DocumentBuilder(e.Document);
                    builder.MoveToMergeField(e.DocumentFieldName);
                    builder.InsertHtml(e.FieldValue.ToString(), true);
                    e.Document.NodeChangingCallback = null;
                    e.Text = "";
                }
            }

            if (string.Compare(e.FieldName, "Alternate Providers", true) == 0)
            {
                if (e.FieldValue != null)
                {
                    word.DocumentBuilder builder = new word.DocumentBuilder(e.Document);
                    builder.MoveToMergeField(e.DocumentFieldName);
                    builder.InsertHtml(e.FieldValue.ToString(), true);
                    e.Document.NodeChangingCallback = null;
                    e.Text = "";
                }
            }

            if (string.Compare(e.FieldName, "Florida Spanish Denial Reason", true) == 0)
            {
                if (e.FieldValue != null)
                {
                    word.DocumentBuilder builder = new word.DocumentBuilder(e.Document);
                    builder.MoveToMergeField(e.DocumentFieldName);
                    builder.InsertHtml(e.FieldValue.ToString(), true);
                    e.Document.NodeChangingCallback = null;
                    e.Text = "";
                }
            }

            if (string.Compare(e.FieldName, "Florida Denial Reason", true) == 0)
            {
                if (e.FieldValue != null)
                {
                    word.DocumentBuilder builder = new word.DocumentBuilder(e.Document);
                    builder.MoveToMergeField(e.DocumentFieldName);
                    builder.InsertHtml(e.FieldValue.ToString(), true);
                    e.Document.NodeChangingCallback = null;
                    e.Text = "";
                }
            }

            if (string.Compare(e.FieldName, "Expedite or Urgency Checkmark", true) == 0)
            {
                if (e.FieldValue != null)
                {
                    word.DocumentBuilder builder = new word.DocumentBuilder(e.Document);

                    builder.MoveToMergeField(e.DocumentFieldName);
                    //builder.InsertHtml(e.FieldValue.ToString(), true);
                    builder.Font.Color = System.Drawing.Color.Black;
                    if (e.FieldValue.ToString().ToLower() == "yes")
                        builder.InsertCheckBox("chkUrgency", true, 12);
                    else
                        builder.InsertCheckBox("chkUrgency", false, 12);


                    e.Document.NodeChangingCallback = null;
                    e.Text = "";
                }
            }
            if (string.Compare(e.FieldName, "Future dated request Checkmark (Yes)", true) == 0)
            {
                if (e.FieldValue != null)
                {
                    word.DocumentBuilder builder = new word.DocumentBuilder(e.Document);
                    builder.MoveToMergeField(e.DocumentFieldName);
                    builder.InsertHtml(e.FieldValue.ToString(), true);
                    e.Document.NodeChangingCallback = null;
                    e.Text = "";
                }
            }

            if (string.Compare(e.FieldName, "Future dated request Checkmark (No)", true) == 0)
            {
                if (e.FieldValue != null)
                {
                    word.DocumentBuilder builder = new word.DocumentBuilder(e.Document);
                    builder.MoveToMergeField(e.DocumentFieldName);
                    builder.InsertHtml(e.FieldValue.ToString(), true);
                    e.Document.NodeChangingCallback = null;
                    e.Text = "";
                }
            }
            if (string.Compare(e.FieldName, "Future dated year textbox", true) == 0)
            {
                if (e.FieldValue != null)
                {
                    word.DocumentBuilder builder = new word.DocumentBuilder(e.Document);
                    builder.MoveToMergeField(e.DocumentFieldName);
                    builder.InsertHtml(e.FieldValue.ToString(), true);
                    e.Document.NodeChangingCallback = null;
                    e.Text = "";
                }
            }
        }

        void wordMailMerging.IFieldMergingCallback.ImageFieldMerging(wordMailMerging.ImageFieldMergingArgs e)
        {
        }
    }

    public class HandleFontNodeChanging : word.INodeChangingCallback
    {
        Aspose.Words.Font mFont;
        public HandleFontNodeChanging(Aspose.Words.Font font)
        {
            mFont = font;
        }
        void word.INodeChangingCallback.NodeInserted(word.NodeChangingArgs args)
        {
            if (args.Node.NodeType == word.NodeType.Run)
            {
                word.Run run = (word.Run)args.Node;
                run.Font.Name = mFont.Name;
                // run.Font.Color = mFont.Color;
                run.Font.Size = mFont.Size;
            }
        }
        void word.INodeChangingCallback.NodeInserting(word.NodeChangingArgs args)
        {
            // Do Nothing
        }
        void word.INodeChangingCallback.NodeRemoved(word.NodeChangingArgs args)
        {
            // Do Nothing
        }
        void word.INodeChangingCallback.NodeRemoving(word.NodeChangingArgs args)
        {
            // Do Nothing
        }
    }

    internal class HandleMergeFieldInsertImage : wordMailMerging.IFieldMergingCallback
    {
        /// <summary>
        /// This is called when merge field is actually merged with data in the document.
        /// </summary>
        void wordMailMerging.IFieldMergingCallback.FieldMerging(wordMailMerging.FieldMergingArgs e)
        {
        }

        void wordMailMerging.IFieldMergingCallback.ImageFieldMerging(wordMailMerging.ImageFieldMergingArgs e)
        {
            // The field value is a byte array, just cast it and create a stream on it.
            if (e.FieldValue != null)
            {
                MemoryStream imageStream = new MemoryStream((byte[])e.FieldValue);

                // Now the mail merge engine will retrieve the image from the stream.
                e.ImageStream = imageStream;
            }
        }
    }
}

