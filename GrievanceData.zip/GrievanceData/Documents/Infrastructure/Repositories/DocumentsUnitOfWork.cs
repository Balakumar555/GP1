﻿using GrievanceData.Case.Infrastructure.Interfaces;
using GrievanceData.Case.Infrastructure.Settings;
using GrievanceData.Documents.Infrastructure.Settings;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.Documents.Infrastructure.Repositories
{
    internal class DocumentsUnitOfWork : IDocumentsUnitOfWork
    {
        //You will need UnitOfWork when you have transactions through a repo;
        private readonly IDocumentsSqlRepository _docRepo;
        IDocumentsSqlRepository IDocumentsUnitOfWork.DocumentsSqlRepo => _docRepo;
        public DocumentsUnitOfWork(DocumentsUnitOfWorkSettings cows)
        {
            _docRepo = new DocumentsSqlRepository(cows.commonsettings, cows.Documentssettings, cows.commonservice, cows.asposeservice);
        }
    }
}
