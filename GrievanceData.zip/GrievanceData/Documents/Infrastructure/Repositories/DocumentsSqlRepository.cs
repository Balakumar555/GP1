﻿using Aspose.Pdf.Annotations;
using DocumentsData.DocumentsContext;
using GrievanceData.Case.Infrastructure.Interfaces;
using GrievanceData.Common.Infrastructure.Service;
using GrievanceData.Common.Infrastructure.Settings;
using GrievanceData.Documents.Domain;
using GrievanceData.Documents.Infrastructure.Settings;
using GrievanceData.GrievanceHubAspose;

namespace GrievanceData.Documents.Infrastructure.Repositories
{
    internal class DocumentsSqlRepository : IDocumentsSqlRepository
    {
        private readonly ICommonService _cservice;
        private readonly IAsposeService _asposeService;

        private readonly GrievanceData.Documents.Infrastructure.Settings.SQLRepoSettings _sqlsettings;
        private CommonSettings _commonsettings;
        public DocumentsData.DocumentsDbContext.OutputParameter<string> errorDescription = new DocumentsData.DocumentsDbContext.OutputParameter<string>();
        public DocumentsData.DocumentsDbContext.OutputParameter<byte?> errorCode = new DocumentsData.DocumentsDbContext.OutputParameter<byte?>();

        public DocumentsSqlRepository(CommonSettings commonsettings, DocumentsSettings docsettings, ICommonService service, IAsposeService asposeService)
        {
            _commonsettings = commonsettings;
            _cservice = service;
            _sqlsettings = docsettings.SQLRepo;
            _asposeService = asposeService;
        }

        public async Task<long> PostFileAsync(FileUploadModel fileData)
        {
            try
            {
                long docId = 0;
                byte[] fileBytes = Array.Empty<byte>();
                fileData.Extension = fileData.Extension.Replace("image/", "");
                using (var stream = new MemoryStream())
                {
                    fileData.file.CopyTo(stream);
                    if (fileData.Extension.ToLower().Contains("document")|| fileData.Extension.ToLower().Contains("text"))
                    {
                        fileData.Extension = "pdf";
                        var pdfstream = SaveWordtoPdf(stream, Format.Pdf);
                        fileBytes = pdfstream.ToArray();
                    }
                    else
                        fileBytes = stream.ToArray();
                }


                List<usp_InsertDocumentResult> docs = await _cservice.DocumentsContext.Procedures.usp_InsertDocumentAsync(fileBytes, fileData.DocType, fileData.Extension, fileData.CreatedBy, fileData.CaseId, errorCode, errorDescription);
                if(docs.Count > 0)
                {
                    docId = docs.First().DocId;
                }

                return docId;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<usp_GetDocumentDetailsResult>> GetDocumentDeails(long docId)
        {
            try
            {

                return await _cservice.DocumentsContext.Procedures.usp_GetDocumentDetailsAsync(docId, errorCode, errorDescription);



            }
            catch (Exception)
            {
                throw;
            }
        }

        public MemoryStream SaveWordtoPdf(MemoryStream streamData, Format fileFormat)
        {
            if (fileFormat == Format.Pdf)
            {
                return _asposeService.SavePDFDocument(streamData);
            }
            return _asposeService.SaveWordDocument(streamData);
        }

        public async Task<int> DeleteDocument(long docId)
        {
            try
            {
               return await _cservice.DocumentsContext.Procedures.usp_DeleteDocumentAsync(docId, errorCode, errorDescription);
               
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
