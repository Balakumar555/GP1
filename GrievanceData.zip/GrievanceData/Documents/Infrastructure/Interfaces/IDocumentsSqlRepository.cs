﻿using DocumentsData.DocumentsContext;
using GrievanceData.Case.Domain;
using GrievanceData.Case.Services;
using GrievanceData.Documents.Domain;
using Microsoft.AspNetCore.Http;

namespace GrievanceData.Case.Infrastructure.Interfaces
{
    internal interface IDocumentsSqlRepository
    {
        public Task<long> PostFileAsync(FileUploadModel fileData);
        public Task<List<usp_GetDocumentDetailsResult>> GetDocumentDeails(long docId);
        public Task<int> DeleteDocument(long docId);
    }
}
