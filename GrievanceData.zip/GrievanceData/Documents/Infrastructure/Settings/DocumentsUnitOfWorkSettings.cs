﻿using GrievanceData.Common.Infrastructure.Service;
using GrievanceData.Common.Infrastructure.Settings;
using GrievanceData.GrievanceHubAspose;

namespace GrievanceData.Documents.Infrastructure.Settings
{
    public class DocumentsUnitOfWorkSettings
    {
        public CommonSettings commonsettings { get; set; }
        public ICommonService commonservice { get; set; }
        public DocumentsSettings Documentssettings { get; set; }
        public IAsposeService asposeservice { get; set; }

    }
}
