﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.Documents.Infrastructure.Settings
{
    public class DocumentsSettings
    {
        public SQLRepoSettings SQLRepo { get; set; }

    }
}
