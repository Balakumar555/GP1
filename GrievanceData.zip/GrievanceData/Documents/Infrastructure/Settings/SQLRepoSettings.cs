namespace GrievanceData.Documents.Infrastructure.Settings
{
    public class SQLRepoSettings
    {
        // public string GetUserToken { get; set; }
    }
}