﻿using DocumentsData.DocumentsContext;
using GrievanceData.Case.Domain;
using GrievanceData.Documents.Domain;
using Microsoft.AspNetCore.Http;
using UserDto = GrievanceData.GrievanceContext.UserDto;

namespace GrievanceData.Documents.Services
{
    public interface IDocumentsService
    {
        Task<long> PostFileAsync(FileUploadModel fileData);
        Task<List<usp_GetDocumentDetailsResult>> GetDocumentDeails(long docId);
        Task<int> DeleteDocument(long docId);
    }
}
