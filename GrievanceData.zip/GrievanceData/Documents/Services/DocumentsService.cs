﻿using GrievanceData.Common.Infrastructure.Service;
using GrievanceData.Common.Infrastructure.Settings;
using GrievanceData.GrievanceContext;
using GrievanceData.GrievanceDbContext;
using GrievanceData.Case.Domain;
using GrievanceData.Case.Infrastructure.Interfaces;
using GrievanceData.Case.Infrastructure.Repositories;
using GrievanceData.Case.Infrastructure.Settings;
using Newtonsoft.Json.Linq;
using UserDto = GrievanceData.GrievanceContext.UserDto;
using GrievanceData.Documents.Domain;
using Microsoft.AspNetCore.Http;
using GrievanceData.Documents.Infrastructure.Settings;
using GrievanceData.Documents.Infrastructure.Repositories;
using DocumentsData.DocumentsContext;
using GrievanceData.GrievanceHubAspose;

namespace GrievanceData.Documents.Services
{
    public class DocumentsService : IDocumentsService
    {
        private readonly IDocumentsUnitOfWork cuow;
        private readonly ICommonService _cservice;
        private readonly DocumentsSettings _Documentssettings;
        private readonly IAsposeService _asposeService ;


        public DocumentsService(GrievancesContext context, CommonSettings commonsettings, DocumentsSettings Documentssettings, ICommonService cservice, IAsposeService asposeService)
        {
            if (cuow == null)
				cuow = cuow ?? new DocumentsUnitOfWork(new DocumentsUnitOfWorkSettings
                {
                    Documentssettings = Documentssettings,
                    commonsettings = commonsettings,
                    commonservice = cservice,
                    asposeservice= asposeService
                });

            _cservice = cservice;
			
        }
        
        public async Task<long> PostFileAsync(FileUploadModel fileData)
        {
            return await cuow.DocumentsSqlRepo.PostFileAsync(fileData);
        }

        public async Task<List<usp_GetDocumentDetailsResult>> GetDocumentDeails(long docId)
        {
            try
            {
                return await cuow.DocumentsSqlRepo.GetDocumentDeails(docId);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<int> DeleteDocument(long docId)
        {
            return await cuow.DocumentsSqlRepo.DeleteDocument(docId);
        }

    }
}
