﻿using Microsoft.AspNetCore.Http;
using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.Documents.Domain
{
	public class FileUploadModel
    {
        public int ID { get; set; }
        public string FileName { get; set; }
       // public byte[] FileData { get; set; }
        public IFormFile file { get; set; }
        public string Extension { get; set; }
        public string DocType { get; set; }
        public int CreatedBy { get; set; }
        public int CaseId{ get; set; }

    }



    public enum FileType
    {
        PDF = 1,
        DOCX = 2
    }
}
