﻿using GrievanceData.Common.Infrastructure.Service;
using GrievanceData.Common.Infrastructure.Settings;
using GrievanceData.GrievanceContext;
using GrievanceData.GrievanceDbContext;
using GrievanceData.User.Domain;
using GrievanceData.User.Infrastructure.Interfaces;
using GrievanceData.User.Infrastructure.Repositories;
using GrievanceData.User.Infrastructure.Settings;
using Newtonsoft.Json.Linq;
using UserDto = GrievanceData.GrievanceContext.UserDto;

namespace GrievanceData.User.Services
{
    public class UserService : IUserService
    {
        private readonly IUserUnitOfWork uow;
        private readonly ICommonService _cservice;
        private readonly UserSettings _usersettings;

        public UserService(GrievancesContext context, CommonSettings commonsettings, UserSettings usersettings, ICommonService cservice)
        {
            if (uow == null)
                uow = uow ?? new UserUnitOfWork(new UserUnitOfWorkSettings
                {
                    usersettings = usersettings,
                    commonsettings = commonsettings,
                    commonservice = cservice
                });

            _cservice = cservice;
            _usersettings = usersettings;
        }
        public async Task<UserDto> LogIn(LogInReq req)
        {
            UserDto resp = await uow.UserSqlRepo.LogIn(req);
            return resp;
        }

		public async Task<List<string>> GetUserPrivileges(int userId)
		{
            return await uow.UserSqlRepo.GetUserPrivileges(userId);
			
		}

		public async Task<List<TblUsers>> GetUsers(int req)
        {
            List<TblUsers> resp = await uow.UserSqlRepo.GetUsers(req);
            return resp;
        }

        public async Task<List<usp_Get_User_DetailsResult>> GetUserDetails(int req)
        {
            List<usp_Get_User_DetailsResult> resp = await uow.UserSqlRepo.GetUserDetails(req);
            return resp;
        }

        public async Task<bool> RegisterUser(NewUserReq req)
        {
            bool status = await uow.UserSqlRepo.RegisterUser(req);
            return status;
        }

        public async Task<bool> UpdateUser(UpdateUserReq req)
        {
            bool status = await uow.UserSqlRepo.UpdateUser(req);
            return status;
        }
        public async Task<bool> SendEmail(string EmailId)
        {
            bool resp = await uow.UserSqlRepo.SendEmail(EmailId);
            return resp;
        }
        public async Task<bool> UpdatePassword(UpdatePassword req)
        {
            bool status = await uow.UserSqlRepo.UpdatePassword(req);
            return status;
        }

        public async Task<bool> ResetPassword(ResetPassword req)
        {
            bool status = await uow.UserSqlRepo.ResetPassword(req);
            return status;
        }

        public async Task<bool> SendResetPasswordNotification(int customerId,string emailId, string token, string newPassword)
        {
           return await uow.UserSqlRepo.SendResetPasswordNotification(customerId,emailId, token,newPassword);
            
        }

        public async Task<MemberEligibilityResp> GetMemberEligibility(MemberEligibilityReq req)
        {
            return await uow.UserSqlRepo.GetMemberEligibility(req);
        }

		public async Task<List<Roles>> GetRolesByCustomerId(int custId)
		{
			return await uow.UserSqlRepo.GetRolesByCustomerId(custId);
			
		}

        public async Task<OTPVerificationResponse> TwoStepsAuthentication(string EmailId, string Otp, byte OtpExpiryTime)
        {

           return await uow.UserSqlRepo.TwoStepsAuthentication(EmailId,Otp,OtpExpiryTime);
            
        }

		public async Task<string> GetRoleByUserId(int userId,int customerId)
		{
			return await uow.UserSqlRepo.GetRoleByUserId(userId, customerId);

		}

		public async Task<List<usp_GetUsersByRoleResult>> GetUsersByRole(short roleId,int customerId)
		{
			List<usp_GetUsersByRoleResult> resp = await uow.UserSqlRepo.GetUsersByRole(roleId, customerId);
			return resp;
		}

		public async Task<List<usp_GetAllAffiliationTypesResult>> GetAllAffiliationTypes()
        {
			List<usp_GetAllAffiliationTypesResult> resp = await uow.UserSqlRepo.GetAllAffiliationTypes();
			return resp;
		}

		public async Task<List<usp_GetAffiliatedUserClientsResult>> GetAffiliatedUserClients(int userId)
        {
			List<usp_GetAffiliatedUserClientsResult> resp = await uow.UserSqlRepo.GetAffiliatedUserClients(userId);
			return resp;
		}


	}


}

