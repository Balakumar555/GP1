﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.User.Domain
{
    public class MemberEligibilityReq
    {
        public string MbrNbr { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public string DoB { get; set; }
        public string Mbi { get; set; }
    }
}
