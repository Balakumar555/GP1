﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.User.Domain
{
	public class UpdateUserReq
    {
		public short CustId { get; set; }
		public short UserID { get; set; }
		public string LoginID { get; set; } = null!;
		public string Fname { get; set; } = null!;
		public string Mname { get; set; } = null!;
		public string Lname { get; set; } = null!;
		public string Status { get; set; } = null!;
		//public string Affiliation { get; set; } = null!;
		public string UserInitial { get; set; } = null!;
		public DateTime UsrEndDate { get; set; }
		public string Email { get; set; } = null!;
		public string Mobile { get; set; } = null!;
		public bool MFAEnabled { get; set; }
		public short roleId { get; set; }
		public string? clientIds { get; set; }
		public int? UserTypeId { get; set; }
	}
}
