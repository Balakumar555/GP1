﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.User.Domain
{
    public class UpdatePassword
    {
        public short CustId { get; set; }
        public short UserID { get; set; }
        public string OldPassword { get; set; }
        public string NewPassword { get; set; }
        public string EmailId { get; set; } = null!;

    }
}
