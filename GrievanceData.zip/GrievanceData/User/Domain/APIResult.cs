﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.User.Domain
{
    public class MFAApiResponse<T, K>
    {
        public MFAApiResponse()
        {
            result = default;
            errorContent = default;
        }

        public MFAApiResponse(T defaultresult = default, K defaulterrorcontent = default)
        {
            result = defaultresult;
            errorContent = defaulterrorcontent;
        }
        public T result { set; get; }
        public K errorContent { get; set; }
    }
}
