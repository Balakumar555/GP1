﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.User.Domain
{
    public class GetUsersResp
    {
        public long UserId { get; set; }        
        public string LoginId { get; set; }       
        public string Fname { get; set; }        
        public string Lname { get; set; }
    }
}
