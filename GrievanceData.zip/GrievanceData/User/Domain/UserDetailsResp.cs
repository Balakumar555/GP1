﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.User.Domain
{
    public class UserDetailsResp
    {
        public long UserId { get; set; }
        public short CustId { get; set; }
        public string LoginId { get; set; }
        public string Password { get; set; }
        public string Fname { get; set; }
        public string Mname { get; set; }
        public string Lname { get; set; }
        public string Affiliation { get; set; }
        public string Status { get; set; }
        public string UserInitial { get; set; }
        public DateTime? UsrEffectiveDate { get; set; }
        public DateTime? UsrEndDate { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public bool Mfaenabled { get; set; }
        public long Createdby { get; set; }
        public DateTime CreatedDate { get; set; }
        public long Modifyby { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
