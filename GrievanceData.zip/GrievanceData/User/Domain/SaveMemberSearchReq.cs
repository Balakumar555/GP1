﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.User.Domain
{
    public class SaveMemberSearchReq
    {
        public int RepresentativeTypeId { get; set; }
        public string AoRFname { get; set; }
        public string AoRLname { get; set; }
        public string AoRPhoneNumber { get; set; }
        public string AoRAddress1 { get; set; }
        public string AoRAddress2 { get; set; }
        public string AoRCity { get; set; }
        public string AoRState { get; set; }
        public string AoRZip { get; set; }
        public string AoRPostalCode { get; set; }
        public string MPAddress1 { get; set; }
        public string MPAddress2 { get; set; }
        public string MPCity { get; set; }
        public string MPState { get; set; }
        public string MPZip { get; set; }
        public string MPPostalCode { get; set; }
        public string RepresentativeFormReceived { get; set; }
        public DateTime? DateReceived { get; set; }
        public bool AoRFlg { get; set; }



        public DateTime? MemberSignatureDate { get; set; }
        public DateTime? AppointeeSignatureDate { get; set; }
        public string MBI { get; set; }
        public string MemberNumber { get; set; }
        public string AltMemberID { get; set; }
        public string RelationCode { get; set; }
        public bool MemberCardholder { get; set; }
        public string PersonNumber { get; set; }
        public string GroupNumber { get; set; }
        public DateTime? EligibilityEffectiveDate { get; set; }
        public DateTime? EligibilityEndDate { get; set; }
        public string CardholderContractNumber { get; set; }
        public string CMSContractNumber { get; set; }
        public int ClientId { get; set; }
        public int PlanId { get; set; }
        public string MPFname { get; set; }
        public string MPLname { get; set; }
        public string MPMname { get; set; }
        public DateTime? DOB { get; set; }
        public string Gender { get; set; }
        public string LanguagePreference { get; set; }
        public string CommunicationPreference { get; set; }
        public string CellPhoneNbr { get; set; }
        public string HomePhoneNbr { get; set; }
        public string WorkPhoneNbr { get; set; }
        public string FaxNbr { get; set; }
        public int UserId { get; set; }
    }
}
