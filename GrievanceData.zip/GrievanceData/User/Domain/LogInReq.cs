﻿namespace GrievanceData.User.Domain
{
    public class LogInReq
    {
        public string LoginId { get; set; } = null!;
        public string Pwd { get; set; } = null!; 
        public bool isOTPRequired { get; set; } = false;
	}
}