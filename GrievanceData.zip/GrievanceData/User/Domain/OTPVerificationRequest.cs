﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.User.Domain
{
    public class OTPVerificationRequest
    {
        public string EmailId { get; set; }
        public string OTP { get; set; }
        public byte? OTPExpiryTime { get; set; }
    }
    public class OTPVerificationResponse
    {
        public bool IsSuccess { get; set; }
        public string errorMessage { get; set; }
    }
}
