﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.User.Domain
{
    public class ResetPassword
    {
              
        public string NewPassword { get; set; }
        public string loginId { get; set; } = null!;
        public string Token { get; set; } = null!;
        public int CustomerId { get; set; }

    }
}
