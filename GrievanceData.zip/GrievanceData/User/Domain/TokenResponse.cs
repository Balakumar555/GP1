﻿namespace GrievanceData.User.Domain
{
    public class LoginResponse
    {
        public string otp { get; set; }
        public string emailId { get; set; }
        public string fName { get; set; }
        public string lName { get; set; }
        public string access_token { get; set; }
        public string refresh_token { get; set; }
        public string expires_in { get; set; }
        public string applicationId { get; set; }
        public string emailOtpStatus { get; set; }
        public int mfaErrorCode { get; set; } = 0;
        public string mfaErrorDesc { get; set; }
        public string isExpired { get; set; }
        public int customerId { get; set; }
        public long userId { get; set; }
        public string loginId { get; set; }
        public string status { get; set; }
        public short? roleId { get; set; }
    }
}
