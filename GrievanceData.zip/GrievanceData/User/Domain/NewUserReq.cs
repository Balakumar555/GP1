﻿namespace GrievanceData.User.Domain
{
    public class NewUserReq
    {	
		public short CustId { get; set; }
		public string Fname { get; set; } = null!;
		public string Mname { get; set; } = null!;		
		public string Lname { get; set; } = null!;
		public string UserInitial { get; set; } = null!;
		public string LoginID { get; set; } = null!;
		public string Password { get; set; } = null!;
		public string Status { get; set; } = null!;
		public string Email { get; set; } = null!;
		public string Mobile { get; set; } = null!;		
		public DateTime UsrEffDate { get; set; }
		public DateTime UsrEndDate { get; set; }
		public short roleId { get; set; }
		public string? clientIds { get; set; }
		public int? UserTypeId { get; set; }
	}
}
