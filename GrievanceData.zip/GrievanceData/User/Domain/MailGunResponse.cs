﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.User.Domain
{
    public class MailGunResponse
    {
        public string Content { get; set; }
        public string ErrorMessage { get; set; }
        public bool IsSuccessfull { get; set; }
        public string MessageID { get; set; }
        public string MailGunMsgStatus { get; set; }
    }
}
