﻿using GrievanceData.User.Infrastructure.Interfaces;
using GrievanceData.User.Infrastructure.Settings;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.User.Infrastructure.Repositories
{
    internal class UserUnitOfWork : IUserUnitOfWork
    {
        //You will need UnitOfWork when you have transactions through a repo;
        private readonly IUserSqlRepository _UserRepo;
        IUserSqlRepository IUserUnitOfWork.UserSqlRepo => _UserRepo;
        public UserUnitOfWork(UserUnitOfWorkSettings uows)
        {
            _UserRepo = new UserSqlRepository(uows.commonsettings, uows.usersettings, uows.commonservice);
        }
    }
}
