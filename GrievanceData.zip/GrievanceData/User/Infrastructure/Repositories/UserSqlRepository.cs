﻿using System.Security.Cryptography;
using RestSharp;
using GrievanceData.Common.Infrastructure.Service;
using System.Text;
using GrievanceData.User.Infrastructure.Settings;
using GrievanceData.User.Infrastructure.Interfaces;
using GrievanceData.User.Domain;
using GrievanceData.Common.Infrastructure.Settings;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Microsoft.Data.SqlClient;
using AutoMapper.Internal;
using GrievanceData.GrievanceDbContext;
using System.Net;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using UserDto = GrievanceData.GrievanceContext.UserDto;
using GrievanceData.GrievanceContext;
using System.Xml.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using Aspose.Pdf.Operators;

namespace GrievanceData.User.Infrastructure.Repositories
{
    internal class UserSqlRepository : IUserSqlRepository
    {
        private readonly ICommonService _cservice;
        private readonly UserSettings _usersettings;
        private readonly SQLRepoSettings _sqlsettings;
        private CommonSettings _commonsettings;
        public OutputParameter<string> errorDescription = new OutputParameter<string>();
        public OutputParameter<int?> errorCode = new OutputParameter<int?>();

        public static UserDto user = new UserDto();

        public UserSqlRepository(CommonSettings commonsettings, UserSettings usersettings, ICommonService service)
        {
            _commonsettings = commonsettings;
            _cservice = service;
            _sqlsettings = usersettings.SQLRepo;
        }

        public async Task<bool> SendEmail(string EmailId)
        {


            return false;
        }

        public async Task<List<string>> GetUserPrivileges(int userId)
        {
            return await _cservice.GrievancesContext.Procedures.GetUserPrivileges(userId);

        }

        public async Task<UserDto> LogIn(LogInReq req)
        {
            UserDto resp = new UserDto();
            try
            {
                List<TblUsers> dbUser = await _cservice.GrievancesContext.Procedures.usp_GetUserByEmailIdAsync(req.LoginId, errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error in fetching user details for " + req.LoginId);
                }
                //TblCustomer dbCustomer = _cservice.GrievancesContext.TblCustomer.Where(c => c.CustId == dbUser[0].CustId).First();
                usp_GetCustomersByCustomerIdResult dbCustomer = _cservice.GrievancesContext.Procedures.usp_GetCustomersByCustomerIdAsync(dbUser[0].CustId, errorCode, errorDescription).Result.First();

                string Fname = string.Empty;
                string Lname = string.Empty;
                string pwd = string.Empty;
                int appId = 1;
                // bool isExpired = false;
                int numDays = 0;

                foreach (var i in dbUser)
                {
                    Fname = i.Fname;
                    Lname = i.Lname;
                    pwd = i.Password;
                    numDays = (int)(DateTime.Now - i.ModifiedDate).TotalDays;
                }

                // Add Condition to get the Customer's expiration policy days limit.
                List<usp_IsPwdExpiredResult> isExpired = await _cservice.GrievancesContext.Procedures.usp_IsPwdExpiredAsync(req.LoginId, errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error in fetching password expiration details for " + req.LoginId);
                }
                if (!ValidatePassword(pwd, req.Pwd))
                {
                    throw new Exception("Existing password did not match. Please enter correct password.");
                }
                if (dbUser[0].Status.ToLower() == "inactive" || dbUser[0].Status.ToLower() == "inact" || dbUser[0].Status.ToLower() == "i")
                {
                    throw new Exception("Your account has been disabled. Please contact your administrator.");
                }
                if ((dbUser[0].UsrEndDate < DateTime.Now))
                {
                    // var objUser = _cservice.GrievancesContext.TblUsers.Where(c => c.UserId == dbUser[0].UserId).First();
                    var users = _cservice.GrievancesContext.Procedures.usp_Get_Active_UsersAsync(dbUser[0].CustId, errorCode, errorDescription).Result;
                    var objUser = users.Where(c => c.UserId == dbUser[0].UserId).First();
                    try
                    {
                        objUser.Status = "InActive";
                        //_cservice.GrievancesContext.TblUsers.Update(objUser);
                        //_cservice.GrievancesContext.SaveChanges();
                        _cservice.GrievancesContext.Procedures.usp_InActivateUserAsync(objUser.UserId, errorCode, errorDescription);
                        throw new Exception("Your account has been disabled. Please contact your administrator.");

                    }
                    catch (Exception ex)
                    {
                        //throw new Exception("Error while fetching user details for " + req.EmailId);
                    }
                }

                ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => { return true; };
                System.Net.ServicePointManager.ServerCertificateValidationCallback += delegate { return true; };
                ServicePointManager.Expect100Continue = true;

                List<PrivilegesDto> privileges = new List<PrivilegesDto>();
                resp.otp = string.Empty;
                resp.Email = dbUser[0].Email;
                resp.access_token = CreateToken(dbUser[0].Email, appId, dbUser[0].UserId, dbUser[0].CustId);
                resp.expires_in = "1800";
                resp.applicationId = appId.ToString();
                resp.emailOtpStatus = string.Empty; ;
                resp.refresh_token = string.Empty;
                resp.mfaErrorCode = 0;
                resp.mfaErrorDesc = string.Empty;
                resp.Fname = Fname;
                resp.Lname = Lname;
                resp.isExpired = isExpired[0].Expired;
                resp.CustId = dbUser[0].CustId;
                resp.LoginId = dbUser[0].LoginId;
                resp.UserId = dbUser[0].UserId;
                resp.roleId = dbUser[0].RoleId;
                resp.Status = dbUser[0].Status;
                resp.OTPExpiryTime = dbCustomer.OTPExpiryTime;
                foreach (var userPrivilage in dbUser[0].UserPrivileges)
                {
                    var privilegesDto = new PrivilegesDto();
                    privilegesDto.Name = userPrivilage!.Privilege?.Name;
                    privilegesDto.Description = userPrivilage.Privilege?.Description;
                    privilegesDto.PrivilegeId = (int)userPrivilage.Privilege?.PrivilegeId;
                    privileges.Add(privilegesDto);
                }
                resp.Privileges = privileges;
                resp.UserPrivileges = dbUser[0].UserPrivileges.Select(x => x.Privilege.Name).ToList();
                //resp.Privilege = dbUser[0].UserPrivileges.Select(x => new PrivilegesDto
                //{ Name = x.Privilege.Name, Description = x.Privilege.Description, PrivilegeId = x.Privilege.PrivilegeId }).ToList();
                if (dbCustomer.MFAEnabled)
                {
                    RestClient client = new RestClient();
                    client.BaseUrl = new Uri(_commonsettings.MFAApiRepo.MFABaseUrl.ToString() + "/Login");
                    RestRequest request = new RestRequest();
                    request.AddParameter("EmailId", dbUser[0].Email);
                    request.AddParameter("AppId", appId);
                    request.AddParameter("Fname", Fname);
                    request.AddParameter("Lname", Lname);
                    request.AddParameter("IsAlphaNum", dbCustomer.IsAlphaNumeric);
                    request.AddParameter("PassLength", dbCustomer.OTPLength);
                    request.AddParameter("isOTPRequired", req.isOTPRequired);
                    request.Method = Method.GET;

                    var restResponse = client.Execute<LoginResponse>(request);
                    var restResponseContent = restResponse.Content;
                    var JResponse = JObject.Parse(restResponseContent);
                    int ErrorCode = Convert.ToInt32(JResponse["errorContent"]["statusCode"]);

                    if (ErrorCode == 200)
                    {
                        resp.otp = (string)JResponse["result"]["otp"];
                        resp.access_token = (string)JResponse["result"]["access_token"];
                        resp.expires_in = (string)JResponse["result"]["expires_in"];
                        resp.applicationId = (string)JResponse["result"]["applicationId"];
                        resp.emailOtpStatus = (string)JResponse["result"]["emailOtpStatus"];
                        resp.mfaErrorCode = ErrorCode;
                        resp.mfaErrorDesc = (string)JResponse["errorContent"]["message"];

                    }
                    else
                    {
                        resp.mfaErrorCode = (int)JResponse["errorContent"]["statusCode"];
                        resp.mfaErrorDesc = (string)JResponse["errorContent"]["message"];
                    }
                }


                return resp;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return resp;
        }

        public async Task<bool> SendResetPasswordNotification(int CustomerId, string emailId, string token, string newPassword)
        {
            MailGunResponse resp = new MailGunResponse();
            LoginResponse respToken = new LoginResponse();
            int appId = 1;


            RestClient client = new RestClient();

            ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => { return true; };
            System.Net.ServicePointManager.ServerCertificateValidationCallback += delegate { return true; };
            ServicePointManager.Expect100Continue = true;

            try
            {
                List<TblUsers> users = await _cservice.GrievancesContext.Procedures.usp_Get_Active_UsersAsync(Convert.ToInt32(CustomerId), errorCode, errorDescription);

                var dbUser = users.Where(c => c.Email == emailId).ToList();
                if (dbUser.Count() == 0)
                {
                    throw new Exception("Error while fetching user details to reset password " + emailId);
                }


                ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => { return true; };
                System.Net.ServicePointManager.ServerCertificateValidationCallback += delegate { return true; };
                ServicePointManager.Expect100Continue = true;

                //client.BaseUrl = new Uri(_commonsettings.MFAApiRepo.MFABaseUrl.ToString() + "/Login");
                //RestRequest request = new RestRequest();
                //request.AddParameter("EmailId", dbUser[0].Email);
                //request.AddParameter("AppId", 1);
                //request.AddParameter("Fname", dbUser[0].Fname);
                //request.AddParameter("Lname", dbUser[0].Lname);
                //request.AddParameter("IsAlphaNum", true);
                //request.AddParameter("PassLength", 4);
                //request.AddParameter("isOTPRequired", true);
                //request.Method = Method.GET;

                //var restResponse = client.Execute<LoginResponse>(request);
                //var restResponseContent = restResponse.Content;
                //var JResponse = JObject.Parse(restResponseContent);
                //int ErrorCode = Convert.ToInt32(JResponse["errorContent"]["statusCode"]);

                //if (ErrorCode == 200)
                //{
                respToken.otp = string.Empty;
                respToken.emailId = dbUser[0].Email;
                respToken.access_token = CreateToken(dbUser[0].Email, appId, dbUser[0].UserId, CustomerId);
                respToken.expires_in = "1800";
                respToken.applicationId = appId.ToString();
                respToken.emailOtpStatus = string.Empty;
                respToken.refresh_token = string.Empty;
                respToken.mfaErrorCode = 0;
                respToken.mfaErrorDesc = string.Empty;
                //respToken.fName = Fname;
                //respToken.lName = Lname;
                //respToken.isExpired = isExpired[0].Expired;
                //    }
                //    else
                //    {
                //        respToken.mfaErrorCode = (int)JResponse["errorContent"]["statusCode"];
                //        respToken.mfaErrorDesc = (string)JResponse["errorContent"]["message"];
                //    }
                //}



                string resetPwdUrl = _commonsettings.ResetPasswordUrl + "?lid=" + dbUser[0].LoginId + "&tkn=" + respToken.access_token;
                if (dbUser.Count() == 0)
                {
                    throw new Exception("Error while fetching user details for " + emailId);
                }
                await _cservice.GrievancesContext.Procedures.usp_CreatePasswordResetDetailsAsync(dbUser[0].UserId, respToken.access_token, errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while fetching user details for " + emailId);
                }

                MailGunRequest reqObj = new MailGunRequest();
                reqObj.To = emailId;
                // reqObj.Body = "\r\n<!DOCTYPE html>\r\n<html lang=\"en\" dir=\"ltr\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" style=\"color-scheme:light dark;supported-color-schemes:light dark;\">\r\n<head>\r\n<meta charset=\"utf-8\">\r\n<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n<meta name=\"viewport\" content=\"width=device-width,initial-scale=1 user-scalable=yes\">\r\n<meta name=\"format-detection\" content=\"telephone=no, date=no, address=no, email=no, url=no\">\r\n<meta name=\"x-apple-disable-message-reformatting\">\r\n<meta name=\"color-scheme\" content=\"light dark\">\r\n<meta name=\"supported-color-schemes\" content=\"light dark\">\r\n<title></title>\r\n<!--[if mso]> <noscript><xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml></noscript>\r\n<![endif]-->\r\n<!--[if mso]>\r\n<style>table,tr,td,p,span,a{mso-line-height-rule:exactly !important;line-height:120% !important;mso-table-lspace:0 !important;mso-table-rspace:0 !important;}.mso-padding{padding-top:20px !important;padding-bottom:20px !important;}\r\n</style>\r\n<![endif]-->\r\n<style>a[x-apple-data-detectors]{color:inherit!important;text-decoration:none!important;font-size:inherit!important;font-family:inherit!important;font-weight:inherit!important;line-height:inherit!important;}u+#body a{color:inherit!important;text-decoration:none!important;font-size:inherit!important;font-family:inherit!important;font-weight:inherit!important;line-height:inherit!important;}#MessageViewBody a{color:inherit!important;text-decoration:none!important;font-size:inherit!important;\r\nfont-family:inherit!important;font-weight:inherit!important;line-height:inherit!important;}:root{color-scheme:light dark;supported-color-schemes:light dark;}tr{vertical-align:middle;}p,a,li{color:#000000;font-size:16px;mso-line-height-rule:exactly;line-height:24px;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Fira Sans,Droid Sans,Helvetica Neue,sans-serif;}p:first-child{margin-top:0!important;}p:last-child{margin-bottom:0!important;}a{text-decoration:underline;font-weight:bold;color:#0000ff}.alert p{vertical-align:top;color:#fff;font-weight:500;text-align:\r\ncenter;border-radius:3px 3px 0 0;background-color:#348eda;margin:0;padding:20px;}@media only screen and (max-width:599px){.full-width-mobile{width:100%!important;height:auto!important;}.mobile-padding{padding-left:10px!important;padding-right:10px!important;}.mobile-stack{display:block!important;width:100%!important;}}@media (prefers-color-scheme:dark){body,div,table,td{background-color:#000000!important;color:#ffffff!important;}.content{background-color:#222222!important;}p,li,.white-text{color:#B3BDC4!important;}a{color:#84cfe2!important;}a span,.alert-dark p{color:#ffffff!important;}}\r\n</style>\r\n</head>\r\n<body class=\"body\" style=\"background-color:#f4f4f4;\"><div style=\"display:none;font-size:1px;color:#f4f4f4;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;\"></div> <span style=\"display:none!important;visibility:hidden;mso-hide:all;font-size:1px;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;\"> &nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;</span><div role=\"article\" aria-roledescription=\"email\" aria-label=\"Your Email\" lang=\"en\" dir=\"ltr\" style=\"font-size:16px;font-size:1rem;font-size:max(16px,1rem);background-color:#f4f4f4;\">\r\n<table align=\"center\" role=\"presentation\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse:collapse;max-width:600px;width:100%;background-color:#f4f4f4;\"><tr style=\"vertical-align:middle;\" valign=\"middle\"><td>\r\n<!--[if mso]>\r\n<table align=\"center\" role=\"presentation\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse:collapse;\"><tr><td align=\"center\">\r\n<!--<![endif]-->\r\n</td></tr><tr style=\"vertical-align:middle;\" valign=\"middle\"><td align=\"center\">\r\n<table align=\"center\" role=\"presentation\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse:collapse;max-width:600px;width:100%;background-color:#fffffe;\"><tr style=\"vertical-align:middle;\" valign=\"middle\"><td>\r\n<table align=\"center\" role=\"presentation\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse:collapse;max-width:600px;width:100%;\"><tr style=\"vertical-align:middle;\" valign=\"middle\"><td class=\"mso-padding alert alert-warning alert-dark\" align=\"center\" bgcolor=\"#348eda\" valign=\"top\"><p style=\"font-size:16px;mso-line-height-rule:exactly;line-height:5px;font-family:Arial,sans-serif;vertical-align:top;color:#fff;font-weight:500;text-align:center;border-radius:3px 3px 0 0;background-color:#348eda;margin:0;padding:20px;margin-top:0!important;margin-bottom:0!important;\"><b>Reset Password</b></p>\r\n</td></tr></table>\r\n</td></tr><tr style=\"vertical-align:middle;\" valign=\"middle\"><td align=\"center\" style=\"padding:30px;\" class=\"content\">\r\n<table align=\"center\" role=\"presentation\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse:collapse;max-width:600px;width:100%;background-color:#fffffe;\"><tr style=\"vertical-align:middle;\" valign=\"middle\"><td class=\"content\"><p style=\"color:#000000;font-size:16px;mso-line-height-rule:exactly;line-height:0px;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Fira Sans,Droid Sans,Helvetica Neue,sans-serif;margin-top:0!important;\">If you've lost your password or wish to reset it,</p>\r\n<p style=\"color:#000000;font-size:16px;mso-line-height-rule:exactly;line-height:24px;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Fira Sans,Droid Sans,Helvetica Neue,sans-serif;margin-top:0!important;\">Please click the link below to reset your password:</p>\r\n\r\n</td></tr></table>\r\n</td></tr><tr style=\"vertical-align:middle;\" valign=\"middle\"><td align=\"center\" class=\"content\">\r\n<table role=\"presentation\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" style=\"border-collapse:collapse;width:100%\"><tr style=\"vertical-align:middle;\" valign=\"middle\"><td align=\"left\" style=\"padding:0 0 0 30px;\" class=\"content\"><a href=" + resetPwdUrl + " style=\"font-size:16px;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Fira Sans,Droid Sans,Helvetica Neue,sans-serif;font-weight:bold;text-decoration:none;color:#348eda;text-underline-color:#348eda;\" >\r\n<!--[if mso]><i style=\"letter-spacing:25px;mso-font-width:-100%;mso-text-raise:30pt\" hidden>&nbsp;</i>\r\n<![endif]--><span style=\"mso-text-raise:15pt;\">Reset Password</span>\r\n<!--[if mso]><i style=\"letter-spacing:25px;mso-font-width:-100%\" hidden>&nbsp;</i>\r\n<![endif]--></a>\r\n</td></tr></table>\r\n</td></tr><tr style=\"vertical-align:middle;\" valign=\"middle\"><td align=\"center\" style=\"padding:30px;\" class=\"content\">\r\n<table align=\"center\" role=\"presentation\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"600\" style=\"border-collapse:collapse;max-width:600px;width:100%;background-color:#fffffe;\"><tr style=\"vertical-align:middle;\" valign=\"middle\"><td class=\"content\"><p style=\"color:#000000;font-size:16px;mso-line-height-rule:exactly;line-height:24px;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Oxygen,Ubuntu,Fira Sans,Droid Sans,Helvetica Neue,sans-serif;margin-top:0!important;margin-bottom:0!important;\"></p>\r\n</td></tr></table>\r\n</td></tr></table>\r\n\r\n</td></tr>\r\n<!--[if mso]>\r\n</td></tr></table>\r\n<!--<![endif]--></table></div>\r\n</body>\r\n</html>\r\n"; ;
                reqObj.Body = "<!doctype html> <html xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\"> <head> <title> </title>  <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"> <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"> <style type=\"text/css\"> #outlook a { padding: 0; } .ReadMsgBody { width: 100%; } .ExternalClass { width: 100%; } .ExternalClass * { line-height: 100%; } body { margin: 0; padding: 0; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; } table, td { border-collapse: collapse; mso-table-lspace: 0pt; mso-table-rspace: 0pt; } img { border: 0; height: auto; line-height: 100%; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; } p { display: block; margin: 13px 0; } </style>  <style type=\"text/css\"> @media only screen and (max-width:480px) { @-ms-viewport { width: 320px; } @viewport { width: 320px; } } </style> <style type=\"text/css\"> @media only screen and (min-width:480px) { .mj-column-per-100 { width: 100% !important; } } </style> <style type=\"text/css\"> </style> </head> <body style=\"background-color:#f9f9f9;\"> <div style=\"background-color:#f9f9f9;\"> <div style=\"background:#f9f9f9;background-color:#f9f9f9;Margin:0px auto;max-width:600px;\"> <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"background:#f9f9f9;background-color:#f9f9f9;width:100%;\"> <tbody> <tr> <td style=\"border-bottom:#0d6ea9 solid 5px;direction:ltr;font-size:10px;padding:20px 0;text-align:center;vertical-align:top;\"> </td> </tr> </tbody> </table> </div> <div style=\"background:#fff;background-color:#fff;Margin:0px auto;max-width:600px;\"> <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"background:#fff;background-color:#fff;width:100%;\"> <tbody> <tr> <td style=\"border:#0d6ea9 solid 1px;border-top:0px;direction:ltr;font-size:0px;padding:20px 0;text-align:center;vertical-align:top;\"> <div class=\"mj-column-per-100 outlook-group-fix\" style=\"font-size:13px;text-align:left;direction:ltr;display:inline-block;vertical-align:bottom;width:100%;\"> <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"vertical-align:bottom;\" width=\"100%\"> <tr> <td align=\"center\" style=\"font-size:0px;padding:10px 15px;padding-bottom:20px;word-break:break-word;\"> <div style=\"font-family:'Helvetica Neue',Arial,sans-serif;font-size:20px;font-weight:bold;line-height:1;text-align:center;color:#0d6ea9;\"> <img src=\"https://www.agadia.com/wp-content/uploads/2016/01/Agadia-Logo-1-e1453307476819.png\" style=\"width:30%\" id=\"logo\" data-height-percentage=\"73\" data-actual-width=\"124\" data-actual-height=\"38\"> </div> </td> </tr> <tr> <td align=\"center\" style=\"font-size:0px;padding:10px 25px;padding-bottom:30px;word-break:break-word;\"> <div style=\"font-family:'Helvetica Neue',Arial,sans-serif;font-size:20px;font-weight:bold;line-height:1;text-align:center;color:#555;\"> You requested a password reset </div> </td> </tr> <tr> <td align=\"center\" style=\"font-size:0px;padding:5px 15px;padding-bottom:20px;word-break:break-word;\"> <div style=\"font-family:'Helvetica Neue',Arial,sans-serif;font-size:14px;line-height:18px;text-align:center;color:#555;\">To reset your password, click \"Reset Password\" below.</div></br> <div style=\"font-family:'Helvetica Neue',Arial,sans-serif;font-size:14px;line-height:18px;text-align:center;color:#555;\">If you did not mean to reset your password, please ignore this email and your password </div></br> <div style=\"font-family:'Helvetica Neue',Arial,sans-serif;font-size:14px;line-height:18px;text-align:center;color:#555;\">will remain the same. The password reset link expires in 90 minutes. </div> </td> </tr> <tr> <td align=\"center\" style=\"font-size:0px;padding:5px 15px;padding-top:20px;padding-bottom:20px;word-break:break-word;\"> <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"border-collapse:separate;line-height:100%;\"> <tr> <td align=\"center\" bgcolor=\"#0d6ea9 \" role=\"presentation\" style=\"border:none;border-radius:3px;color:#ffffff;cursor:auto;padding:8px 20px;\" valign=\"middle\"> <a href=" + resetPwdUrl + " style=\"background:#0d6ea9 ;color:#ffffff;font-family:'Helvetica Neue',Arial,sans-serif;font-size:15px;font-weight:normal;line-height:120%;Margin:0;text-decoration:none;text-transform:none;\"> Reset Password </a> </td> </tr> </table> </td> </tr> </table> </div> </td> </tr> </tbody> </table> </div> <div style=\"Margin:0px auto;max-width:600px;\"> <table align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" role=\"presentation\" style=\"width:100%;\"> <tbody> <tr> <td style=\"direction:ltr;font-size:0px;padding:20px 0;text-align:center;vertical-align:top;\"> </td> </tr> </tbody> </table> </div> </div> </body> </html>";
                reqObj.Subject = "Agadia Systems";
                string jsonObj = JsonConvert.SerializeObject(reqObj);

                client = new RestClient();
                client.BaseUrl = new Uri(_commonsettings.MFAApiRepo.MFABaseUrl.ToString() + "/SendMail");

                var requestMail = new RestSharp.RestRequest(Method.POST);
                requestMail.AddHeader("Content-Type", "application/json");
                var body = jsonObj;
                requestMail.AddParameter("application/json", body, ParameterType.RequestBody);
                var response = client.Execute<MailGunResponse>(requestMail);
                resp.Content = response.Content;
                resp.IsSuccessfull = response.IsSuccessful;
                if (respToken.mfaErrorDesc == string.Empty && response.ErrorMessage != string.Empty)
                    respToken.mfaErrorDesc = response.ErrorMessage;
                resp.Content = response.Content;

            }
            catch (Exception ex)
            {
                throw new Exception("Error while fetching user details for" + emailId);
            }
            return true;
        }


        public async Task<List<TblUsers>> GetUsers(int CustId)
        {
            List<TblUsers> resp = await _cservice.GrievancesContext.Procedures.usp_Get_Active_UsersAsync(CustId, errorCode, errorDescription);

            if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
            {
                throw new Exception("Error while fetching users for Customer ID: " + CustId);
            }

            if (resp == null)
            {
                throw new Exception("Error while fetching users for Customer ID: " + CustId);
            }
            return resp;
        }

        public async Task<List<usp_GetUsersByRoleResult>> GetUsersByRole(short roleId, int customerId)
        {
            //var resp = await _cservice.GrievancesContext.TblUsers.Where(x => x.RoleId == roleId && x.Status.ToUpper() =="A" && x.UsrEndDate > DateTime.Now).ToListAsync();	
            List<usp_GetUsersByRoleResult> users = await _cservice.GrievancesContext.Procedures.usp_GetUsersByRoleAsync(roleId, customerId,errorCode, errorDescription);
            if (users == null)
            {
                throw new Exception("Error while fetching users for Role ID: " + roleId);
            }
            return users;
        }

        public async Task<List<usp_GetAllAffiliationTypesResult>> GetAllAffiliationTypes()
        {
            var resp = await _cservice.GrievancesContext.Procedures.usp_GetAllAffiliationTypesAsync(errorCode, errorDescription);

            if (resp == null)
            {
                throw new Exception("Error while fetching All Affiliation Types ");
            }
            return resp;
        }

        public async Task<List<usp_GetAffiliatedUserClientsResult>> GetAffiliatedUserClients(int userId)
        {
            var resp = await _cservice.GrievancesContext.Procedures.usp_GetAffiliatedUserClientsAsync(userId, errorCode, errorDescription);

            if (resp == null)
            {
                throw new Exception("Error while fetching Affiliated User Clients ");
            }
            return resp;
        }
        public async Task<List<usp_Get_User_DetailsResult>> GetUserDetails(int UserId)
        {
            List<usp_Get_User_DetailsResult> resp = await _cservice.GrievancesContext.Procedures.usp_Get_User_DetailsAsync(UserId, errorCode, errorDescription);
            if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
            {
                throw new Exception("Error while fetching user details of UserId: " + UserId);

            }

            if (resp == null)
            {
                throw new Exception("Error while fetching user details of UserId: " + UserId);
            }
            return resp;
        }

        public async Task<bool> RegisterUser(NewUserReq req)
        {
            try
            {

                List<TblUsers> users = await _cservice.GrievancesContext.Procedures.usp_Get_Active_UsersAsync(req.CustId, errorCode, errorDescription);

                int count = users.Count(u => u.Email == req.Email);
                if (count > 0)
                {
                    throw new Exception("Email already exists.");
                }
                int loginCount = users.Count(u => u.LoginId == req.LoginID);
                if (loginCount > 0)
                {
                    throw new Exception("Login ID already exists.");
                }
                if (req.LoginID == req.Password)
                {
                    throw new Exception("LoginId and Password should not be same.");
                }
                int UserStatus = 0;
                string pwd = CreatedSaltedHash(req.Password);

                var resp = await _cservice.GrievancesContext.Procedures.usp_CreateGrievancesUserAsync(req.CustId, req.LoginID, req.Fname, req.Lname,
                    DateTime.Now.Date, req.UsrEndDate, req.Email, req.Mobile, req.CustId, DateTime.Now.Date, req.CustId, DateTime.Now.Date, pwd, req.Mname, req.Status, req.roleId,
                    req.UserInitial, req.UserTypeId, req.clientIds, errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while saving new user " + req.LoginID);

                }
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            //return false;
        }

        public async Task<bool> UpdateUser(UpdateUserReq req)
        {
            List<TblUsers> dbUser = await _cservice.GrievancesContext.Procedures.usp_GetUserByEmailIdAsync(req.LoginID, errorCode, errorDescription);
            if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
            {
                throw new Exception("Error while fetching user details for " + req.LoginID);

            }
            if (dbUser.Count() < 1)
            {
                throw new Exception("Error while fetching user details for " + req.Email);
            }

            string pwd = string.Empty;

            foreach (var i in dbUser)
            {
                pwd = i.Password;
            }

            try
            {
                if (req.UsrEndDate.Date < DateTime.Now.Date)
                {
                    req.Status = "I";

                }
                else
                {
                    req.Status = "A";
                }
                //if (req.Status.ToLower() == "inactive" || req.Status.ToLower() == "i")
                //{
                //    req.UsrEndDate = DateTime.Parse(DateTime.Now.AddDays(-1).ToShortDateString()).AddHours(23).AddMinutes(59).AddSeconds(59);
                //}
                var resp = await _cservice.GrievancesContext.Procedures.usp_UpdateGrievancesUserAsync(req.UserID, req.CustId, req.LoginID, req.Fname, req.Lname,
                  DateTime.Now.Date, req.UsrEndDate, req.Email, req.Mobile, req.CustId, DateTime.Now.Date, req.UserID, DateTime.Now.Date, pwd, req.Mname, req.Status, req.roleId,
                  req.UserInitial, req.UserTypeId, req.clientIds, errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while updating user details for " + req.Email);

                }

                return true;
            }
            catch (Exception ex)
            {

            }
            return false;
        }

        public static string CreatedSaltedHash(string password)
        {
            byte[] key;
            byte[] salt;
            // industry recommanded size of 32-bytes or 64-byte salt
            // specify that we want to randomly generate a 32-byte salt
            using (var deriveBytes = new Rfc2898DeriveBytes(password, 32, 5000))
            {
                salt = deriveBytes.Salt;
                key = deriveBytes.GetBytes(32);  // derive a 32-byte key
                // industry recommanded size of at least 256 bits (32 bytes) fixed length hash
            }
            return Convert.ToBase64String(salt) + Convert.ToBase64String(key);
        }

        /// <summary>
        /// Given a salted hash with a 32-byte salt (44 chars in base64 encoding), separate the salt and the hash
        /// </summary>
        /// <param name="saltAndHash">the salted hash with salt first</param>
        /// <returns>Tuple (salt, hash)</returns>
        public static Tuple<string, string> GetSaltAndHash(string saltAndHash)
        {
            // we use 32-byte salts, base 64 encoded is 44 chars
            int saltSize = 44;
            var salt = saltAndHash.Substring(0, saltSize);
            string hash = saltAndHash.Substring(saltSize, saltAndHash.Length - saltSize);
            return Tuple.Create<string, string>(salt, hash);
        }

        /// <summary>
        /// Compute a hash given a key and salt
        /// </summary>
        /// <param name="salt">The salt</param>
        /// <param name="key">The key</param>
        /// <returns>Computed hash</returns>
        public static string ComputeHash(string salt, string key)
        {
            byte[] newKey;
            byte[] saltBytes = Convert.FromBase64String(salt);

            // specify that we want to use a 32-byte salt
            using (var deriveBytes = new Rfc2898DeriveBytes(key, saltBytes, 5000))
            {
                newKey = deriveBytes.GetBytes(32);  // derive a 32-byte key
            }
            return Convert.ToBase64String(newKey);
        }

        /// <summary>
        /// Validate the password
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public static bool ValidatePassword(string SaltedHash, string InputPassword)
        {
            var saltAndHashTuple = UserSqlRepository.GetSaltAndHash(SaltedHash);

            var dbSalt = saltAndHashTuple.Item1;
            var dbHashKey = saltAndHashTuple.Item2; //

            var computedHash = UserSqlRepository.ComputeHash(dbSalt, InputPassword);

            // compare the salted hash in the DB to the one we get here
            if (string.Compare(computedHash, dbHashKey) == 0)
                return true;
            else return false;
        }

        /// <summary>
        /// New Passowrd will be update here.
        /// </summary>
        /// <param name="req"></param>
        /// <returns></returns>
        public async Task<bool> UpdatePassword(UpdatePassword req)
        {
            TblUsers dbUser = null;
            List<TblUsers> users = await _cservice.GrievancesContext.Procedures.usp_Get_Active_UsersAsync(req.CustId, errorCode, errorDescription);
            dbUser = users.Where(t => t.UserId == req.UserID).First();

            try
            {
                if (!ValidatePassword(dbUser.Password, req.OldPassword))
                {
                    throw new Exception("Existing password did not match. Please enter correct password.");
                }
                if (req.NewPassword == dbUser.LoginId)
                {
                    throw new Exception("LoginId and Password should not be same.");
                }

                var recentPasswords = _cservice.GrievancesContext.Procedures.VerifyPasswordExists(req.UserID, errorCode, errorDescription);
                foreach (var item in recentPasswords.Result)
                {
                    if (ValidatePassword(item.Password, req.NewPassword))
                    {
                        throw new Exception("Please choose a password that is different from the last 10 passwords used.");
                    }
                }
                dbUser.Password = CreatedSaltedHash(req.NewPassword);
                dbUser.UsrEffectiveDate = DateTime.Now.Date;
                dbUser.LastPwdCreated = DateTime.Now.Date;
                //_cservice.GrievancesContext.TblUsers.Update(dbUser);
                //_cservice.GrievancesContext.SaveChanges();
               
                var resp = await _cservice.GrievancesContext.Procedures.usp_UpdateGrievancesUserAsync(req.UserID, req.CustId, dbUser.LoginId, dbUser.Fname, dbUser.Lname,
                  DateTime.Now.Date, dbUser.UsrEndDate, dbUser.Email, dbUser.Mobile, req.UserID, DateTime.Now.Date, req.UserID, DateTime.Now.Date, dbUser.Password, dbUser.Mname, dbUser.Status, dbUser.RoleId,
                  dbUser.UserInitial, dbUser.UserTypeId, "", errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while updating user details for " + dbUser.Email);
                }
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        /// <summary>
        /// New Passowrd will be reset here.
        /// </summary>
        /// <param name="req"></param>
        /// <returns></returns>
        public async Task<bool> ResetPassword(ResetPassword req)
        {
            try
            {
                //var dbUser = _cservice.GrievancesContext.TblUsers.Where(c => c.LoginId == req.loginId).ToList();
                List<TblUsers> dbUser = await _cservice.GrievancesContext.Procedures.usp_Get_Active_UsersAsync(req.CustomerId, errorCode, errorDescription);

                if (dbUser.Count() == 0)
                {
                    throw new Exception("Error while fetching user details to reset password " + req.loginId);
                }
                if (req.NewPassword == dbUser[0].LoginId)
                {
                    throw new Exception("LoginId and Password should not be same.");
                }
                string newPassword = CreatedSaltedHash(req.NewPassword);

                var recentPasswords = _cservice.GrievancesContext.Procedures.VerifyPasswordExists(dbUser[0].UserId, errorCode, errorDescription);
                foreach (var item in recentPasswords.Result)
                {
                    if (ValidatePassword(item.Password, req.NewPassword))
                    {
                        throw new Exception("Please choose a password that is different from the last 10 passwords used.");
                    }
                }
                await _cservice.GrievancesContext.Procedures.usp_ResetPasswordAsync(dbUser[0].UserId, req.Token, newPassword, errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error in reset password " + req.loginId);
                }
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<MemberEligibilityResp> GetMemberEligibility(MemberEligibilityReq req)
        {
            MemberEligibilityResp resp = new MemberEligibilityResp();
            RestClient client = new RestClient();

            try
            {
                // Step 1: Get Elgibility Preference through Web Service Call like: strEligibilityPrefernece = objDisableOneworld.GetCustomerConfiguration("EligibilityPreferenceType", long.Parse(strCustomerId));
                // Step 2: If EligibilityPrefernece value is WS then Customer is configured with for service and not DB, Configure the XML for service request.
                // Step 3: If EligibilityPrefernece value is WS then Use table [dbo].[tblServiceLocation] to create customer specifc Configuration call

                // Step 1: Another class: to idenitfy WS or DB
                // Step 2: Calling WebServices according customerInfo: ECM call and that will be one call for identified customer 
                // Step 3: Another class for database name : Our GrivanceDB or Another database which will need flat files of Customers. 
                //


            }
            catch (Exception ex)
            {
                throw new Exception("Error while fetching user details for" + req.MbrNbr);
            }
            return resp;
        }

        private string CreateToken(string EmailId, int AppId, long UserId,int CustomerId)
        {
            List<Claim> claims = new List<Claim>
            {
                new Claim(ClaimTypes.Email, EmailId),
                new Claim("UserId", UserId.ToString()),
                 new Claim("CustomerId", CustomerId.ToString())
            };

            var claim = new Claim(ClaimTypes.Role, AppId.ToString());
            claims.Add(claim);



            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(
                "my top secret key"));

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

            var token = new JwtSecurityToken(
                claims: claims,
                expires: DateTime.Now.AddDays(1),
                signingCredentials: creds);

            string jwt = new JwtSecurityTokenHandler().WriteToken(token);

            return jwt;
        }

        private string CreateRandomOTP(int length, bool isAlphaNum)
        {
            string validChars;
            Random random = new Random();
            char[] chars = new char[length];

            if (isAlphaNum)
                validChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890!@#$%^&*?";
            else
                validChars = "1234567890";

            for (int i = 0; i < length; i++)
            {
                chars[i] = validChars[random.Next(0, validChars.Length)];
            }
            return new string(chars);
        }

        public async Task<List<Roles>> GetRolesByCustomerId(int CustId)
        {
            List<Roles> resp = await _cservice.GrievancesContext.Procedures.usp_GetAllRolesByCustomerIdAsync(CustId, errorCode, errorDescription);
            if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
            {
                throw new Exception("Error while fetching users for Customer ID: " + CustId);
            }

            if (resp == null)
            {
                throw new Exception("Error while fetching users for Customer ID: " + CustId);
            }
            return resp;
        }

        public async Task<OTPVerificationResponse> TwoStepsAuthentication(string EmailId, string Otp, byte OtpExpiryTime)
        {
            RestClient client = new RestClient();
            client.BaseUrl = new Uri(_commonsettings.MFAApiRepo.MFABaseUrl.ToString() + "/TwoStepsAuthentication");
            OTPVerificationRequest myDynamic = new OTPVerificationRequest { EmailId = EmailId, OTP = Otp, OTPExpiryTime = OtpExpiryTime };
            string jsonObj = JsonConvert.SerializeObject(myDynamic);
            var requestMail = new RestSharp.RestRequest(Method.POST);
            requestMail.AddHeader("Content-Type", "application/json");
            var body = jsonObj;
            requestMail.AddParameter("application/json", body, ParameterType.RequestBody);
            var response = client.Execute<OTPVerificationResponse>(requestMail);
            var restResponseContent = response.Content;
            var JResponse = JObject.Parse(restResponseContent);
            int ErrorCode = Convert.ToInt32(JResponse["errorContent"]["statusCode"]);

            return new OTPVerificationResponse { IsSuccess = (JResponse["result"]["isSuccess"].ToString() == "False" ? false : true), errorMessage = (string)JResponse["result"]["errorMessage"] };
        }

        public async Task<string> GetRoleByUserId(int userId,int customerId)
        {
            string resp = string.Empty;
            List<Roles> roles= await GetRolesByCustomerId(customerId);
            List<TblUsers> users = await _cservice.GrievancesContext.Procedures.usp_Get_Active_UsersAsync(customerId, errorCode, errorDescription);
            List<TblUsers> dboUsers = users.Where(u => u.UserId == userId).ToList();

            if (dboUsers == null)
            {
                throw new Exception("Error while fetching roles for User ID: " + userId);
            }
            else
            {
                var objRole = roles.Where(d => d.RoleId == dboUsers[0].RoleId).ToList();
                if(objRole==null)
                    throw new Exception("Error while fetching roles for User ID: " + userId);

                resp = objRole[0].RoleName;

            }

            return resp;
        }



    }
}
