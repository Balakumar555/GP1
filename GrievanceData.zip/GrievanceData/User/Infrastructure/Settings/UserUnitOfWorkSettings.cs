﻿using GrievanceData.Common.Infrastructure.Service;
using GrievanceData.Common.Infrastructure.Settings;

namespace GrievanceData.User.Infrastructure.Settings
{
    public class UserUnitOfWorkSettings
    {
        public CommonSettings commonsettings { get; set; }
        public ICommonService commonservice { get; set; }
        public UserSettings usersettings { get; set; }
    }
}
