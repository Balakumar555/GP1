﻿using GrievanceData.User.Domain;
using GrievanceData.User.Services;

namespace GrievanceData.User.Infrastructure.Interfaces
{
    internal interface IUserSqlRepository : IQueueEntity
    {
        Task<GrievanceContext.UserDto> LogIn(LogInReq req);
        Task<List<TblUsers>> GetUsers(int req);
        Task<List<usp_Get_User_DetailsResult>> GetUserDetails(int req);
        Task<bool> SendEmail(string EmailId);
        Task<bool> RegisterUser(NewUserReq request);
        Task<bool> UpdateUser(UpdateUserReq req);
        Task<bool> UpdatePassword(UpdatePassword req);
        Task<bool> ResetPassword(ResetPassword req);
        Task<bool> SendResetPasswordNotification(int CustomerId, string emailId,string token, string newPassword);
        Task<MemberEligibilityResp> GetMemberEligibility(MemberEligibilityReq req);
        Task<List<Roles>> GetRolesByCustomerId(int custId);
        Task<List<string>> GetUserPrivileges(int userId);
        Task<OTPVerificationResponse> TwoStepsAuthentication(string EmailId, string Otp, byte OtpExpiryTime);			
        Task<string> GetRoleByUserId(int userId,int customerId);
        Task<List<usp_GetUsersByRoleResult>> GetUsersByRole(short roleId,int customerId);
        Task<List<usp_GetAllAffiliationTypesResult>> GetAllAffiliationTypes();
        Task<List<usp_GetAffiliatedUserClientsResult>> GetAffiliatedUserClients(int userId);
    }
}
