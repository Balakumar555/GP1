﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.User.Infrastructure.Interfaces
{
    internal interface IUserUnitOfWork
    {
        IUserSqlRepository UserSqlRepo { get; }
    }
}
