﻿using GrievanceData.Common.Infrastructure.Service;
using GrievanceData.Common.Infrastructure.Settings;

namespace GrievanceData.Queue.Infrastructure.Settings
{
    public class QueueUnitOfWorkSettings
    {
        public CommonSettings commonsettings { get; set; }
        public ICommonService commonservice { get; set; }
        public QueueSettings queuesettings { get; set; }
    }
}
