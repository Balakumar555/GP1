﻿using GrievanceData.Common.Infrastructure.Service;
using GrievanceData.Common.Infrastructure.Settings;
using GrievanceData.GrievanceDbContext;
using GrievanceData.Member.Infrastructure.Settings;
using GrievanceData.Queue.Infrastructure.Interfaces;
using GrievanceData.User.Domain;
using GrievanceData.User.Infrastructure.Settings;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using UserDto = GrievanceData.GrievanceContext.UserDto;
using GrievanceData.Queue.Infrastructure.Settings;

namespace GrievanceData.Queue.Infrastructure.Repositories
{
    internal class QueueSqlRepository : IQueueSqlRepository
    {
        private readonly ICommonService _cservice;
        private readonly QueueSettings _queuesettings;
        private readonly GrievanceData.Queue.Infrastructure.Settings.SQLRepoSettings _sqlsettings;
        private CommonSettings _commonsettings;
        public OutputParameter<string> errorDescription = new OutputParameter<string>();
        public OutputParameter<byte?> errorCode = new OutputParameter<byte?>();

        public QueueSqlRepository(CommonSettings commonsettings, QueueSettings usersettings, ICommonService service)
        {
            _commonsettings = commonsettings;
            _cservice = service;
            _sqlsettings = usersettings.QueueRepo;
        }


        public async Task<List<usp_GetQueueColumnConfigurationResult>> GetQueueColumnConfiguration(int? queueId)
        {
            var resp = await _cservice.GrievancesContext.Procedures.usp_GetQueueColumnConfigurationAsync(queueId, errorCode, errorDescription);

            if (resp == null)
            {
                throw new Exception("Error while fetching QUeue Column Configuration.");
            }
            return resp;
        }

        public async Task<List<usp_GetUserQueuesResult>> GetUserQueues(int? userId,int? customerId)
        {
            var resp = await _cservice.GrievancesContext.Procedures.usp_GetUserQueuesAsync(userId, customerId, errorCode, errorDescription);

            if (resp == null)
            {
                throw new Exception("Error while fetching Queue Column Configuration.");
            }
            return resp;
        }

        public async Task<List<usp_GetMyOpenCasesQueueDataResult>> GetMyOpenCasesQueueData(int? userId, int? customerId, string? requestTypes,
            string? clientTypeIds,
            string? planTypeIds,
            string? benefitDeterminations,
            string? methodReceived, bool? isExportToExcel)
        {
            var resp = await _cservice.GrievancesContext.Procedures.usp_GetMyOpenCasesQueueDataAsync(userId, customerId, isExportToExcel,requestTypes,clientTypeIds,planTypeIds,benefitDeterminations,methodReceived, errorCode, errorDescription);
            if (resp == null)
            {
                throw new Exception("Error while fetching My Open Cases Data.");
            }
            return resp;
        }




    }
}
