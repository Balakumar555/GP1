﻿using GrievanceData.Queue.Infrastructure.Interfaces;
using GrievanceData.Queue.Infrastructure.Settings;

namespace GrievanceData.Queue.Infrastructure.Repositories
{
    internal class QueueUnitOfWork : IQueueUnitOfWork
    {
        //You will need UnitOfWork when you have transactions through a repo;
        private readonly IQueueSqlRepository _QueueRepo;
        IQueueSqlRepository IQueueUnitOfWork.QueueSqlRepo => _QueueRepo;
        public QueueUnitOfWork(QueueUnitOfWorkSettings uows)
        {
            _QueueRepo = new QueueSqlRepository(uows.commonsettings, uows.queuesettings, uows.commonservice);
        }
    }
}
