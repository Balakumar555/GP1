﻿using GrievanceData.User.Domain;
using GrievanceData.Queue.Services;

namespace GrievanceData.Queue.Infrastructure.Interfaces
{
    internal interface IQueueSqlRepository : IQueueEntity
    {
        Task<List<usp_GetQueueColumnConfigurationResult>> GetQueueColumnConfiguration(int? queueId);
        Task<List<usp_GetUserQueuesResult>> GetUserQueues(int? userId, int? customerId);
        Task<List<usp_GetMyOpenCasesQueueDataResult>> GetMyOpenCasesQueueData(int? userId, int? customerId, string? requestTypes,
            string? clientTypeIds,
            string? planTypeIds,
            string? benefitDeterminations,
            string? methodReceived, bool? isExportToExcel);
    }
}
