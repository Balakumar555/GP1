﻿using Aspose.Pdf.Operators;
using GrievanceData.Common.Infrastructure.Service;
using GrievanceData.Common.Infrastructure.Settings;
using GrievanceData.GrievanceContext;
using GrievanceData.GrievanceDbContext;
using GrievanceData.Queue.Infrastructure.Interfaces;
using GrievanceData.Queue.Infrastructure.Repositories;
using GrievanceData.Queue.Infrastructure.Settings;
using GrievanceData.User.Domain;
using GrievanceData.User.Infrastructure.Interfaces;
using GrievanceData.User.Infrastructure.Repositories;
using GrievanceData.User.Infrastructure.Settings;
using Newtonsoft.Json.Linq;
using UserDto = GrievanceData.GrievanceContext.UserDto;

namespace GrievanceData.Queue.Services
{
    public class QueueService : IQueueService
    {
        private readonly IQueueUnitOfWork uow;
        private readonly ICommonService _cservice;
        private readonly QueueSettings _usersettings;

        public QueueService(GrievancesContext context, CommonSettings commonsettings, QueueSettings queuesettings, ICommonService cservice)
        {
            if (uow == null)
                uow = uow ?? new QueueUnitOfWork(new QueueUnitOfWorkSettings
                {
                    queuesettings = queuesettings,
                    commonsettings = commonsettings,
                    commonservice = cservice
                });

            _cservice = cservice;
            _usersettings = queuesettings;
        }


        public async Task<List<usp_GetMyOpenCasesQueueDataResult>> GetMyOpenCasesQueueData(int? userId, int? customerId, string? requestTypes,
            string? clientTypeIds,
            string? planTypeIds,
            string? benefitDeterminations,
            string? methodReceived, bool? isExportToExcel)
        {
            List<usp_GetMyOpenCasesQueueDataResult> resp = await uow.QueueSqlRepo.GetMyOpenCasesQueueData(userId, customerId, requestTypes,clientTypeIds,planTypeIds,benefitDeterminations,methodReceived,isExportToExcel);
            return resp;

        }

        
        public async Task<List<usp_GetQueueColumnConfigurationResult>> GetQueueColumnConfiguration(int? queueId)
        {
            List<usp_GetQueueColumnConfigurationResult> resp = await uow.QueueSqlRepo.GetQueueColumnConfiguration(queueId);
            return resp;
        }

       
        public async Task<List<usp_GetUserQueuesResult>> GetUserQueues(int? userId,int? customerId)
        {
            List<usp_GetUserQueuesResult> resp = await uow.QueueSqlRepo.GetUserQueues(userId, customerId);
            return resp;

        }


    }


}

