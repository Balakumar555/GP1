﻿using GrievanceData.Common.Infrastructure.Service;
using GrievanceData.Common.Infrastructure.Settings;

namespace GrievanceData.Case.Infrastructure.Settings
{
    public class CaseUnitOfWorkSettings
    {
        public CommonSettings commonsettings { get; set; }
        public ICommonService commonservice { get; set; }
        public CaseSettings casesettings { get; set; }
    }
}
