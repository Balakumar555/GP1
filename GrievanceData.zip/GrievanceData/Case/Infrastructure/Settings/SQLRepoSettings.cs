namespace GrievanceData.Case.Infrastructure.Settings
{
    public class SQLRepoSettings
    {
        // public string GetUserToken { get; set; }
    }
}