﻿using GrievanceData.Case.Domain;
using GrievanceData.Case.Services;

namespace GrievanceData.Case.Infrastructure.Interfaces
{
    internal interface ICaseSqlRepository
    {
		Task<bool> CreateGrievancesCaseAsync(CaseDetailDto caseDetail);
		Task<List<CaseStatusDto>> GetCaseStatusAsync();
		Task<CaseDetailDto> GetCaseDetailByIdAsync(long? caseId, long? customerId,int userId);
		Task<List<CaseDetailListDto>> GetAllCaseDetail(long? customerId);
		Task<int> CreateGrievancesDraftCaseAsync(DraftCaseDetailDto caseDetail);
		Task<int> DiscardGrievancesDraftCaseAsync(int caseDetailId);
        Task<List<CategoryDto>> GetCategoriesAsync();
		Task<List<usp_GetCaseData_DashboardResult>> GetDashboardData(string? mbi, string? caseId, string? memberNumber, DateTime? dob, string? firstName, string? lastName,int userId);
		Task<bool> InsertOrDeleteCaseAttachments(long caseId, long docId, int userId, bool isDelete,string fileName);
		Task<List<usp_GetCaseAttachmentsResult>> GetCaseAttachments(long? CustomerId, long? CaseId);
		Task<List<usp_GetCaseCommentByCaseIdResult>> GetCaseComments(long? caseId);
		Task<int> CreateCaseComment(CommentDto commentDetail, long createdBy);
		Task<int> UpdateCaseComment(CommentDto commentDetail, long modifiedBy);
		Task<bool> UpdateGrievancesCaseAsync(CaseDetailUpdateDto caseDetail, long modifiedBy);
		Task<List<NMIReason>> GetNMIReasonAsync(short currentCustomerId);
		Task<List<NMIOutcome>> GetNMIOutcomeAsync(short currentCustomerId);
		Task<List<ExtensionReason>> GetExtensionReasonAsync(short currentCustomerId);
		Task<List<CaseStatusDto>> GetAllEligibleActionsAsync(int caseId);
	}
}
