﻿using GrievanceData.Case.Infrastructure.Interfaces;
using GrievanceData.Case.Infrastructure.Settings;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.Case.Infrastructure.Repositories
{
    internal class CaseUnitOfWork : ICaseUnitOfWork
    {
        //You will need UnitOfWork when you have transactions through a repo;
        private readonly ICaseSqlRepository _CaseRepo;
        ICaseSqlRepository ICaseUnitOfWork.CaseSqlRepo => _CaseRepo;
        public CaseUnitOfWork(CaseUnitOfWorkSettings cows)
        {
			_CaseRepo = new CaseSqlRepository(cows.commonsettings, cows.casesettings, cows.commonservice);
        }
    }
}
