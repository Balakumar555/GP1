﻿using System.Security.Cryptography;
using RestSharp;
using GrievanceData.Common.Infrastructure.Service;
using System.Text;
using GrievanceData.Case.Infrastructure.Settings;
using GrievanceData.Case.Infrastructure.Interfaces;
using GrievanceData.Case.Domain;
using GrievanceData.Common.Infrastructure.Settings;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Microsoft.Data.SqlClient;
using AutoMapper.Internal;
using GrievanceData.GrievanceDbContext;
using System.Net;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using UserDto = GrievanceData.GrievanceContext.UserDto;
using Microsoft.EntityFrameworkCore;
using GrievanceData.GrievanceContext;
using System.Data;
using Microsoft.CodeAnalysis.Operations;

namespace GrievanceData.Case.Infrastructure.Repositories
{
    internal class CaseSqlRepository : ICaseSqlRepository
    {
        private readonly ICommonService _cservice;
        // private readonly UserSettings _usersettings;
        private readonly SQLRepoSettings _sqlsettings;
        private CommonSettings _commonsettings;
        public OutputParameter<string> errorDescription = new OutputParameter<string>();
        public OutputParameter<int?> errorCode = new OutputParameter<int?>();

        public static UserDto user = new UserDto();

        public CaseSqlRepository(CommonSettings commonsettings, CaseSettings casesettings, ICommonService service)
        {
            _commonsettings = commonsettings;
            _cservice = service;
            _sqlsettings = casesettings.SQLRepo;
        }

        public async Task<bool> CreateGrievancesCaseAsync(CaseDetailDto caseDetail)
        {
            try
            {
				//await _cservice.GrievancesContext.Procedures.CreateGrievancesCaseAsync(caseDetail.CaseDetailId, caseDetail.StatusId, caseDetail.CustomerId, caseDetail.CategoryId, caseDetail.IncidentDate, caseDetail.DueDate, caseDetail.ReceivedDate
				//    , caseDetail.Method, caseDetail.Requestor, caseDetail.RequestType, caseDetail.SubCategory, caseDetail.Source, caseDetail.Urgency, caseDetail.HighPriority, caseDetail.ExtensionTaken,
				//    caseDetail.PartType, caseDetail.ComplianceCase, caseDetail.GoodCause, caseDetail.Description, caseDetail.FirstTier, caseDetail?.MemberInfo?.FirstName, caseDetail?.MemberInfo?.MiddleName, caseDetail?.MemberInfo?.lastName, caseDetail?.MemberInfo?.DateOfBirth,
				//    caseDetail?.MemberInfo?.Gender, caseDetail?.MemberInfo?.State, caseDetail?.MemberInfo?.City, caseDetail?.MemberInfo?.Zip, "USA", caseDetail?.MemberInfo?.Email, caseDetail?.MemberInfo?.AddressLine1, caseDetail?.MemberInfo?.AddressLine2, caseDetail?.MemberInfo?.HomePhone, caseDetail?.MemberInfo?.WorkPhone, caseDetail?.MemberInfo?.Fax, caseDetail?.MemberInfo?.CellPhone, caseDetail?.MemberInfo?.CommunicationPrefrence,
				//    caseDetail.IsAor, caseDetail?.AorInfo?.aorRelationship, caseDetail?.AorInfo?.aorFormReceivedDate, caseDetail?.AorInfo?.aorPhone, caseDetail?.AorInfo?.aorAddressLine1,
				//    caseDetail?.AorInfo?.aorState, caseDetail?.AorInfo?.aorCity, caseDetail?.AorInfo?.aorZip, "USA", caseDetail?.AorInfo?.aorEmail, caseDetail?.AorInfo?.aorFirstName,
				//    caseDetail?.AorInfo?.aorMiddleName, caseDetail?.AorInfo?.aorLastName, caseDetail?.AorInfo?.aorAddressLine2, caseDetail?.AorInfo?.memberSignatureDate, caseDetail?.AorInfo?.apointeeSignatureDate, caseDetail?.AorInfo?.formReceived,
				//    caseDetail.AssigneeId, caseDetail?.CreatedBy, DateTime.Now, caseDetail?.MemberInfo?.LanguagePrefrence, caseDetail?.MemberInfo?.MBI, caseDetail?.MemberInfo?.MemberNumber, caseDetail?.MemberInfo?.PlanId, caseDetail?.MemberInfo?.ClientId, errorCode, errorDescription);

				await _cservice.GrievancesContext.Procedures.CreateGrievancesCaseAsync(caseDetail.CaseDetailId, caseDetail.StatusId, caseDetail.CustomerId, caseDetail.CategoryId, caseDetail.IncidentDate, caseDetail.DueDate, caseDetail.ReceivedDate
				   , caseDetail.Method, caseDetail.Requestor, caseDetail.RequestType, caseDetail.SubCategory, caseDetail.Source, caseDetail.Urgency, caseDetail.HighPriority, caseDetail.ExtensionTaken,
				   caseDetail.PartType, caseDetail.ComplianceCase, caseDetail.GoodCause, caseDetail.Description, caseDetail.FirstTier, caseDetail?.MemberInfo?.FirstName, caseDetail?.MemberInfo?.MiddleName, caseDetail?.MemberInfo?.lastName, caseDetail?.MemberInfo?.DateOfBirth,
				   caseDetail?.MemberInfo?.Gender, caseDetail?.MemberInfo?.State, caseDetail?.MemberInfo?.City, caseDetail?.MemberInfo?.Zip, "USA", caseDetail?.MemberInfo?.Email, caseDetail?.MemberInfo?.AddressLine1, caseDetail?.MemberInfo?.AddressLine2, caseDetail?.MemberInfo?.HomePhone, caseDetail?.MemberInfo?.WorkPhone, caseDetail?.MemberInfo?.Fax, caseDetail?.MemberInfo?.CellPhone, caseDetail?.MemberInfo?.CommunicationPrefrence,
				   caseDetail.IsAor,caseDetail.MemberInfo?.IsPoa, caseDetail?.AorInfo?.aorRelationship, caseDetail?.AorInfo?.aorFormReceivedDate, caseDetail?.AorInfo?.aorPhone, caseDetail?.AorInfo?.aorAddressLine1,
				   caseDetail?.AorInfo?.aorState, caseDetail?.AorInfo?.aorCity, caseDetail?.AorInfo?.aorZip, "USA", caseDetail?.AorInfo?.aorEmail, caseDetail?.AorInfo?.aorFirstName,
				   caseDetail?.AorInfo?.aorMiddleName, caseDetail?.AorInfo?.aorLastName, caseDetail?.AorInfo?.aorAddressLine2, caseDetail?.AorInfo?.memberSignatureDate, caseDetail?.AorInfo?.apointeeSignatureDate, caseDetail?.AorInfo?.formReceived,
				   caseDetail.AssigneeId, caseDetail?.CreatedBy, DateTime.Now, caseDetail?.MemberInfo?.LanguagePrefrence, caseDetail?.MemberInfo?.MBI, caseDetail?.MemberInfo?.MemberNumber, caseDetail?.MemberInfo?.PlanId, caseDetail?.MemberInfo?.ClientId,
                   caseDetail.AorInfo?.aorTerminationDate, caseDetail.PoaInfo?.poaEffectiveDate, caseDetail.PoaInfo?.poaTerminationDate, caseDetail.PoaInfo?.poaRelationship, caseDetail.PoaInfo?.poaFormReceivedDate, caseDetail.PoaInfo?.poaPhone, caseDetail.PoaInfo?.poaAddressLine1, caseDetail.PoaInfo?.poaState, caseDetail.PoaInfo?.poaCity, caseDetail.PoaInfo?.poaZip,"USA", caseDetail.PoaInfo?.poaEmail, caseDetail.PoaInfo?.poaFirstName, caseDetail.PoaInfo?.poaMiddleName, caseDetail.PoaInfo?.poaLastName, caseDetail.PoaInfo?.poaAddressLine2, caseDetail.PoaInfo?.poaFormReceived, errorCode, errorDescription);
				if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while creating a case ");

                }
                return true;
            }
            catch (Exception ex)
            {

            }
            return false;
        }

		public async Task<bool> UpdateGrievancesCaseAsync(CaseDetailUpdateDto caseDetail, long modifiedBy)
		{
			try
			{
				await _cservice.GrievancesContext.Procedures.UpdateGrievancesCaseAsync(caseDetail.CaseInfo.CaseDetailId, caseDetail.StatusId, caseDetail.CaseInfo.CustomerId, caseDetail.CaseInfo.CategoryId, caseDetail.CaseInfo.IncidentDate, caseDetail.CaseInfo.DueDate, caseDetail.CaseInfo.ReceivedDate
					, caseDetail.CaseInfo.Method, caseDetail.CaseInfo.Requestor, caseDetail.CaseInfo.RequestType, caseDetail.CaseInfo.SubCategory, caseDetail.CaseInfo.Source, caseDetail.CaseInfo.Urgency, caseDetail.CaseInfo.HighPriority, caseDetail.CaseInfo.ExtensionTaken,
					caseDetail.CaseInfo.PartType, caseDetail.CaseInfo.ComplianceCase, caseDetail.CaseInfo.GoodCause, caseDetail.CaseInfo.Description, caseDetail.CaseInfo.FirstTier, caseDetail?.MemberInfo?.FirstName, caseDetail?.MemberInfo?.MiddleName, caseDetail?.MemberInfo?.lastName, caseDetail?.MemberInfo?.DateOfBirth,
					caseDetail?.MemberInfo?.Gender, caseDetail?.MemberInfo?.State, caseDetail?.MemberInfo?.City, caseDetail?.MemberInfo?.Zip, "USA", caseDetail?.MemberInfo?.Email, caseDetail?.MemberInfo?.AddressLine1, caseDetail?.MemberInfo?.AddressLine2, caseDetail?.MemberInfo?.HomePhone, caseDetail?.MemberInfo?.WorkPhone, caseDetail?.MemberInfo?.Fax, caseDetail?.MemberInfo?.CellPhone, caseDetail?.MemberInfo?.CommunicationPrefrence,
					caseDetail.CaseInfo.IsAor, caseDetail?.AorInfo?.aorRelationship, caseDetail?.AorInfo?.aorFormReceivedDate, caseDetail?.AorInfo?.aorPhone, caseDetail?.AorInfo?.aorAddressLine1,
					caseDetail?.AorInfo?.aorState, caseDetail?.AorInfo?.aorCity, caseDetail?.AorInfo?.aorZip, "USA", caseDetail?.AorInfo?.aorEmail, caseDetail?.AorInfo?.aorFirstName,
					caseDetail?.AorInfo?.aorMiddleName, caseDetail?.AorInfo?.aorLastName, caseDetail?.AorInfo?.aorAddressLine2, caseDetail?.AorInfo?.memberSignatureDate, caseDetail?.AorInfo?.apointeeSignatureDate, caseDetail?.AorInfo?.formReceived,
					caseDetail.CaseInfo.AssigneeId,modifiedBy, caseDetail?.MemberInfo?.LanguagePrefrence,caseDetail?.MemberInfo?.MemberRepresentativeId, caseDetail?.CaseInfo.ClosedDate,caseDetail?.NMIInfo?.NMIReason, caseDetail?.NMIInfo?.NMIDescription,
                    caseDetail?.NMIOutcome?.Outcome, caseDetail?.NMIOutcome?.OutcomeDescription,caseDetail?.ExtensionInfo?.ExtensionReason, caseDetail?.ExtensionInfo?.ExtensionDescription, errorCode, errorDescription);
				if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
				{
					throw new Exception("Error while updating a case ");

				}
				return true;
			}
			catch (Exception ex)
			{

			}
			return false;
		}

		public async Task<CaseDetailDto> GetCaseDetailByIdAsync(long? caseId, long? customerid,int userId)
        {
            CaseDetailDto caseDetail = new CaseDetailDto();
            try
            {
                int _erroCode = 0;
                string _erroDesc = string.Empty;
                var result = await _cservice.GrievancesContext.Procedures.usp_GetCaseDetailsByIdAsync(customerid, caseId,userId, errorCode, errorDescription);
				if (result.Count == 0)
					throw new UnauthorizedAccessException();

				caseDetail = result
                     .Select(z => new CaseDetailDto()
                     {
                         CategoryId = z.CategoryId,
                         CaseId = z.CaseId,
                         DueDate = z.DueDate,
                         AssigneeId = z.AssigneeId,
                         AssigneeName = z.AssigneeName,
                         StatusId = z.StatusId,
                         Status=z.Status,
                         PartType = z.PartType,
                         Urgency = z.Urgency,
                         Requestor = z.RequestorText,
                         RequestType = z.RequestTypeText,
                         ReceivedDate = z.ReceivedDate,
                         IncidentDate = z.IncidentDate,
                         Method = z.Method,
                         ExtensionTaken = z.ExtensionTaken,
                         Source = z.Source,
                         ComplianceCase = z.ComplianceCase,
                         GoodCause = z.GoodCause,
                         Description = z.Description,
                         FirstTier = z.FirstTier,
                         SubCategory = z.SubCategory,
                         HighPriority = z.HighPriority,
                         IsAor = z.IsAOR,
                         CustomerId=z.CustomerId,
                         CategoryName=z.CategoryName,
                         PlanName=z.PlanName,
                         CaseDetailId=z.CaseDetailId,
                         CaseInfo= new CaseInfo()
                         {
							 CategoryId = z.CategoryId,
							 CaseId = z.CaseId,
							 DueDate = z.DueDate,
							 AssigneeId = z.AssigneeId,
							 AssigneeName = z.AssigneeName,
							 StatusId = z.StatusId,
							 PartType = z.PartType,
							 Urgency = z.Urgency,
							 Requestor = z.Requestor,
							 RequestType = z.RequestType,
							 ReceivedDate = z.ReceivedDate,
							 IncidentDate = z.IncidentDate,
							 Method = z.Method,
							 ExtensionTaken = z.ExtensionTaken,
							 Source = z.Source,
							 ComplianceCase = z.ComplianceCase,
							 GoodCause = z.GoodCause,
							 Description = z.Description,
							 FirstTier = z.FirstTier,
							 SubCategory = z.SubCategory,
							 HighPriority = z.HighPriority,
							 IsAor = z.IsAOR,
							 CustomerId = z.CustomerId,
							 CaseDetailId = z.CaseDetailId,
						 },
                         MemberInfo = new MemberInfoDetailDto()
                         {
                             Email = z.Email ,
                             CellPhone = z.CellPhone,
                             CommunicationPrefrence = z.CommunicationPreference,
                             DateOfBirth = z.DateOfBirth ,
                             FirstName = z.FirstName,
                             lastName = z.LastName,
                             MiddleName = z.MiddleName,
                             Gender = z.Gender,
                             HomePhone = z.HomePhone,
                             Fax = z.Fax,
                             AddressLine1 = z.AddrLine1,
                             AddressLine2 = z.AddrLine2,
                             City = z.City,
                             State = z.STATE,
                             Zip = z.Zip,
                             LanguagePrefrence = z.LanguagePrefrence,
                             MemberRepresentativeId=z.MemberRepresentativeId,
                             MBI=z.MBI,
                             MemberNumber=z.MemberNumber,
                             PlanType=z.PlanType,
                             StateName=z.StateName
                         },
                         AorInfo = new AorDetailDto()
                         {
                             aorAddressLine1 = z.aorAddressLine1 ,
                             aorAddressLine2 = z.aorAddressLine2,
                             aorCity = z.aorCity ,
                             aorZip = z.aorZip ,
                             aorState = z.aorState ,
                             aorFirstName = z.aorFirstName,
                             aorLastName = z.aorLastName,
                             aorEmail = z.aorEmail,
                             aorPhone = z.aorPhone,
                             aorMiddleName = z.MiddleName,
                             aorFormReceivedDate = z.ReceivedDate,
                             aorRelationship = z.AORRelationship,
                             memberSignatureDate = z.MemberSignatureDate,
                             apointeeSignatureDate = z.AppointeeSignatureDate,
                             formReceived = z.RepresentativeFormReceived,
                             aorStateName=z.AORStateName

                         },
                         NMIInfo= new NMI()
                         {
                             NMIReason=z.ReasonId,
                             NMIDescription=z.NMIDescription
                            
                         },
						 NMIOutcome = new NMIResolution()
						 {
							 OutcomeDescription = z.OutcomeDescription,
							 Outcome = z.OutcomeId
						 },
                         ExtensionInfo = new CaseExtensionDetail()
                         { ExtensionDescription=z.ExtensionDescription,
                           ExtensionReason=z.ExtensionReason                         
                         }

					 }).FirstOrDefault();
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while creating a case ");

                }
                return caseDetail;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return caseDetail;
        }

        public async Task<List<CaseDetailListDto>> GetAllCaseDetail(long? customerId)
        {
            List<CaseDetailListDto> caseDetailsList = new List<CaseDetailListDto>();
            try
            {
                var result = await _cservice.GrievancesContext.Procedures.usp_GetAllCaseDetailsAsync(customerId, errorCode, errorDescription);
                caseDetailsList = result.Select(x => new CaseDetailListDto
                {
                    CaseDetailId = x.CaseDetailId,
                    CaseId = x.CaseId != null ? x.CaseId : string.Empty,
                    AssigneeId = x.AssigneeId != null ? x.AssigneeId : 0,
                    AssigneeName =  x.AssigneeName,
                    Status = x.CaseStatus,
                    DueDate = x.DueDate,
                    CustomerId = x.CustomerId,
                    ExtensionTaken = x.ExtensionTaken,
                    HighPriority = x.HighPriority,
                    IncidentDate = x.IncidentDate,
                    PartType = x.PartType,
                    ReceivedDate = x.ReceivedDate,
                    Source = x.Source,
                    Urgency = x.Urgency,
                    StatusId = x.StatusId
                }).ToList();
                return caseDetailsList;
            }
            catch (Exception ex)
            {

            }
            return caseDetailsList;
        }

        public Task<List<CaseStatusDto>> GetCaseStatusAsync()
        {
            return _cservice.GrievancesContext.Procedures.GetAllCaseStatus();
        }

        public async Task<int> CreateGrievancesDraftCaseAsync(DraftCaseDetailDto caseDetail)
        {
            try
            {
                var result = await _cservice.GrievancesContext.Procedures.CreateDraftGrievancesCaseAsync(caseDetail.CaseData, caseDetail.DraftCaseDetailId, caseDetail.CreatedBy, caseDetail.CreatedDate, caseDetail.LastModifiedDate, caseDetail.LastModifiedBy, errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while saving draft case ");
                }
                if (result.Count > 0)
                    return Convert.ToInt32(result.First().DraftCaseDetailId);
                else
                    throw new Exception("Error while creating a member ");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public async Task<int> DiscardGrievancesDraftCaseAsync(int caseDetailId)
        {
            try
            {
                var result = await _cservice.GrievancesContext.Procedures.Discard_DraftCaseDetailsAsync(caseDetailId, errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while discarding the draft case ");
                }
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }



        public Task<List<CategoryDto>> GetCategoriesAsync()
        {
            return _cservice.GrievancesContext.Procedures.GetCategories();
        }

        public async Task<List<usp_GetCaseData_DashboardResult>> GetDashboardData(string? mbi, string? caseId, string? memberNumber, DateTime? dob, string? firstName, string? lastName,int userId)
        {
            try
            {
                var result = await _cservice.GrievancesContext.Procedures.usp_GetCaseData_DashboardAsync(mbi, memberNumber, dob, lastName, firstName, caseId, userId, errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while discarding the draft case ");
                }
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


        public async Task<bool> InsertOrDeleteCaseAttachments(long caseId, long docId, int userId, bool isDelete, string fileName)
        {
            try
            {
                OutputParameter<byte?> errCode = new OutputParameter<byte?>();
                await _cservice.GrievancesContext.Procedures.usp_InsertOrDeleteCaseAttachmentsAsync(caseId, docId, userId, fileName, isDelete, errCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while creating a case ");

                }
                return true;
            }
            catch (Exception ex)
            {

            }
            return false;
        }


        public async Task<List<usp_GetCaseAttachmentsResult>> GetCaseAttachments(long? CustomerId, long? CaseId)
        {
            try
            {
                var result = await _cservice.GrievancesContext.Procedures.usp_GetCaseAttachmentsAsync(CustomerId, CaseId, errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while discarding the draft case ");
                }
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<usp_GetCaseCommentByCaseIdResult>> GetCaseComments(long? caseId)
        {
            try
            {
				var result = await _cservice.GrievancesContext.Procedures.usp_GetCaseCommentByCaseIdAsync(caseId, errorCode, errorDescription);
				if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
				{
					throw new Exception("Error while discarding the draft case ");
				}
				return result;
			}
			catch (Exception ex)
			{
				throw new Exception(ex.Message);
			}
		}

        public async Task<int> CreateCaseComment(CommentDto commentDetail, long createdBy)
        {
			try
			{
				var result = await _cservice.GrievancesContext.Procedures.usp_CreateCaseCommentAsync(commentDetail.CaseId,commentDetail.AttachmentId,commentDetail.Comment,createdBy,DateTime.Now, errorCode, errorDescription);
				if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
				{
					throw new Exception("Error while discarding the draft case ");
				}
				return result;
			}
			catch (Exception ex)
			{
				throw new Exception(ex.Message);
			}
		}

		public async Task<int> UpdateCaseComment(CommentDto commentDetail, long modifiedBy)
		{
			try
			{
				var result = await _cservice.GrievancesContext.Procedures.usp_UpdateCaseCommentAsync(commentDetail.CommentId, commentDetail.AttachmentId, commentDetail.Comment,commentDetail.IsDeleted, modifiedBy, errorCode, errorDescription);
				if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
				{
					throw new Exception("Error while discarding the draft case ");
				}
				return result;
			}
			catch (Exception ex)
			{
				throw new Exception(ex.Message);
			}
		}

        public async Task<List<NMIReason>> GetNMIReasonAsync(short currentCustomerId)
        {
			try
			{
				var result = await _cservice.GrievancesContext.Procedures.usp_GetNMIReasonAsync(currentCustomerId, errorCode, errorDescription);
				if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
				{
					throw new Exception("Error while getting NMI reason ");
				}
				return result;
			}
			catch (Exception ex)
			{
				throw new Exception(ex.Message);
			}
		}

        public async Task<List<NMIOutcome>> GetNMIOutcomeAsync(short currentCustomerId)
        {
			try
			{
				var result = await _cservice.GrievancesContext.Procedures.usp_GetNMIOutcomeAsync(currentCustomerId, errorCode, errorDescription);
				if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
				{
					throw new Exception("Error while getting NMI Outcome ");
				}
				return result;
			}
			catch (Exception ex)
			{
				throw new Exception(ex.Message);
			}
		}

        public async Task<List<ExtensionReason>> GetExtensionReasonAsync(short currentCustomerId)
        {
			try
			{
				var result = await _cservice.GrievancesContext.Procedures.usp_GetExtensionReasonAsync(currentCustomerId, errorCode, errorDescription);
				if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
				{
					throw new Exception("Error while getting Extension ");
				}
				return result;
			}
			catch (Exception ex)
			{
				throw new Exception(ex.Message);
			}
		}

        public async Task<List<CaseStatusDto>> GetAllEligibleActionsAsync(int caseId)
        {
			try
			{
				var result = await _cservice.GrievancesContext.Procedures.usp_GetEligibleActionsOfCaseAsync(caseId, errorCode, errorDescription);
				if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
				{
					throw new Exception("Error while getting Actions ");
				}
				return result;
			}
			catch (Exception ex)
			{
				throw new Exception(ex.Message);
			}
		}
    }
}
