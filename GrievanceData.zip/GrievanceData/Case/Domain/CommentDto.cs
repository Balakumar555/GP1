﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.Case.Domain
{
	public class CommentDto
	{
		public int? AttachmentId { get; set; }
		public string Comment { get; set; }
		public long? CaseId { get; set; }
		public int? CommentId { get; set; }
		public bool? IsDeleted { get; set; }
	}
}
