﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.Case.Domain
{
	public class CaseDetailDto
	{
		public long CaseDetailId { get; set; }
		public short? StatusId { get; set; }
		public short? CustomerId { get; set; }
		public DateTime? IncidentDate { get; set; }
		public DateTime? DueDate { get; set; }
		public DateTime ReceivedDate { get; set; }
		public string Method { get; set; }
		public string Requestor { get; set; }
		public string RequestType { get; set; }
		public short CategoryId { get; set; }
		public string SubCategory { get; set; }
		public string Source { get; set; }
		public string Urgency { get; set; }
		public bool? HighPriority { get; set; }
		public bool? ExtensionTaken { get; set; }
		public string PartType { get; set; }
		public bool? ComplianceCase { get; set; }
		public bool? GoodCause { get; set; }
		public string Description { get; set; }
		public string FirstTier { get; set; }		
		public bool? IsAor { get; set; }
		public DateTime CreatedDate { get; set; }
		public long CreatedBy { get; set; }
		public DateTime? LastModifiedDate { get; set; }
		public long? LastModifiedBy { get; set; }		
		public string CaseId { get; set; }
		public long? AssigneeId { get; set; }
		public string AssigneeName { get; set; }
		public string? PlanName { get; set; }
		public string? CategoryName { get; set; }
		public string? Status { get; set; }
		public DateTime? ClosedDate { get; set; }
		public CaseInfo? CaseInfo { get; set; }
		public AorDetailDto? AorInfo { get; set; }
		public PoaDetailDto? PoaInfo { get; set; }
		public MemberInfoDetailDto? MemberInfo { get; set; }
		public NMI? NMIInfo { get; set; }
		public NMIResolution? NMIOutcome { get; set; }
		public CaseExtensionDetail? ExtensionInfo { get; set; }

	}

	public class PoaDetailDto
	{
		public string? poaFirstName { get; set; }
		public string? poaMiddleName { get; set; }
		public string? poaLastName { get; set; }
		public string? poaEmail { get; set; }
		public DateTime? poaEffectiveDate { get; set; }
		public DateTime? poaTerminationDate { get; set; }
		public string? poaCity { get; set; }
		public string? poaAddressLine1 { get; set; }
		public string? poaAddressLine2 { get; set; }
		public string? poaPhone { get; set; }
		public string? poaZip { get; set; }
		public string? poaState { get; set; }
		public string? poaRelationship { get; set; }
		public bool? poaFormReceived { get; set; }
		public DateTime? poaFormReceivedDate { get; set; }
	}
	public class AorDetailDto
	{
		public DateTime? aorTerminationDate;

		public string? aorFirstName { get; set; }
		public string? aorMiddleName { get; set; }
		public string? aorLastName { get; set; }
		public string? aorEmail { get; set; }
		public DateTime? memberSignatureDate { get; set; }
		public DateTime? apointeeSignatureDate { get; set; }
		public string? aorCity { get; set; }
		public string? aorAddressLine1 { get; set; }
		public string? aorAddressLine2 { get; set; }
		public string? aorPhone { get; set; }
		public string? aorZip { get; set; }
		public string? aorState { get; set; }
		public string? aorRelationship { get; set; }
		public bool? formReceived { get; set; }
		public DateTime? aorFormReceivedDate { get; set; }
		public string? aorStateName { get; set; }
	}
	public class MemberInfoDetailDto
	{
		public string FirstName { get; set; }
		public string? MiddleName { get; set; }
		public string lastName { get; set; }
		public DateTime? DateOfBirth { get; set; }
		public string Gender { get; set; }
		public string AddressLine1 { get; set; }
		public string? AddressLine2 { get; set; }
		public string State { get; set; }
		public string City { get; set; }
		public string Zip { get; set; }
		public string? Email { get; set; }
		public string? HomePhone { get; set; }
		public string? WorkPhone { get; set; }
		public string? Fax { get; set; }
		public string? CellPhone { get; set; }
		public string? CommunicationPrefrence { get; set; }
		public string? LanguagePrefrence { get; set; }
		public string? MBI { get; set; }
		public string? MemberNumber { get; set; }
		public int? ClientId { get; set; }
		public int? PlanId { get; set; }
		public string? ClientName { get; set; }
		public string? PlanName { get; set; }
		public long? MemberRepresentativeId { get; set; }
		public bool? IsAor { get; set; }
		public bool? IsPoa { get; set; }
		public string? PlanType { get; set; }
		public string? StateName { get; set; }
	}

	

	public class DraftCaseDetailDto
	{
		public string CaseData { get; set; }
		//public DateTime CreatedDate { get; set; }
		public long CreatedBy { get; set; }
		public DateTime CreatedDate { get; set; }
		public DateTime? LastModifiedDate { get; set; }
		public long? LastModifiedBy { get; set; }
		public int? DraftCaseDetailId { get; set; }
	}
	public class NMI
	{
		public int? NMIReason { get; set; }
		public string? NMIDescription { get; set; }
	}

	public class NMIResolution
	{
		public int? Outcome { get; set; }
		public string? OutcomeDescription { get; set; }
	}

	public class CaseExtensionDetail
	{
		public int? ExtensionReason { get; set; }
		public string? ExtensionDescription { get; set; }
	}


}
