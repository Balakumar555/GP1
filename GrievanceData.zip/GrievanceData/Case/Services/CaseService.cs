﻿using GrievanceData.Common.Infrastructure.Service;
using GrievanceData.Common.Infrastructure.Settings;
using GrievanceData.GrievanceContext;
using GrievanceData.GrievanceDbContext;
using GrievanceData.Case.Domain;
using GrievanceData.Case.Infrastructure.Interfaces;
using GrievanceData.Case.Infrastructure.Repositories;
using GrievanceData.Case.Infrastructure.Settings;
using Newtonsoft.Json.Linq;
using UserDto = GrievanceData.GrievanceContext.UserDto;

namespace GrievanceData.Case.Services
{
    public class CaseService : ICaseService
    {
        private readonly ICaseUnitOfWork cuow;
        private readonly ICommonService _cservice;
        private readonly CaseSettings _casesettings;

        public CaseService(GrievancesContext context, CommonSettings commonsettings, CaseSettings casesettings, ICommonService cservice)
        {
            if (cuow == null)
				cuow = cuow ?? new CaseUnitOfWork(new CaseUnitOfWorkSettings
                {
                    casesettings = casesettings,
                    commonsettings = commonsettings,
                    commonservice = cservice
                });

            _cservice = cservice;
			_casesettings = casesettings;
        }
        

        public async Task<bool> CreateCase(CaseDetailDto caseDetail)
        {
            bool status = await cuow.CaseSqlRepo.CreateGrievancesCaseAsync(caseDetail);
            return status;
        }

		public async Task<bool> UpdateCase(CaseDetailUpdateDto caseDetail, long modifiedBy)
		{
			bool status = await cuow.CaseSqlRepo.UpdateGrievancesCaseAsync(caseDetail, modifiedBy);
			return status;
		}
		public async Task<int> CreateGrievancesDraftCaseAsync(DraftCaseDetailDto caseDetail)
        {
            int caseDetailId = await cuow.CaseSqlRepo.CreateGrievancesDraftCaseAsync(caseDetail);
            return caseDetailId;
        }
		public async Task<CaseDetailDto> GetCaseDetailsById(long? caseId,long? customerId,int userId)
		{
			return await cuow.CaseSqlRepo.GetCaseDetailByIdAsync(caseId, customerId, userId);
			
		}

		public async Task<List<CaseDetailListDto>> GetAllCaseDetails(long? customerId)
		{
			return await cuow.CaseSqlRepo.GetAllCaseDetail(customerId);

		}

		public async Task<List<CaseStatusDto>> GetAllCaseStatusAsync()
        {
           return  await cuow.CaseSqlRepo.GetCaseStatusAsync();
		}

		public async Task<int> DiscardGrievancesDraftCaseAsync(int caseDetailId)
        {
            return await cuow.CaseSqlRepo.DiscardGrievancesDraftCaseAsync(caseDetailId);
        }	

        public async Task<List<CategoryDto>> GetCategoriesAsync()
        {
            return await cuow.CaseSqlRepo.GetCategoriesAsync();
        }

		public async Task<List<usp_GetCaseData_DashboardResult>> GetDashboardData(string? mbi, string? caseId, string? memberNumber, DateTime? dob, string? firstName, string? lastName,int userId)
		{
			return await cuow.CaseSqlRepo.GetDashboardData(mbi,caseId,memberNumber,dob,firstName,lastName, userId);

		}
        
        public async Task<bool> InsertOrDeleteCaseAttachments(long caseId,long docId,int userId,string fileName,bool isDelete)
        {
            return await cuow.CaseSqlRepo.InsertOrDeleteCaseAttachments(caseId, docId,userId,isDelete,fileName);
        }

        public async Task<List<usp_GetCaseAttachmentsResult>> GetCaseAttachments(long? CustomerId, long? CaseId) {
            return await cuow.CaseSqlRepo.GetCaseAttachments(CustomerId, CaseId);
        }

        public async Task<List<usp_GetCaseCommentByCaseIdResult>> GetCaseComments(long? caseId)
        {
			return await cuow.CaseSqlRepo.GetCaseComments(caseId);
        }

        public async Task<int> CreateCaseComment(CommentDto commentDetail, long createdBy)
        {
            return await cuow.CaseSqlRepo.CreateCaseComment(commentDetail, createdBy);

		}

        public async Task<int> UpdateCaseComment(CommentDto commentDetail, long modifiedBy)
        {
			return await cuow.CaseSqlRepo.UpdateCaseComment(commentDetail, modifiedBy);
		}

        public async Task<List<NMIReason>> GetNMIReasonAsync(short currentCustomerId)
        {
			return await cuow.CaseSqlRepo.GetNMIReasonAsync(currentCustomerId);
		}

        public async Task<List<NMIOutcome>> GetNMIOutcomeAsync(short currentCustomerId)
        {
			return await cuow.CaseSqlRepo.GetNMIOutcomeAsync(currentCustomerId);
		}

        public async Task<List<ExtensionReason>> GetExtensionReasonAsync(short currentCustomerId)
        {
			return await cuow.CaseSqlRepo.GetExtensionReasonAsync(currentCustomerId);
		}

        public async Task<List<CaseStatusDto>> GetAllEligibleActionsAsync(int caseId)
        {
			return await cuow.CaseSqlRepo.GetAllEligibleActionsAsync(caseId);
		}
    }
}
