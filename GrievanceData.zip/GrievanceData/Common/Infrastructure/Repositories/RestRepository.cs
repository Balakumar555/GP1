﻿using RestSharp;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using GrievanceData.Common.Infrastructure.Settings;
using GrievanceData.Common.Domain;
using GrievanceData.Common.Infrastructure.Framework;
using GrievanceData.Common.Infrastructure.Interfaces;
using Microsoft.AspNetCore.Http;
using System.Net;
using System.Net.Security;

namespace GrievanceData.Common.Infrastructure.Repositories
{
    internal class RestRepository<T> : IRestRepository<T> where T : class
    {        
        private readonly HeadersSettings _headerssettings;

        public RestRepository(HeadersSettings headerssettings)
        {
            _headerssettings = headerssettings;
        }

        public async Task<T> RestApi(RestApiRequest request, Method method = Method.POST, bool isSecure = false)
        {
            JsonSerializerSettings jsonSerializerSettings = new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver()
            };

             RestClient restClient = new RestClient(request.BaseUrl);

            if (isSecure)
            {
                ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(
                delegate
                {
                    return true;
                });
                //restClient.RemoteCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;
            }
            RestRequest restrequest = new RestRequest(request.UriSegment, method);

            foreach (KeyValuePair<string, string> hdr in request.Headers)
            {
                restrequest.AddHeader(hdr.Key, hdr.Value);
            }

            if (request.Data != null)
            {
                string jsonObject = JsonConvert.SerializeObject(request.Data, Formatting.Indented, jsonSerializerSettings);
                restrequest.AddParameter("application/json", jsonObject, ParameterType.RequestBody);
            }

            TaskCompletionSource<RestResponse> taskCompletion = new TaskCompletionSource<RestResponse>(); // Changed from IRestResponse to RestResponse

            //RestRequestAsyncHandle handle = restClient.ExecuteAsync(restrequest, r => taskCompletion.SetResult(r));
            var handle = await restClient.ExecuteAsync(restrequest);

            RestResponse response = await taskCompletion.Task as RestResponse;            

            if (!request.HandleErrorResponse)
            {
                throwException(response);
            }
            return new CommonMapper().Mapper.Map<RestApiResponse>(response) as T;
        }

        private void throwException(RestResponse response)
        {
            if (response.StatusCode == System.Net.HttpStatusCode.Forbidden)
            {
                throw new InvalidOperationException(string.Format("{0} : {1}", response.StatusDescription, response.ErrorMessage), response.ErrorException);
            }
            else if (response.StatusCode != System.Net.HttpStatusCode.OK)
            {
               
            }
        }
    }
}
