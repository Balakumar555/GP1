﻿global using GrievanceData.GrievanceContext;
using GrievanceData.Common.Infrastructure.Interfaces;
using GrievanceData.Common.Infrastructure.Settings;
using GrievanceData.GrievanceDbContext;
using RestSharp;
using RestSharp.Authenticators;
using Newtonsoft.Json.Linq;
using DocumentsData.DocumentsDbContext;
using GrievanceData.Common.Infrastructure.Service;
using DocumentsData.DocumentsDbContext;

namespace GrievanceData.Common.Infrastructure.Repositories
{
    public class CommonRepository: IGrievancesDBRepository
    {       
        private CommonSettings _commonsettings;
        private GrievancesContext _context;
        private DocumentsContext _docContext;

        private readonly ICommonService _cservice;
        
        public CommonRepository(CommonSettings settings, GrievancesContext context, DocumentsContext docContext, ICommonService service)
        {
            _commonsettings = settings;
            _context = context;
            _docContext=   docContext;
             _cservice = service;
        }

        public async Task<List<usp_GetLookUpValuesResult>> GetLookUpValues(string lookUpName, int customerId)
        {
            try
            {
                GrievanceDbContext.OutputParameter<int> returnValue = new GrievanceDbContext.OutputParameter<int>();
                GrievanceDbContext.OutputParameter<byte?> errorCode = new GrievanceDbContext.OutputParameter<byte?>();
                GrievanceDbContext.OutputParameter<string> errorDescription = new GrievanceDbContext.OutputParameter<string>();
                
                List<usp_GetLookUpValuesResult> resp = await _cservice.GrievancesContext.Procedures.usp_GetLookUpValuesAsync(lookUpName, customerId,
                       errorCode, errorDescription, returnValue);

                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while gettting lookup values ");

                }
                return resp;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public async Task<List<usp_GetCustomerConfigurationResult>> GetCustomerConfiguration(int customerId)
        {
            try
            {
                GrievanceDbContext.OutputParameter<int> returnValue = new GrievanceDbContext.OutputParameter<int>();
                GrievanceDbContext.OutputParameter<byte?> errorCode = new GrievanceDbContext.OutputParameter<byte?>();
                GrievanceDbContext.OutputParameter<string> errorDescription = new GrievanceDbContext.OutputParameter<string>();

                List<usp_GetCustomerConfigurationResult> resp = await _cservice.GrievancesContext.Procedures.usp_GetCustomerConfigurationAsync(customerId,
                       errorCode, errorDescription, returnValue);

                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while gettting lookup values ");

                }
                return resp;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

       

        public GrievancesContext GetGrievanceDBConnection
        {
            get
            {  
                return _context;
            }
        }
        public GrievancesContext GrievancesContext => _context;

        public DocumentsContext GetDocumentsDBConnection
        {
            get
            {
                return _docContext;
            }
        }
        public DocumentsContext DocumentsContext => _docContext;
    }
    public async Task<int> InsertActivityLog(usp_InserttblActivityLog model)
    {

    }
}
