﻿using GrievanceData.Common.Domain;
using GrievanceData.Common.Infrastructure.Interfaces;
using GrievanceData.Common.Infrastructure.Settings;
using GrievanceData.GrievanceDbContext;
using DocumentsData.DocumentsContext;
using DocumentsData.DocumentsDbContext;
using GrievanceData.Common.Infrastructure.Service;

namespace GrievanceData.Common.Infrastructure.Repositories
{
    public class CommonUnitOfWork : ICommonUnitOfWork
    {
        
        private readonly IGrievancesDBRepository _CommonSqlRepo;
        private readonly IRestRepository<ICommonEntity> _MFAApiRepo;        

        IRestRepository<ICommonEntity> ICommonUnitOfWork.MFAApiRepo => _MFAApiRepo;
        IGrievancesDBRepository ICommonUnitOfWork.CommonSqlRepo => _CommonSqlRepo;                

        public CommonUnitOfWork(CommonUnitOfWorkSettings uows, GrievancesContext context, DocumentsContext docContext,ICommonService cservice)
        {           
            _MFAApiRepo = new RestRepository<ICommonEntity>(uows.commonsettings.HeadersRepo);
            _CommonSqlRepo = new CommonRepository(uows.commonsettings, context,docContext, cservice);
        }       
    }
}

