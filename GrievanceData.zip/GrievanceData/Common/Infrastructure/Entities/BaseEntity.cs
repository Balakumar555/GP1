﻿namespace GrievanceData.GrievanceContext
{
    public class BaseEntity
    {

    }
    public partial class AspNetUsers : BaseEntity { }
    public partial class AspNetRoleClaims : BaseEntity { }
    public partial class AspNetUserClaims : BaseEntity { }    
}