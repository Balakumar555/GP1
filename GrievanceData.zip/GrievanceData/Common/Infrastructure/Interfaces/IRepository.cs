﻿using System.Linq.Expressions;

namespace GrievanceData.Common.Infrastructure.Interfaces
{
    public interface IRepository<T> // where T : class , new()
    {

        Task<T> Get(Expression<Func<T, bool>> predicate);        
        Task<T> Find(Expression<Func<T, bool>> predicate);
        //Task<List<T>> GetAll(Expression<Func<T, bool>> predicate);
        Task<List<T>> GetAll();
        Task<T> GetWhere(Expression<Func<T, bool>> predicate);
        Task<List<T>> GetAllWhere(Expression<Func<T, bool>> predicate);
        void Add(T entity);
        void AddRange(IEnumerable<T> entities);
        void Update(T entity);
        void UpdateRange(IEnumerable<T> entities);
        void Delete(T entity);
        void DeleteRange(IEnumerable<T> entities);
    }
}
