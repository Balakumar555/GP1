﻿using DocumentsData.DocumentsDbContext;
using GrievanceData.Common.Domain;
using GrievanceData.GrievanceDbContext;

namespace GrievanceData.Common.Infrastructure.Interfaces
{
    public interface IGrievancesDBRepository : ICommonEntity//<T> where T : class, ICommonEntity
    {
        GrievancesContext GrievancesContext { get; }
        DocumentsContext DocumentsContext { get; }
        Task<List<usp_GetLookUpValuesResult>> GetLookUpValues(string lookUpName, int customerId);
        Task<List<usp_GetCustomerConfigurationResult>> GetCustomerConfiguration(int customerId);

    }
}
