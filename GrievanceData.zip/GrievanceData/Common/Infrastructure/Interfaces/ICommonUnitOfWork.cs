﻿using GrievanceData.Common.Domain;

namespace GrievanceData.Common.Infrastructure.Interfaces
{
    internal interface ICommonUnitOfWork
    {
        IGrievancesDBRepository CommonSqlRepo { get; }
        IRestRepository<ICommonEntity> MFAApiRepo { get; }
    }
}
