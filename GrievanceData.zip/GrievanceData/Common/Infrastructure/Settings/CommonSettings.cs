namespace GrievanceData.Common.Infrastructure.Settings
{
    public class CommonSettings
    {
        public RestApiRepoSettings MFAApiRepo { get; set; }
        public DBConnectionSettings DBConnectionRepo { get; set; }
        public HeadersSettings HeadersRepo { get; set; }
        public string ResetPasswordUrl { get; set; }
    }
    public class DBConnectionSettings
    {
        public string GrievancesContext { get; set; }
    }
    public class HeadersSettings
    {
        public bool IsGrievance { get; set; }
        public bool IsQuery { get; set; }


    }

    public class RestApiRepoSettings
    {
        public string MFABaseUrl { get; set; }
        public string MFAApiKey { get; set; }
        public string Domain { get; set; }
    }
}