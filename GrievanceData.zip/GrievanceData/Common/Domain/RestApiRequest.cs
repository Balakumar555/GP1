﻿namespace GrievanceData.Common.Domain
{  
    public class RestApiRequest : ICommonEntity
    {
        public string BaseUrl { get; set; }
        public string UriSegment { get; set; }
        public Dictionary<string, string> Headers { get; set; }
        public object Data { get; set; }
        public bool HandleErrorResponse { get; set; }
    }
}
