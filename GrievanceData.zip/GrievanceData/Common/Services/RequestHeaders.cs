﻿using Microsoft.AspNetCore.Http;
using GrievanceData.Common.Domain;
using Microsoft.Data.SqlClient;
using GrievanceData.GrievanceDbContext;

namespace GrievanceData.Common.Infrastructure.Service
{
    public interface IRequestContextService
    {
        Token GetToken { get; } 
    }

    public sealed class RequestContextService : IRequestContextService
    {
        private readonly IHttpContextAccessor _accessor;
        private GrievancesContext _context;
        public RequestContextService(IHttpContextAccessor accessor, GrievancesContext context)
        {
            this._accessor = accessor;
            this._context = context;
        }
                
        public Token GetToken
        {
            get
            {
                var sqlParameters = new[]
                {
                    new SqlParameter
                    {
                        ParameterName = "@loginCountryCd",
                        Size = 4,
                        Value = _accessor.HttpContext.Request.Headers["countryCode"].ToString() ?? Convert.DBNull,
                        SqlDbType = System.Data.SqlDbType.NChar,                        
                    },
                    new SqlParameter
                    {
                        ParameterName = "@userId",
                        Size = 100,
                        Value = _accessor.HttpContext.Request.Headers["userId"].ToString() ?? Convert.DBNull,
                        SqlDbType = System.Data.SqlDbType.NVarChar,
                    }
                };
                Token token = new Token();
                token.userId = _accessor.HttpContext.Request.Headers["userId"];
                token.app = _accessor.HttpContext.Request.Headers["app"];
                
                return token;
            }
        }
    }
}
