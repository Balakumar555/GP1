﻿using DocumentsData.DocumentsDbContext;
using GrievanceData.Clients.Domain;
using GrievanceData.GrievanceDbContext;
using System.Data;

namespace GrievanceData.Common.Infrastructure.Service
{
    public interface ICommonService
    {
        GrievancesContext GrievancesContext { get; }
        DocumentsContext DocumentsContext { get; }
        Task<List<usp_GetLookUpValuesResult>> GetLookUpValues(string lookUpName, int customerId);
        Task<List<usp_GetCustomerConfigurationResult>> GetCustomerConfiguration(int customerId);
        string userId { get; }
        string app { get; }
        Task<int> InsertActivityLog(usp_InserttblActivityLog usp_InserttblActivityLog); 
    }
}
