﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.Clients.Domain
{
	public class PlanDetailDto
	{
		public long ClientPlanId { get; set; }
		public short? PlanTypeId { get; set; }
		public long? ClientId { get; set; }
		public string PlanName { get; set; }
		public string PlanCode { get; set; }
		public string Description { get; set; }
		public DateTime EffectiveDate { get; set; }
		public DateTime EndDate { get; set; }
		public DateTime CreatedDate { get; set; }
		public long CreatedBy { get; set; }
		public DateTime? LastModifiedDate { get; set; }
		public long? LastModifiedBy { get; set; }
		public string? Status { get; set; }
	}
}
