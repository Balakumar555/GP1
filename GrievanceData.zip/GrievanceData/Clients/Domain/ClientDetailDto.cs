﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.Clients.Domain
{
    public class ClientDetailDto
    {
        public long ClientId { get; set; }
        public short? ClientTypeId { get; set; }
        public short CustomerId { get; set; }
        public string ClientName { get; set; }
        public string ClientCode { get; set; }
        public string Description { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime EndDate { get; set; }
        public DateTime CreatedDate { get; set; }
        public long CreatedBy { get; set; }
        public DateTime? LastModifiedDate { get; set; }
        public long? LastModifiedBy { get; set; }
        public string Status { get; set; }
        public byte[]? Logo { get; set; }
    }
}
