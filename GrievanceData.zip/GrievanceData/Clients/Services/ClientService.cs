﻿using GrievanceData.Common.Infrastructure.Service;
using GrievanceData.Common.Infrastructure.Settings;
using GrievanceData.GrievanceContext;
using GrievanceData.GrievanceDbContext;
//using GrievanceData.Client.Domain;
using GrievanceData.Clients.Infrastructure.Interfaces;
using GrievanceData.Clients.Infrastructure.Repositories;
using GrievanceData.Clients.Infrastructure.Settings;
using Newtonsoft.Json.Linq;
using UserDto = GrievanceData.GrievanceContext.UserDto;
using GrievanceData.Clients.Domain;

namespace GrievanceData.Clients.Services
{
    public class ClientService : IClientService
    {
        private readonly IClientUnitOfWork cuow;
        private readonly ICommonService _cservice;
        private readonly ClientSettings _clientsettings;

        public ClientService(GrievancesContext context, CommonSettings commonsettings, ClientSettings clientsettings, ICommonService cservice)
        {
            if (cuow == null)
                cuow = cuow ?? new ClientUnitOfWork(new ClientUnitOfWorkSettings
                {
                    clientsettings = clientsettings,
                    commonsettings = commonsettings,
                    commonservice = cservice
                });

            _cservice = cservice;
			_clientsettings = clientsettings;
        }


        public async Task<bool> CreateClient(ClientDetailDto clientDetail)
        {
            bool status = await cuow.ClientSqlRepo.CreateClientAsync(clientDetail);
            return status;
        }

		public async Task<bool> UpdateClient(ClientDetailDto clientDetail)
		{
			bool status = await cuow.ClientSqlRepo.UpdateClientAsync(clientDetail);
			return status;
		}

		public async Task<bool> CreatePlan(PlanDetailDto planDetail)
		{
			bool status = await cuow.ClientSqlRepo.CreatePlanAsync(planDetail);
			return status;
		}

		public async Task<bool> UpdatePlan(PlanDetailDto planDetail)
		{
			bool status = await cuow.ClientSqlRepo.UpdatePlanAsync(planDetail);
			return status;
		}

		public async Task<bool> CreateGroup(GroupDetailDto groupDetail)
		{
			bool status = await cuow.ClientSqlRepo.CreateGroupAsync(groupDetail);
			return status;
		}

		public async Task<bool> UpdateGroup(GroupDetailDto groupDetail)
		{
			bool status = await cuow.ClientSqlRepo.UpdateGroupAsync(groupDetail);
			return status;
		}

		public async Task<List<ClientDetailDto>> GetClientsByCustomerId(short customerId)
        {
            return await cuow.ClientSqlRepo.GetClientsByCustomerId(customerId);

        }

		public async Task<List<ClientDetailDto>> GetActiveClientsByUserId(short customerId, int userId) => await cuow?.ClientSqlRepo.GetActiveClientsByUserId(customerId,userId);

		public async Task<List<PlanDetailDto>> GetPlansByClientId(int clientId)
		{
			return await cuow.ClientSqlRepo.GetPlansByClientId(clientId);

		}

		public async Task<List<GroupDetailDto>> GetGroupsByPlanId(int planId)
		{
			return await cuow.ClientSqlRepo.GetGroupsByPlanId(planId);

		}

		public async Task<List<usp_GetAllClientTypesResult>> GetAllClientTypesAsync()
		{
			return await cuow.ClientSqlRepo.GetAllClientTypeAsync();

		}

		public async Task<List<usp_GetAllPlanTypesResult>> GetAllPlanTypesAsync()
		{
			return await cuow.ClientSqlRepo.GetAllPlanTypeAsync();

		}

		public async Task<List<usp_GetAllGroupTypesResult>> GetAllGroupTypesAsync()
		{
			return await cuow.ClientSqlRepo.GetAllGroupTypeAsync();

		}

		//public async Task<List<ClientType>> GetAllCaseStatusAsync()
		//{
		//	return await cuow.ClientSqlRepo.GetCaseStatusAsync();
		//}
	}
}
