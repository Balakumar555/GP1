﻿
using GrievanceData.Clients.Domain;
using UserDto = GrievanceData.GrievanceContext.UserDto;

namespace GrievanceData.Clients.Services
{
    public interface IClientService
    {
		Task<bool> CreateClient(ClientDetailDto clientDetail);
		Task<bool> UpdateClient(ClientDetailDto clientDetail);
		Task<bool> CreatePlan(PlanDetailDto planDetail);
		Task<bool> UpdatePlan(PlanDetailDto planDetail);
		Task<bool> CreateGroup(GroupDetailDto groupDetail);
		Task<bool> UpdateGroup(GroupDetailDto groupDetail);
		Task<List<ClientDetailDto>> GetClientsByCustomerId(short customerId);
		Task<List<ClientDetailDto>> GetActiveClientsByUserId(short customerId, int userId);
		Task<List<PlanDetailDto>> GetPlansByClientId(int clientId);
		Task<List<GroupDetailDto>> GetGroupsByPlanId(int planId);
		Task<List<usp_GetAllClientTypesResult>> GetAllClientTypesAsync();
		Task<List<usp_GetAllPlanTypesResult>> GetAllPlanTypesAsync();
		Task<List<usp_GetAllGroupTypesResult>> GetAllGroupTypesAsync();
		//Task<List<CaseDetailListDto>> GetAllCaseDetails();

	}
}
