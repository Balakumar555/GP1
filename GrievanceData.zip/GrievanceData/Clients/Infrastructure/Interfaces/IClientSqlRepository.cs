﻿//using GrievanceData.Client.Domain;
using GrievanceData.Clients.Domain;
using GrievanceData.Clients.Services;

namespace GrievanceData.Clients.Infrastructure.Interfaces
{
    internal interface IClientSqlRepository
    {
		Task<bool> CreateClientAsync(ClientDetailDto clientDetail);
		Task<bool>UpdateClientAsync(ClientDetailDto clientDetail);
		Task<bool> CreatePlanAsync(PlanDetailDto planDetail);
		Task<bool> UpdatePlanAsync(PlanDetailDto planDetail);
		Task<bool> CreateGroupAsync(GroupDetailDto groupDetail);
		Task<bool> UpdateGroupAsync(GroupDetailDto groupDetail);
		Task<List<ClientDetailDto>> GetClientsByCustomerId(short customerId);
		Task<List<ClientDetailDto>> GetActiveClientsByUserId(short customerId, int userId);
		Task<List<PlanDetailDto>> GetPlansByClientId(int clientId);
		Task<List<GroupDetailDto>> GetGroupsByPlanId(int planId);
		Task<List<usp_GetAllClientTypesResult>> GetAllClientTypeAsync();
		Task<List<usp_GetAllPlanTypesResult>> GetAllPlanTypeAsync();
		Task<List<usp_GetAllGroupTypesResult>> GetAllGroupTypeAsync();
		//Task<CaseDetailDto> GetCaseDetailByIdAsync(int caseId);
		//Task<List<CaseDetailListDto>> GetAllCaseDetail();

	}
}
