namespace GrievanceData.Clients.Infrastructure.Settings
{
    public class SQLRepoSettings
    {
        // public string GetUserToken { get; set; }
    }
}