﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.Clients.Infrastructure.Settings
{
    public class ClientSettings
    {
        public SQLRepoSettings SQLRepo { get; set; }

    }
}
