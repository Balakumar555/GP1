﻿using GrievanceData.Common.Infrastructure.Service;
using GrievanceData.Common.Infrastructure.Settings;

namespace GrievanceData.Clients.Infrastructure.Settings
{
    public class ClientUnitOfWorkSettings
    {
        public CommonSettings commonsettings { get; set; }
        public ICommonService commonservice { get; set; }
        public ClientSettings clientsettings { get; set; }
    }
}
