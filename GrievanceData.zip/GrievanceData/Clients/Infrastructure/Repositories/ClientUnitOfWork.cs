﻿using GrievanceData.Clients.Infrastructure.Interfaces;
using GrievanceData.Clients.Infrastructure.Settings;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.Clients.Infrastructure.Repositories
{
    internal class ClientUnitOfWork : IClientUnitOfWork
    {
        //You will need UnitOfWork when you have transactions through a repo;
        private readonly IClientSqlRepository _ClientRepo;
       public IClientSqlRepository ClientSqlRepo => _ClientRepo;

        /// <summary>
        /// public IClientSqlRepository ClientSqlRepo => throw new NotImplementedException();
        /// </summary>
        /// <param name="cows"></param>

        public ClientUnitOfWork(ClientUnitOfWorkSettings cows)
        {
			_ClientRepo = new ClientSqlRepository(cows.commonsettings, cows.clientsettings, cows.commonservice);
        }
    }
}
