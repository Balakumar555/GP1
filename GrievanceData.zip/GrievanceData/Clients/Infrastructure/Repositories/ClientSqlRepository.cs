﻿using System.Security.Cryptography;
using RestSharp;
using GrievanceData.Common.Infrastructure.Service;
using System.Text;
using GrievanceData.Clients.Infrastructure.Settings;
using GrievanceData.Clients.Infrastructure.Interfaces;
//using GrievanceData.Client.Domain;
using GrievanceData.Common.Infrastructure.Settings;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Microsoft.Data.SqlClient;
using AutoMapper.Internal;
using GrievanceData.GrievanceDbContext;
using System.Net;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using UserDto = GrievanceData.GrievanceContext.UserDto;
using Microsoft.EntityFrameworkCore;
using GrievanceData.GrievanceContext;
using GrievanceData.Clients.Domain;
using System.Numerics;

namespace GrievanceData.Clients.Infrastructure.Repositories
{
    internal class ClientSqlRepository : IClientSqlRepository
    { 
        private readonly ICommonService _cservice;
        private readonly SQLRepoSettings _sqlsettings;
        private CommonSettings _commonsettings;
        public OutputParameter<string> errorDescription = new OutputParameter<string>();
        public OutputParameter<int?> errorCode = new OutputParameter<int?>();

        public static UserDto user = new UserDto();

        public ClientSqlRepository(CommonSettings commonsettings, ClientSettings clientsettings, ICommonService service)
        {
            _commonsettings = commonsettings;
            _cservice = service;
            _sqlsettings = clientsettings.SQLRepo;
        }

        public async Task<bool> CreateClientAsync(ClientDetailDto clientDetail)
        {
            try
            {
                if (IsClientNameExist(clientDetail.ClientName, clientDetail.CustomerId, clientDetail.ClientId) > 0)
                {
                    throw new Exception("Client Name already Exist");
                }
                await _cservice.GrievancesContext.Procedures.usp_CreateClientAsync(clientDetail.ClientTypeId, clientDetail.CustomerId, clientDetail.ClientCode,
                    clientDetail.ClientName, clientDetail.Description, clientDetail.EffectiveDate, clientDetail.EndDate, clientDetail.Logo, DateTime.Now, clientDetail.CreatedBy, null, null, errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while creating a Client ");

				}
				return true;
			}
			catch (Exception ex)
			{
				throw new Exception(ex.Message);
			}
			//return false;
		}

        public async Task<bool> UpdateClientAsync(ClientDetailDto clientDetail)
        {
            try
            {
                if (IsClientNameExist(clientDetail.ClientName, clientDetail.CustomerId, clientDetail.ClientId) > 0)
                {
                    throw new Exception("Client Name already Exist");
                }
                await _cservice.GrievancesContext.Procedures.usp_UpdateClientAsync(clientDetail.ClientId, clientDetail.ClientTypeId, clientDetail.CustomerId, clientDetail.ClientCode,
                    clientDetail.ClientName, clientDetail.Description, clientDetail.EffectiveDate, clientDetail.EndDate, clientDetail.LastModifiedBy, clientDetail.LastModifiedDate, clientDetail.Logo, errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while updating a Client ");

				}
				return true;
			}
			catch (Exception ex)
			{
				throw new Exception(ex.Message);
			}
			//return false;
		}

        public async Task<bool> CreatePlanAsync(PlanDetailDto planDetail)
        {
            try
            {
                if (IsPlanNameExist(planDetail.PlanName, planDetail.ClientId.Value, planDetail.ClientPlanId) > 0)
                {
                    throw new Exception("Plan Name already Exist");
                }
                await _cservice.GrievancesContext.Procedures.usp_CreatePlanAsync(planDetail.ClientId, planDetail.PlanName, planDetail.PlanCode, planDetail.Description, planDetail.PlanTypeId,
                     planDetail.EffectiveDate, planDetail.EndDate, planDetail.CreatedBy, null, null, errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while creating a Plan ");

				}
				return true;
			}
			catch (Exception ex)
			{
				throw new Exception(ex.Message);
			}
			//return false;
		}

        public async Task<bool> CreateGroupAsync(GroupDetailDto groupDetail)
        {
            try
            {
                if (IsGroupNameExist(groupDetail.GroupName, groupDetail.ClientPlanId.Value, groupDetail.ClientPlanGroupId) > 0)
                {
                    throw new Exception("Group Name already Exist");
                }
                await _cservice.GrievancesContext.Procedures.usp_CreateGroupAsync(groupDetail.ClientPlanId, groupDetail.GroupName, groupDetail.GroupNumber, groupDetail.Description, groupDetail.GroupTypeId,
                     groupDetail.EffectiveDate, groupDetail.EndDate, groupDetail.CreatedBy, null, null, errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while creating a Group ");

				}
				return true;
			}
			catch (Exception ex)
			{
				throw new Exception(ex.Message);
			}
			//return false;
		}
				

        public async Task<List<ClientDetailDto>> GetClientsByCustomerId(short customerId)
        {
            List<ClientDetailDto> clientDetailsList = new List<ClientDetailDto>();
            try
            {
                clientDetailsList = await _cservice.GrievancesContext.Procedures.usp_GetAllClientsByCustomerIdAsync(customerId,errorCode, errorDescription);
                return clientDetailsList;
            }
            catch (Exception ex)
            {

            }
            return clientDetailsList;
        }

        public async Task<List<ClientDetailDto>> GetActiveClientsByUserId(short customerId, int userId)
        {
            List<ClientDetailDto> clientDetailsList = new List<ClientDetailDto>();
            try
            {
                 clientDetailsList = await _cservice.GrievancesContext.Procedures.usp_GetActiveClientsByUserIdAsync(customerId,userId, errorCode, errorDescription);
                return clientDetailsList;
            }
            catch (Exception ex)
            {

            }
            return clientDetailsList;
        }

        public async Task<List<PlanDetailDto>> GetPlansByClientId(int clientId)
        {
            List<PlanDetailDto> planDetailsList = new List<PlanDetailDto>();
            try
            {
                planDetailsList = await _cservice.GrievancesContext.Procedures.usp_GetAllClientPlansAsync(clientId, errorCode, errorDescription);

                return planDetailsList;
            }
            catch (Exception ex)
            {

            }
            return planDetailsList;
        }

        public async Task<List<GroupDetailDto>> GetGroupsByPlanId(int planId)
        {
            List<GroupDetailDto> groupDetailsList = new List<GroupDetailDto>();
            try
            {

                groupDetailsList = await _cservice.GrievancesContext.Procedures.usp_GetAllClientPlanGroupsAsync(planId, errorCode, errorDescription);

                return groupDetailsList;
            }
            catch (Exception ex)
            {

            }
            return groupDetailsList;
        }

        public Task<List<usp_GetAllClientTypesResult>> GetAllClientTypeAsync()
        {
            return _cservice.GrievancesContext.Procedures.usp_GetAllClientTypesAsync(errorCode, errorDescription);
        }

        public Task<List<usp_GetAllPlanTypesResult>> GetAllPlanTypeAsync()
        {
            return _cservice.GrievancesContext.Procedures.usp_GetAllPlanTypesAsync(errorCode, errorDescription);
        }

        public Task<List<usp_GetAllGroupTypesResult>> GetAllGroupTypeAsync()
        {
            return _cservice.GrievancesContext.Procedures.usp_GetAllGroupTypesAsync(errorCode, errorDescription);
        }

        public async Task<bool> UpdatePlanAsync(PlanDetailDto planDetail)
        {
            try
            {
                if (IsPlanNameExist(planDetail.PlanName, planDetail.ClientId.Value, planDetail.ClientPlanId) > 0)
                {
                    throw new Exception("Plan Name already Exist");
                }
                await _cservice.GrievancesContext.Procedures.usp_UpdatePlanAsync(planDetail.ClientPlanId, planDetail.ClientId, planDetail.PlanName, planDetail.PlanCode, planDetail.Description, planDetail.PlanTypeId,
                     planDetail.EffectiveDate, planDetail.EndDate, planDetail.LastModifiedBy, planDetail.LastModifiedDate, errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while creating a Plan ");

				}
				return true;
			}
			catch (Exception ex)
			{
				throw new Exception(ex.Message);
			}
			//return false;
		}

        public async Task<bool> UpdateGroupAsync(GroupDetailDto groupDetail)
        {
            try
            {
                if (IsGroupNameExist(groupDetail.GroupName, groupDetail.ClientPlanId.Value, groupDetail.ClientPlanGroupId) > 0)
                {
                    throw new Exception("Plan Name already Exist");
                }
                await _cservice.GrievancesContext.Procedures.usp_UpdateGroupAsync(groupDetail.ClientPlanGroupId, groupDetail.ClientPlanId, groupDetail.GroupName, groupDetail.GroupNumber, groupDetail.Description, groupDetail.GroupTypeId,
                     groupDetail.EffectiveDate, groupDetail.EndDate, groupDetail.LastModifiedBy, groupDetail.LastModifiedDate, errorCode, errorDescription);
                if (errorDescription != null && errorDescription.Value != null && errorDescription.Value != string.Empty)
                {
                    throw new Exception("Error while creating a Group ");

				}
				return true;
			}
			catch (Exception ex)
			{
				throw new Exception(ex.Message);
			}
			//return false;
		}

        private int IsClientNameExist(string clientName, short customerId, long clientId)
        {
            // List<ClientDetailDto> clientDetailsList = new List<ClientDetailDto>();
            var clientDetailsList = _cservice.GrievancesContext.Procedures.usp_GetAllClientsByCustomerIdAsync(customerId, errorCode, errorDescription);
            if (clientDetailsList.Result == null)
                return 0;
            return clientDetailsList.Result.Count(x => x.ClientName == clientName && x.CustomerId == customerId && x.ClientId != clientId);
        }
        private int IsPlanNameExist(string planName, long clientId, long clientPlanId)
        {
            var planDetailsList = _cservice.GrievancesContext.Procedures.usp_GetAllClientPlansAsync(clientId, errorCode, errorDescription);
            if (planDetailsList.Result == null)
                return 0;
            return planDetailsList.Result.Count(x => x.PlanName == planName && x.ClientId == clientId && x.ClientPlanId != clientPlanId);
        }
        private int IsGroupNameExist(string groupName, long clientPlanId, long clientPlanGroupId)
        {
            var groupDetailsList = _cservice.GrievancesContext.Procedures.usp_GetAllClientPlanGroupsAsync(clientPlanId, errorCode, errorDescription);
            if (groupDetailsList.Result == null)
                return 0;
            return _cservice.GrievancesContext.ClientPlanGroup.Count(x => x.GroupName == groupName && x.ClientPlanId == clientPlanId && x.ClientPlanGroupId != clientPlanGroupId);
        }
    }
}
