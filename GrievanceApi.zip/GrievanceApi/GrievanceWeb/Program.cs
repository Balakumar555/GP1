global using GrievanceData.GrievanceContext;
using GrievanceData.Common.Infrastructure.Service;
using GrievanceData.Logger;
using Microsoft.Extensions.Options;
using GrievanceData.Common.Infrastructure.Settings;
using AutoMapper;
using GrievanceData.Common.Infrastructure.Interfaces;
using GrievanceData.Common.Infrastructure.Repositories;
using GrievanceData.GrievanceDbContext;
using GrievanceData.User.Infrastructure.Settings;
using GrievanceData.User.Services;

var builder = WebApplication.CreateBuilder(args);
var config = new ConfigurationBuilder().AddJsonFile("appsettings.json", optional: false).Build();

builder.Services.AddRazorPages();
builder.Services.AddControllers();

// 

builder.Services.AddDbContext<GrievancesContext>(ServiceLifetime.Transient);
//builder.Services.AddDbContext<GrievancesContext>(options => options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddScoped<IRequestContextService, RequestContextService>();
builder.Services.AddHttpContextAccessor();


builder.Services.AddSingleton<ILoggerManager, LoggerManager>();

builder.Services.Configure<CommonSettings>(config.GetSection("Shared"))
               .AddScoped(sp => sp.GetRequiredService<IOptions<CommonSettings>>().Value);

builder.Services.Configure<UserSettings>(config.GetSection("SQLRepo"))
               .AddScoped(sp => sp.GetRequiredService<IOptions<UserSettings>>().Value);

//var mapperConfig = new MapperConfiguration(mc =>
//{
//    mc.AddProfile(new MappingProfile());
//});

//IMapper mapper = mapperConfig.CreateMapper();
//builder.Services.AddSingleton(mapper);

builder.Services.AddMvc();

builder.Services.AddTransient<IUserService, UserService>();
builder.Services.AddTransient<ICommonService, CommonService>();

builder.Services.AddTransient<IUnitOfWork, UnitOfWork>();
builder.Services.AddTransient(typeof(IRepository<>), typeof(Repository<>));

var app = builder.Build();



if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
