﻿using Microsoft.AspNetCore.Mvc;
using GrievanceData.Logger;
using GrievancesAPI.Models;
using GrievanceData.User.Services;
using GrievanceData.User.Domain;

namespace GrievanceWeb.Controllers
{
    [Route("Grievances")]
    [ApiController]
    public class UserController : BaseController
    {
        private readonly ILoggerManager _logger;
        private readonly IUserService _service;
        public UserController(ILoggerManager logger, IConfiguration configuration, IUserService service)
        {
            _logger = logger;
            _service = service;
        }

        [HttpPost("Login")]
        public async Task<ActionResult<bool>> LogIn(string EmailId)
        {
            UserDto request = new UserDto();
            request.Email = EmailId;

            GrievancesAPIResponse<bool, ApiError> resp = new GrievancesAPIResponse<bool, ApiError>(false, new ApiError());
            try
            {
                _logger.LogInfo("Called " + resp.GetCurrentMethod() + " endpoint");
                resp.result = await _service.LogIn(EmailId);
            }
            catch (Exception e)
            {
                resp.errorContent.statusCode = 500;
                resp.errorContent.message = e.Message;
                resp.errorContent.type = "fatal";
                _logger.LogInfo(e.ToString());
                return StatusCode(500, resp);
            }
            return Ok(resp);
        }

        [HttpPost("CreateUser")]
        public async Task<ActionResult<TblUsers>> Register(string UserId, string Pwd)
        {
            UserDto request = new UserDto();
            request.UserName = UserId;
            request.Password = Pwd;
            GrievancesAPIResponse<TblUsers, ApiError> resp = new GrievancesAPIResponse<TblUsers, ApiError>(null, new ApiError());
            try
            {
                _logger.LogInfo("Called " + resp.GetCurrentMethod() + " endpoint");
                resp.result = await _service.RegisterUser(request);
            }
            catch (Exception e)
            {
                resp.errorContent.statusCode = 500;
                resp.errorContent.message = e.Message;
                resp.errorContent.type = "fatal";
                _logger.LogInfo(e.ToString());
                return StatusCode(500, resp);
            }
            return Ok(resp);
        }
    }
}
