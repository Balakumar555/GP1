﻿namespace GrievancesAPI.Models
{
    /// <summary>
    /// Basic model to describe most error content for api calls
    /// It defaults to success.
    /// </summary>
    public class ApiError
    {
        public ApiError()
        {
            statusCode = 200; // default to success          
            message = "success";
            type = "info";
        }
        public int statusCode { set; get; }
        public string type { set; get; }
        public string message { set; get; }
    }
}
