﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace GrievancesAPI.Models
{

    /// <typeparam name="T">Result type</typeparam>
    /// <typeparam name="K">ErrorContent type</typeparam>
    public class GrievancesAPIResponse<T,K>
	{
	    public GrievancesAPIResponse()
        {
            result = default(T);
            errorContent = default(K);
        }
    
        public GrievancesAPIResponse(T defaultresult = default(T), K defaulterrorcontent = default(K))
        {
            result = defaultresult;
            errorContent = defaulterrorcontent;
        }


        [MethodImpl(MethodImplOptions.NoInlining)]
        public string GetCurrentMethod()
        {
            var st = new StackTrace();
            var sf = st.GetFrame(1);
            string name = sf.GetMethod().Name;

            if (name.Equals("MoveNext"))
            {
                // We're inside an async method
                name = sf.GetMethod().ReflectedType.Name
                         .Split(new char[] { '<', '>' }, StringSplitOptions.RemoveEmptyEntries)[0];
            }

            return name;
        }

        public T result { set; get; }
        public K errorContent { get; set; }

    }
   
    public class ApiRespString : GrievancesAPIResponse<string, ApiError>
    {
    }
    //public class ApiRespUser : GrievancesAPIResponse<UserEntity, APIError>
    //{
    //}

   
    public class ApiRespAdminResult : GrievancesAPIResponse<string, ApiError>
    {
    }


    public class ApiRespBadRequest : GrievancesAPIResponse<string, SerializableError>
    {
    }
   
}

