﻿namespace GrievanceData.User.Domain
{
    public class User
    {
        public decimal UserId { get; set; }
        public int UserNbr { get; set; }
        public string UserCd { get; set; } = null!;
        public string UserName { get; set; } = null!;
        public bool? IsActive { get; set; }
        public byte[] PasswordHash { get; set; }
        public byte[] PasswordSalt { get; set; }
    }
}