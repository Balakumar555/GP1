﻿using GrievanceData.Common.Infrastructure.Service;
using GrievanceData.GrievanceDbContext;
using GrievanceData.User.Domain;
using GrievanceData.User.Infrastructure.Interfaces;
using GrievanceData.User.Infrastructure.Repositories;
using GrievanceData.User.Infrastructure.Settings;

namespace GrievanceData.User.Services
{
    public class UserService : IUserService
    {
        private readonly IUserUnitOfWork uow;
        private readonly ICommonService _cservice;
        private readonly UserSettings _usersettings;

        public UserService(GrievancesContext context, UserSettings usersettings, ICommonService cservice)
        {
            if (uow == null)
                uow = uow ?? new UserUnitOfWork(new UserUnitOfWorkSettings
                {
                    usersettings = usersettings,
                    commonservice = cservice
                });

            _cservice = cservice;
            _usersettings = usersettings;
        }
        public async Task<bool> LogIn(string EmailId)
        {
            bool status = await uow.UserSqlRepo.LogIn(EmailId);
            return status;
        }
        public async Task<TblUsers> RegisterUser(UserDto request)
        {
            var status = await uow.UserSqlRepo.RegisterUser(request);
            return status;
        }
    }
}
