﻿using GrievanceData.User.Domain;

namespace GrievanceData.User.Services
{
    public interface IUserService
    {
        Task<bool> LogIn(string EmailId);
        Task<TblUsers> RegisterUser(UserDto request);
    }
}
