﻿using GrievanceData.User.Domain;
using GrievanceData.User.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.User.Infrastructure.Interfaces
{
    internal interface IUserSqlRepository : IUserEntity
    {
        Task<bool> LogIn(string EmailId);
        Task<TblUsers> RegisterUser(UserDto request);
    }
}
