﻿using GrievanceData.Common.Infrastructure.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.User.Infrastructure.Settings
{
    public class UserUnitOfWorkSettings
    {
        public ICommonService commonservice { get; set; }
        public UserSettings usersettings { get; set; }
    }
}
