﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.User.Infrastructure.Settings
{
    public class UserSettings
    {
        public SQLRepoSettings SQLRepo { get; set; }

    }
}
