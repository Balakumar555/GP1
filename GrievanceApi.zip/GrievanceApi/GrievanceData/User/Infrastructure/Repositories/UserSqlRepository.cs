﻿using System.Net;
using System.Net.Mail;
using Microsoft.AspNetCore.Http;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using Microsoft.Extensions.Configuration;
using RestSharp;
using RestSharp.Authenticators;
using Newtonsoft.Json.Linq;
using GrievanceData.Common.Infrastructure.Service;
using System.Text;
using GrievanceData.User.Infrastructure.Settings;
using GrievanceData.User.Infrastructure.Interfaces;
using GrievanceData.User.Domain;

namespace GrievanceData.User.Infrastructure.Repositories
{
    internal class UserSqlRepository : IUserSqlRepository
    {
        private readonly ICommonService _cservice;
        private readonly UserSettings _usersettings;
        private readonly SQLRepoSettings _sqlsettings;

        public static UserDto user = new UserDto();

        public byte[] PasswordHash { get; set; }
        public byte[] PasswordSalt { get; set; }

        public UserSqlRepository(UserSettings usersettings, ICommonService service)
        {
            _cservice = service;
            _sqlsettings = usersettings.SQLRepo;
        }

        public async Task<bool> LogIn(string EmailId)
        {

            // Get User Authenticated from DB and Send OTP First through MFA API call.
            // Then on UI User will be prompted to enter Password,OTP received through Email and MFA token API will be called.
            
            //TblUsers user = new TblUsers();
            //user.CustId = 1;
            //user.Fname = "Rajesh";
            //user.Lname = "Chavan";
            //user.Password = "Test";
            //user.Email = "Rajesh.Chavan@agadia.com";
            //user.Mfaenabled = true;
            //user.UsrEffectiveDate = DateTime.Now.Date;
            //user.UsrEndDate = DateTime.Now.Date;
            //user.LoginId = EmailId;
            //user.Mobile = "23423487990";


            return true; // Return true if User is found successfully and OTP has been sent through MFA API call.
        }

        public async Task<TblUsers> RegisterUser(UserDto request)
        {
            CreatePasswordHash(request.Password, out byte[] passwordHash, out byte[] passwordSalt);
            Random random = new Random();

            string strPasswordHash = Encoding.UTF8.GetString(passwordHash, 0, passwordHash.Length);
            string strPasswordSalt = Encoding.UTF8.GetString(passwordSalt, 0, passwordSalt.Length);

            TblUsers user = new TblUsers();
            user.CustId= 1;
            user.Fname=request.UserName;
            user.Lname = request.UserName;
            user.Password = strPasswordHash;
            user.Email = "Rajesh.Chavan@agadia.com";
            user.Mfaenabled= true;
            user.UsrEffectiveDate = DateTime.Now.Date;
            user.UsrEndDate = DateTime.Now.Date;
            user.LoginId = request.UserName;
            user.Mobile = request.PhoneNumber;

            _cservice.GrievancesContext.TblUsers.Add(user);
            _cservice.GrievancesContext.SaveChanges();

            return user;
        }
        private void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt)
        {
            using (var hmac = new HMACSHA512())
            {
                passwordSalt = hmac.Key;
                passwordHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(password));
            }
        }

        private bool VerifyPasswordHash(string password, byte[] passwordHash, byte[] passwordSalt)
        {
            using (var hmac = new HMACSHA512(passwordSalt))
            {
                var computedHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(password));
                return computedHash.SequenceEqual(passwordHash);
            }
        }
    }
}
