﻿using GrievanceData.Common.Infrastructure.Interfaces;
using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;
using GrievanceData.Common.Infrastructure.Service;
using GrievanceData.GrievanceDbContext;

namespace GrievanceData.Common.Infrastructure.Repositories
{
    public class Repository<T> : IRepository<T> where T : BaseEntity //, new()
    {
        protected readonly GrievancesContext _context;
        protected readonly ICommonService _cservice;
        protected readonly object _commonPredicate;
        protected readonly object _x;

        public Repository(GrievancesContext context, ICommonService service)
        {
            _context = context;
            _cservice = service;
            //_commonPredicate = _cservice.busUnitNbrs.Any(type => type == x.BusinessUnitNbr);
        }

        public void Add(T entity)
        {
           _context.Set<T>().Add(entity);
        }

        public void AddRange(IEnumerable<T> entities)
        {
            _context.Set<T>().AddRange(entities);
        }

        public void Delete(T entity)
        {
            _context.Set<T>().Remove(entity);
        }

        public void DeleteRange(IEnumerable<T> entities)
        {
            _context.Set<T>().RemoveRange(entities);
        }

        public async Task<T> Find(Expression<Func<T, bool>> predicate)
        {
            var result = await _context.Set<T>().FirstOrDefaultAsync(predicate);
            return result;
        }

        public async Task<T> Get(Expression<Func<T, bool>> predicate)
        { 
            //var result =  await _context.Set<T>().Where(predicate).Where(_cservice.busUnitNbrs.Any(type => type ==  _x.BusinessUnitNbr)).FirstOrDefaultAsync();
            var result = await _context.Set<T>().Where(predicate).FirstOrDefaultAsync();
            return result;
        }

       // public async Task<List<T>> GetAll(Expression<Func<T, bool>> predicate)
        public async Task<List<T>> GetAll()
        {
            //var result = await _context.Set<T>().Where(comomnpredicate).ToListAsync();
            var result = await _context.Set<T>().ToListAsync();
            return result;
        }

        public async Task<T> GetWhere(Expression<Func<T, bool>> predicate)
        {
            var result = await _context.Set<T>().Where(predicate).FirstOrDefaultAsync();
            return result;
        }

        public async Task<List<T>> GetAllWhere(Expression<Func<T, bool>> predicate)
        {
            var result = await _context.Set<T>().Where(predicate).ToListAsync();
            return result;
        }

        public void Update(T entity)
        {
            _context.Set<T>().Update(entity);
        }

        public void UpdateRange(IEnumerable<T> entities)
        {
            _context.Set<T>().UpdateRange(entities);
        }
    }
}
