﻿using GrievanceData.Common.Infrastructure.Interfaces;
using GrievanceData.Common.Infrastructure.Service;
using GrievanceData.GrievanceDbContext;

namespace GrievanceData.Common.Infrastructure.Repositories
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly GrievancesContext _context;
        private readonly ICommonService _cservice;


        public UnitOfWork(ICommonService service, GrievancesContext context)
        {
            _context = context;
            _cservice = service;
        }

        /*private IRepository<AspNetUser> userRepo;*/

        public IRepository<AspNetUsers> userRepo => userRepo ?? new Repository<AspNetUsers>(_context, _cservice);
    
        public async Task<bool> Complete()
        {
            var confirmation = await _context.SaveChangesAsync() > 0;
            return confirmation;
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
