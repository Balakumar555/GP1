﻿global using GrievanceData.GrievanceContext;
using GrievanceData.Common.Infrastructure.Interfaces;
using GrievanceData.Common.Infrastructure.Settings;
using GrievanceData.GrievanceDbContext;
using RestSharp;
using RestSharp.Authenticators;
using Newtonsoft.Json.Linq;

namespace GrievanceData.Common.Infrastructure.Repositories
{
    public class CommonRepository: IGrievancesDBRepository
    {       
        private CommonSettings _commonsettings;
        private GrievancesContext _context;

        public CommonRepository(CommonSettings settings, GrievancesContext context)
        {
            _commonsettings = settings;
            _context = context;
        }
        public GrievancesContext GetGrievanceDBConnection
        {
            get
            {  
                return _context;
            }
        }
        public GrievancesContext GrievancesContext => _context;
    }
}
