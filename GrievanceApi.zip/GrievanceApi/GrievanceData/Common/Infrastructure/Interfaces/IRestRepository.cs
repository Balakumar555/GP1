﻿using GrievanceData.Common.Domain;
using RestSharp;

namespace GrievanceData.Common.Infrastructure.Interfaces
{
    internal interface IRestRepository<T> where T : class
    {
        Task<T> RestApi(RestApiRequest request, Method method = Method.POST, bool isSecure = false);
    }
}
