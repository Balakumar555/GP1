﻿namespace GrievanceData.Common.Infrastructure.Interfaces
{
    public interface IUnitOfWork
    {
        IRepository<AspNetUsers> userRepo { get; }
        Task<bool> Complete();
    }
}
