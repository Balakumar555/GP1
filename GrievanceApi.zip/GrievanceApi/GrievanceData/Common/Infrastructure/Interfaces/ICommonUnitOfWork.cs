﻿using GrievanceData.Common.Domain;

namespace GrievanceData.Common.Infrastructure.Interfaces
{
    internal interface ICommonUnitOfWork
    {
        //IGrievancesDBRepository<ICommonEntity> CommonSqlRepo { get; }
        IGrievancesDBRepository CommonSqlRepo { get; }
        IRestRepository<ICommonEntity> MFAApiRepo { get; }
    }
}
