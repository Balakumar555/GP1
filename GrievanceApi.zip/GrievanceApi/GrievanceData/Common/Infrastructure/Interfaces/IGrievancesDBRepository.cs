﻿using GrievanceData.Common.Domain;
using GrievanceData.GrievanceDbContext;

namespace GrievanceData.Common.Infrastructure.Interfaces
{
    public interface IGrievancesDBRepository : ICommonEntity//<T> where T : class, ICommonEntity
    {
          GrievancesContext GrievancesContext { get; }
    }
}
