﻿using Microsoft.AspNetCore.Http;

namespace GrievanceData.Common.Infrastructure.Settings
{
    public class CommonUnitOfWorkSettings
    {
        public CommonSettings commonsettings { get; set; }
        public IHttpContextAccessor accessor { get; set; }
    }
}
