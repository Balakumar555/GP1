namespace GrievanceData.Common.Infrastructure.Settings
{
    public class CommonSettings
    {
        public DBConnectionSettings DBConnectionRepo { get; set; }
        public HeadersSettings HeadersRepo { get; set; }
    }  
    public class DBConnectionSettings
    {
        public string GrievancesContext { get; set; }
    }
    public class HeadersSettings
    {
        public bool IsGrievance { get; set; }
        public bool IsQuery { get; set; }
    }
}