﻿using AutoMapper;
using RestSharp;
using GrievanceData.Common.Domain;

namespace GrievanceData.Common.Infrastructure.Framework
{
    /// <summary>
    /// Class to hold the AutoMapper Initialization code.
    /// Create a static instance of this class at process initialization.
    /// A statis instance of this call is created in the Service construtor.
    /// </summary>
    internal class CommonMapper
    {
        private readonly IMapper _mapper;
        public CommonMapper()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<RestResponse, RestApiResponse>()
                .ForMember(dest => dest.Content, opts => opts.MapFrom(src => src.Content))
                .ForMember(dest => dest.ContentType, opts => opts.MapFrom(src => src.ContentType))
                .ForMember(dest => dest.StatusCode, opts => opts.MapFrom(src => src.StatusCode))
                .ForMember(dest => dest.StatusCode, opts => opts.MapFrom(src => src.StatusCode))
                .ForMember(dest => dest.StatusDescription, opts => opts.MapFrom(src => src.StatusDescription))
                .ForMember(dest => dest.ErrorMessage, opts => opts.MapFrom(src => src.ErrorMessage))
                .ForMember(dest => dest.Exception, opts => opts.MapFrom(src => src.ErrorException));
            });

            _mapper = config.CreateMapper();
        }

        public IMapper Mapper
        {
            get
            {
                return _mapper;
            }
        }
    }
}