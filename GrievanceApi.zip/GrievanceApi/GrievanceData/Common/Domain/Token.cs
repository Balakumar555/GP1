﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrievanceData.Common.Domain
{
    public class Token:ICommonEntity
    {
        public string userId { get; set; }
        public string app { get; set; }
        public List<int> busUnitNbrs { get; set; }
    }
}
