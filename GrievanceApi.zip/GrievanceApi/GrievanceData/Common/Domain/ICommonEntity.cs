﻿namespace GrievanceData.Common.Domain
{
    /// <summary>
    /// Base interface for every DomainEntity passed to and from the public to private layer.
    /// All models must implement this interface.
    /// </summary>
    public interface ICommonEntity
    {

    }
}
