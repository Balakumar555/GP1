﻿using System.Net;

namespace GrievanceData.Common.Domain
{
    /// <summary>
    /// Base interface for every DomainEntity passed to and from the public to private layer.
    /// All models must implement this interface.
    /// </summary>
    public class RestApiResponse : ICommonEntity
    {
        public string Content { get; set; }
        public string ContentType { get; set; }
        public HttpStatusCode StatusCode { get; set; }
        public string StatusDescription { get; set; }
        public string ErrorMessage { get; set; }
        public Exception Exception { get; set; }
    }
}
