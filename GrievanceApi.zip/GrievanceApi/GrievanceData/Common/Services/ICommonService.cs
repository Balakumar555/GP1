﻿using GrievanceData.GrievanceDbContext;
using System.Data;

namespace GrievanceData.Common.Infrastructure.Service
{
    public interface ICommonService
    {
        GrievancesContext GrievancesContext { get; }
        string userId { get; }
        string app { get; }
    }
}
