﻿using GrievanceData.Common.Infrastructure.Interfaces;
using GrievanceData.Common.Infrastructure.Settings;
using GrievanceData.Common.Infrastructure.Repositories;
using Microsoft.AspNetCore.Http;
using GrievanceData.GrievanceDbContext;

namespace GrievanceData.Common.Infrastructure.Service
{
    public class CommonService : ICommonService
    {
        private readonly ICommonUnitOfWork uow;
        private readonly CommonSettings _commonsettings;
        private readonly IRequestContextService _headers;
        private readonly GrievancesContext _context;
        private readonly IHttpContextAccessor _accessor;
        private readonly List<bool> _headerParams;

        public CommonService(CommonSettings settings, IRequestContextService headers, GrievancesContext dbContext, IHttpContextAccessor accessor)
        {
            _context = dbContext;
            _commonsettings = settings;
            _headers = headers;
            _accessor = accessor;
            // Sample code to retrieve parameters from QueryString into HTTPContext object. Keep it for now.
            switch (_accessor.HttpContext.Request.Path.Value.Substring(8, 2))
            {
                case "Grievance":
                    _headerParams = new List<bool> { _commonsettings.HeadersRepo.IsGrievance };
                    break;

                case "Query":
                    _headerParams = new List<bool> { _commonsettings.HeadersRepo.IsQuery };
                    break;               
            }

            if (uow == null)
                uow = new CommonUnitOfWork(new CommonUnitOfWorkSettings
                {
                    commonsettings = settings
                }, _context);
        }
        GrievancesContext ICommonService.GrievancesContext => _context; // uow.CommonSqlRepo.GrievancesContext;

        string ICommonService.userId => _headers.GetToken.userId; // Sample code to accept any parameters from header properties.
        string ICommonService.app => _headers.GetToken.app;
    }
}