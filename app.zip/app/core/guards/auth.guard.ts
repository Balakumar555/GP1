import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Route, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from 'src/app/Services/auth.service';
import { ErrorDialogService } from 'src/app/shared/errors/error-dialog.service';
import { SharedDataService } from 'src/app/shared/shareddata.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router, private dialog: ErrorDialogService, private sharedService:SharedDataService ){ }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    const currentUser = this.authService.currentUserValue;
    let roles = route.data['roles'] as Array<string>;
    const { routeConfig } = route; 
    const { path } = routeConfig as Route; 
    if (currentUser)
    {
      if (roles && roles.indexOf(currentUser.result.roleId) === -1) {
        // role not authorised so redirect to home page
        this.router.navigate(['/home']);
        this.dialog.openDialog("You are not Authorized to view this page");
        return false;
      }
     
   
   if (path?.endsWith('case-details') &&  !this.sharedService.getEligibilityMemberId()) {  
     this.router.navigate(['/home']);
     return false;
   }
      return true;
    }    
    else {
     this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
       return false;
     }

  }

}
