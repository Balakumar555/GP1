import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanDeactivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AddCaseDetailsComponent } from 'src/app/feature-components/case-management/add-case-details/add-case-details.component';
import { ErrorDialogService } from 'src/app/shared/errors/error-dialog.service';
import { ModelDialogsService } from 'src/app/shared/model-dialog/model-dialog.service';

@Injectable({
  providedIn: 'root'
})
export class PreventUnsavedChangesGuard implements CanDeactivate<AddCaseDetailsComponent> {
  constructor( private dialog: ErrorDialogService, private dialogService: ModelDialogsService, private router: Router) { }
  canDeactivate(
    component: AddCaseDetailsComponent,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      const retValue = component && component.addCaseDetailForm && (component.addCaseDetailForm.dirty && component.addCaseDetailForm.touched);
      if (retValue) {
        this.dialogService.confirm( "Confirm","You have unsaved changes. Are you sure you want to navigate away?", true).subscribe((res: boolean) => {
            if (res === true) {
                component.addCaseDetailForm.reset();
                return this.router.navigateByUrl(nextState?.url!);
            } else {
                return false;
            }
        });
    }
    return !retValue;
  }
  
}
