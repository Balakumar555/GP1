import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserComponent } from './feature-components/Account/user/user.component';
import { DashboardComponent } from './feature-components/dashboard/dashboard.component';
import { HomeComponent } from './feature-components/home/home.component';
import { FooterComponent } from './feature-components/Grievance-Lib/footer/footer.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthService } from './Services/auth.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NavbarComponent } from './feature-components/navigation/navbar/navbar.component';
import { UserListComponent } from './feature-components/user-management/user-list/user-list.component';
import { NavigationComponent } from './feature-components/navigation/navigation.component';
import { SubHeaderComponent } from './feature-components/navigation/sub-header/sub-header.component';
//import { CalendarComponent } from './feature-components/calendar/calendar.component';
//import { MemberManagementComponent } from './feature-components/member-management/member-management.component';
import { AuthInterceptor } from './Services/auth.interceptor';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
// import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
//import { SupportComponent } from './support/support.component';
//import { DocumentManagementComponent } from './document-management/document-management.component';
//import { ProfileComponent } from './profile/profile.component';
//import { QueuManagerComponent } from './queue-manager/queu-manager.component';
//import { SetupComponent } from './setup/setup.component';
//import { AddNewMemberComponent } from "./feature-components/member-management/add-new-member/add-new-member.component";
//import { ClientComponent } from './feature-components/client/client.component';
//import { ClientConsoleComponent } from './feature-components/client/client-console/client-console.component';
import { HeroComponent } from './feature-components/navigation/hero/hero.component';
import { CoreModule } from './core/core.module';
import { SharedModule } from './shared/shared.module';
import { MaterialModule } from './material.module';
import { TimedateComponent } from './feature-components/navigation/timedate/timedate.component';
import { MatDialogRef, MAT_DIALOG_DATA, MAT_DIALOG_DEFAULT_OPTIONS } from '@angular/material/dialog';
import { ToastaModule } from 'ngx-toasta';
import { SharedDataService } from './shared/shareddata.service';
import { MultifactorAuthenticationComponent } from './feature-components/multifactor-authentication/multifactor-authentication.component';
import { IConfig, NgxMaskModule } from 'ngx-mask';

//import { ClientComponent } from './feature-components/client/client.component';
//import { ClientConsoleComponent } from './feature-components/client/client-console/client-console.component';
import { MobileNavbarComponent } from './feature-components/navigation/mobile-navbar/mobile-navbar.component';
//import { CommentsSectionComponent } from './feature-components/case-management/comments-section/comments-section.component';
//import { CommunicationLogComponent } from './feature-components/case-management/communication-log/communication-log.component';
export const options: Partial<null|IConfig> | (() => Partial<IConfig>) = null;
@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    DashboardComponent,
    FooterComponent,
    HomeComponent,
    NavbarComponent,
    UserListComponent,
    NavigationComponent,
    SubHeaderComponent,
  //  CalendarComponent,
   // MemberManagementComponent,
 //   SupportComponent,
 //   DocumentManagementComponent,
//    ProfileComponent,
//    QueuManagerComponent,
//    SetupComponent,
   // AddNewMemberComponent,
    HeroComponent,
    TimedateComponent,
    MultifactorAuthenticationComponent,
  //  MobileNavbarComponent,
  //  CommentsSectionComponent,
 //   CommunicationLogComponent

 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    CoreModule,
    SharedModule,
    MaterialModule,    
    NgxMaskModule.forRoot(),
   ToastaModule.forRoot(),

  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: AuthInterceptor,
    multi: true
  }, AuthService, SharedDataService,
  [{ provide: LocationStrategy, useClass: HashLocationStrategy }],
  
 // [{ provide: MatDialogRef, useValue: {} }],
 // [{ provide: MAT_DIALOG_DATA, useValue: {} }],
 //[ { provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: { disableClose: true, hasBackdrop: true }  }]


  ],
  bootstrap: [AppComponent]
})

export class AppModule {

}
