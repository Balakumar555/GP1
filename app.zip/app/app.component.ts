import { AuthService } from './Services/auth.service';
import { Component, ViewEncapsulation,OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { filter, Observable } from 'rxjs';
import { UserManagementComponent } from './feature-components/user-management/user-management.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.None

})

export class AppComponent {
  isUserLoggedIn : Observable<boolean> | undefined;
  title = 'GrievanceApp';
  currentRoute: string = ""
  width: string = ''
 tagname:string =""
 sidenavspan:boolean=false;

  // get isLogInPage(): boolean{
  //   return (this.currentRoute == "" || this.currentRoute.toLowerCase().indexOf("login") >= 0)
  // }

  constructor(
    private router: Router,
    private authService:AuthService
    )


  {



//     this.router.events.pipe(
//       filter((event: any) => event instanceof NavigationEnd)
//     )
//       .subscribe((ev: any) => {
//         var currentUrl: string = ev.url;
//         if (currentUrl.indexOf("?") >= 0) {
//           this.currentRoute = currentUrl.substring(0, currentUrl.indexOf("?"));
// //alert(this.currentRoute);
//         }
//         else {
//           this.currentRoute = currentUrl;
//         }

//       })


  }

  ngOnInit(){

    this.isUserLoggedIn = this.authService.isLoggedIn();
    console.log(this.isUserLoggedIn)
  }

}


