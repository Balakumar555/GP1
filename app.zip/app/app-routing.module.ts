import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PasswordresetComponent } from './feature-components/Account/passwordreset/passwordreset.component';
import { DashboardComponent } from './feature-components/dashboard/dashboard.component';
import { HomeComponent } from './feature-components/home/home.component';
import { AuthGuard } from './core/guards/auth.guard';
import { MultifactorAuthenticationComponent } from './feature-components/multifactor-authentication/multifactor-authentication.component';
import { CommunicationLogComponent } from './feature-components/case-management/communication-log/communication-log.component';
import { CaseDetailsPageComponent } from './feature-components/case-management/case-details-page/case-details-page.component';
import { VerbalNotificationComponent } from "./feature-components/case-management/verbal-notification/verbal-notification.component";


const routes: Routes = [
   {path:'', redirectTo: 'home', pathMatch: 'full'},
   {path:'dashboard',component:DashboardComponent},
  //  {path:'login', component:LoginComponent, children:
  // [
  //   {
  //     path: '',
  //     component: LoginComponent
  //   },
  //   {
  //     path: '**',
  //     component: LoginComponent
  //   }
  // ]},
  //  {path:'newpwd',component:NewpasswordComponent, children:
  //  [
  //    {
  //      path: '',
  //      component: LoginComponent
  //    },
  //    {
  //      path: '**',
  //      component: LoginComponent
  //    }
  //  ]},
  //  {path:'pwdexp',component:PasswordExpirationComponent},
    // {path: 'client', component:ClientComponent},
  //  {path: 'client-console', component:ClientConsoleComponent},
   // {path:'member-management',component: MemberManagementComponent, canActivate:[AuthGuard]},
 // {path: 'add-new-member', component:AddNewMemberComponent},
   {path: 'user-management', loadChildren:() => import('./feature-components/user-management/user-management.module').then(m=> m.UserManagementModule)},
   {path: 'client-management', loadChildren:() => import('./feature-components/client-plan-group-management/client-management.module').then(m=> m.ClientManagementModule)},
   {path: 'case-management', loadChildren:() => import('./feature-components/case-management/case-management.module').then(m=> m.CaseManagementModule)},
   {path: 'member-management', loadChildren:() => import('./feature-components/member-management/member-management.module').then(m=> m.MemberManagementModule)},
   {path: 'queue-management', loadChildren:() => import('./feature-components/queue-management/queue-management.module').then(m=> m.QueueManagementModule)},
   
   {path: 'login', loadChildren:() => import('./feature-components/Account/account.module').then(m=> m.AccountManagementModule)},

  {path:'home',component:HomeComponent, canActivate:[AuthGuard]},

  {path: 'mutlifactorauthentication', component:MultifactorAuthenticationComponent},
   {path: 'passwordreset', component:PasswordresetComponent},

  { path: 'home', component: HomeComponent, canActivate: [AuthGuard] },

  { path: 'mutlifactorauthentication', component: MultifactorAuthenticationComponent },
  { path: 'passwordreset', component: PasswordresetComponent },

  {
    path: 'case-details-page', component: CaseDetailsPageComponent, children: [
      { path: '', component: CommunicationLogComponent, },
      { path: 'verbal-notification', component: VerbalNotificationComponent }
    ]
  },


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
