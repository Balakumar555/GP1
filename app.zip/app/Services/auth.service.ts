import { Injectable, Injector, NgZone } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { BehaviorSubject, catchError, map, Observable, retry, throwError } from 'rxjs';
import { getLocaleDateFormat } from '@angular/common';
//import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  public paramaters : any
  passLength: number = 6;
  get: any;
  private loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  private currentUserSubject: BehaviorSubject<any>;
  constructor(private httpClient: HttpClient) {    
    this.currentUserSubject = new BehaviorSubject<any>(JSON.parse(localStorage.getItem('currentUser')!)); 
  }

  //private baseURL = "https://qapoc.pahub.com/GrievanceAPI/Grievances";
  //private baseURL = 'https://localhost:7091/Grievances';   

  isUserLoggedIn() {
    return this.loggedIn.asObservable();
}

isLoggedIn()
{
  let user = localStorage.getItem('currentUser')
  if(user)
  {
    this.loggedIn.next(true);
    
  }  
  else
  {
    this.loggedIn.next(false);
  }
  return this.loggedIn.asObservable();
}
public get currentUserValue(): any {
  return this.currentUserSubject.value;
}
  getData(){  
    return this.httpClient.get<any>('/GetActiveUsersByCustomer').pipe(retry(1), catchError(this.handleError));
  }
  
  getLogin(loginId: string, pwd: string): Observable<any>
  {   
    
    var LoginReq= {LoginId: loginId, pwd:pwd,IsAlphaNum:true,PassLength:6,isOTPRequired:true };
    return this.httpClient.post<any>('/Login',LoginReq).pipe(map(user => {
        localStorage.setItem('currentUser', JSON.stringify(user));
        if(user.result.isExpired != "Y")
        {
        this.loggedIn.next(true);
        this.currentUserSubject.next(user);
        }
        else
        {
          
            this.loggedIn.next(false);
            this.currentUserSubject.next(null);
            
        }
      return user;
  }));
  }

  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('currentUser');
    this.loggedIn.next(false);
    this.currentUserSubject.next(null);
}

  sendResetPasswordNotification(EmailId: string): Observable<any> {
    const params = new HttpParams()
      .set('emailId', EmailId)
    return this.httpClient.post<any>('/SendResetPasswordNotification', '', { params: params });
  }

  resetPwd(NewPwd:string, LoginId:string, Token:string,customerId:any): Observable<any>
  {      
    var resetPwdReq= { newPassword:NewPwd,loginId: LoginId, token:Token,customerId:customerId};
     return this.httpClient.post<any>('/ResetPassword', resetPwdReq);
  }

  updatePwd(CustId:number, UserId:number, OldPwd:string, NewPwd:string,EmailId:string, Token:string): Observable<any>
  {  
    //alert('In service: before API all')
    var resetPwdReq= { custId:CustId, userID: UserId, oldPassword:OldPwd, newPassword: NewPwd, emailId:EmailId};
     return this.httpClient.post<any>('/UpdatePassword', resetPwdReq);
  } 
  handleError(error: any) {

    let errorMessage = '';

    if (error.error instanceof ErrorEvent) {

      // Get client-side error

      errorMessage = error.error.message;

    } else {

      // Get server-side error

      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;

    }
    
    //window.alert(errorMessage);  

    return throwError(() => {

      return errorMessage;

    });


   
  }  
}
