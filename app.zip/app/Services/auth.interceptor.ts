import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse
} from '@angular/common/http';
import { catchError, finalize, Observable, throwError } from 'rxjs';
import { LoadingDialogService } from '../shared/loading/loading-dialog.service';
import { environment } from 'src/environments/environment';
@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  constructor(private loadingDialogService: LoadingDialogService) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    const token = localStorage.getItem("access_token");
    const url = this.updateUrl(request.url);
    
    this.loadingDialogService.openDialog();
    if (token) {
      // If we have a token, we set it to the header
      request = request.clone({
         setHeaders: {Authorization: `Bearer ${token}`, TimezoneOffset: `${new Date().getTimezoneOffset()}`},
         
      });
   }
   request= request.clone({
    url:url
   })
    return next.handle(request).pipe(
      finalize(() => {
        
        this.loadingDialogService.hideDialog();     })
     )
  
  }
  updateUrl(url: string) {
    return environment.origin + url;
  }
}
