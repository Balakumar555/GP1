import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { catchError, map, Observable, retry, throwError } from 'rxjs';
import { getLocaleDateFormat } from '@angular/common';
import { computeMsgId } from '@angular/compiler';
import { SharedDataService } from '../shared/shareddata.service';
import { ActivatedRouteSnapshot } from '@angular/router';
import { User } from '../shared/model/user';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  //private baseURL = "https://qapoc.pahub.com/GrievanceAPI/Grievances";
  //private baseURL = 'https://localhost:7091/Grievances';  
  constructor(private httpClient: HttpClient,private sharedService:SharedDataService) { }

  resolve(route: ActivatedRouteSnapshot) : Observable<any>
  {
      return this.sharedService.getUserPrivileges();
     // let userRole = this.sharedService.getUserRole();
     // let data = {userPermissions: userPrivileges, userRole: userRole};
     // return of(data);
  }
  getUsersByCustomer(){    
    return this.httpClient.get<any>('/GetActiveUsersByCustomer')
    .pipe(map((response :any)=> {
      const result =Object.keys(response.result).map(x=>({
        userId: response.result[x].userId,
        custId:response.result[x].custId,
        fname: response.result[x].fname,
          lname: response.result[x].lname,
          usrEffectiveDate: response.result[x].usrEffectiveDate,
          usrEndDate: response.result[x].usrEndDate,
          email: response.result[x].email,
          mobile:response.result[x].mobile,        
          mname: response.result[x].mname,
          status: response.result[x].status, 
          userInitial: response.result[x].userInitial,
          roleId: response.result[x].roleId,
          loginId:response.result[x].loginId,
          roleName:response.result[x].role.roleName,
          affiliation:response.result[x].userTypeId,
          internal:[''],
          client:[''],
          clientIds:['']
      })) as User[]
      return result;      
  } ));
  }

  SaveUser(userData:any): Observable<any>
  {  
    //alert(FName MName LName,LoginId, Pwd, DDActive,Getcalsel,Affi,Phone,Initials,Email)
    //alert('In service before API call')
    var saveUserReq= userData;
    saveUserReq.userTypeId= userData.affiliation
    return this.httpClient.post<any>('/EditUser', saveUserReq);
  } 

  addUser(userData:any): Observable<any>
  {      
    var saveUserReq= userData;
    saveUserReq.userTypeId= userData.affiliation
    return this.httpClient.post<any>('/CreateUser', saveUserReq);
  } 

  loadUser(userId:string)
  {
    //alert('In service before API call')
    //alert(userId)
    return this.httpClient.get<any>('/GetUserDetailsByUserId?UserId=' + userId);    
  }

getCustomerRoles()
  {
    
    return this.httpClient.get<any>('/GetRolesByCustomer');
     
  }

  getAllAffiliationTypes()
  {    
    return this.httpClient.get<any>('/GetAllAffiliationTypes');
     
  }

  getAffiliatedUserClient(userId:any)
  {    
    return this.httpClient.get<any>('/GetAffiliatedUserClientsByUser?userId=' + userId);
     
  }
  
  getUsersByRole(roleId:any)
  { 
    const params = new HttpParams()
      .set('roleId', roleId);

    return this.httpClient.get<any>('/GetActiveUsersByRole')
    .pipe(map((response :any)=> {
     const result =Object.keys(response.result).map(x=>({
        userId: response.result[x].userId,
        name:  response.result[x].fname + ' ' + response.result[x].lname        
      })) as User[]
    //  this.sharedService.setOption('userRoleData',result);
      return result;      
  } ));
     
  }
  

}
