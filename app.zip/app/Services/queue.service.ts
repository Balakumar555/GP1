import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { catchError, map, Observable, retry, throwError } from 'rxjs';
import { getLocaleDateFormat } from '@angular/common';
import { computeMsgId } from '@angular/compiler';
import { SharedDataService } from '../shared/shareddata.service';
import { ActivatedRouteSnapshot } from '@angular/router';
import { User } from '../shared/model/user';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class QueueService { 
  constructor(private httpClient: HttpClient,private sharedService:SharedDataService) { }

  getUserQueues()
  {
    return this.httpClient.get<any>('/GetUserQueues');    
  }
  getQueueColumnConfiguration(queueId:any)
  {
    return this.httpClient.get<any>('/GetQueueColumnConfiguration?queueId='+queueId);    
  }
  getMyOpenCasesQueueData(selectedRequestTypes:any,
    selectedClientTypes:any,
    selectedMethodReceived:any,
    selectedPlanTypes:any,
    selectedBenefitDeterminations:any,
    isExportToExcel:any)
  {
    const inputs = new HttpParams()
    .set('requestTypes', selectedRequestTypes)
    .set('clientTypeIds', selectedClientTypes)
    .set('planTypeIds', selectedPlanTypes)
    .set('benefitDeterminations', selectedBenefitDeterminations)
    .set('methodReceived', selectedMethodReceived)
    .set('isExportToExcel', isExportToExcel);
    return this.httpClient.get('/GetMyOpenCasesQueueData', { params: inputs });
  }
}
