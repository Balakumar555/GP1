import { AfterViewInit, Component, OnInit, ViewChild, ViewEncapsulation,Optional,Inject } from '@angular/core';
import { AbstractControl, AbstractControlOptions, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { QueueService } from 'src/app/Services/queue.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';
import { AuthService } from 'src/app/Services/auth.service';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { LookUpService } from 'src/app/shared/services/LookUp.service';
import { LookUp } from 'src/app/shared/model/LookUp';
import { LookUps } from 'src/app/shared/constants/lookUp';
import { ClientManagementService } from '../client-plan-group-management/client-management.service';
import { ExportService } from 'src/app/shared/services/Export.service';

@Component({
  selector: 'app-queue-management',
  templateUrl: './queue-management.component.html',
  encapsulation: ViewEncapsulation.None

})

export class QueueManagementComponent implements OnInit {

  @ViewChild('queueTbSort') queueTbSort = new MatSort(); 
  // @ViewChild(MatSort) set queueTbSort(sort:MatSort)
  // {
  //   this.queueData.sort=this.queueTbSort
  // }
  queueData: any; 
  moment = moment;
  userQueues: any = [];
  
  selectedQueueColumnConfiguration: any[]=[];
  displayedColumns: string[] = [];
  benefitDeterminations!: any[];
  clientTypes!:any[];
  planTypes!: any[];
  groupTypes!: any[];
  MethodReceived!:any[];
  RequestTypes!:any[];
  selectedClientTypes: any = '';
  selectedPlanTypes: any = '';
  selectedGroupTypes: any = '';
  selectedMethodReceived: any = '';
  selectedBenefitDeterminations: any = '';
  selectedRequestTypes: any = '';
  isExportExcel:boolean=false;
  selectedQueueId:any=0;
  selectedQueueName:any='';
  
  queueManagerForm = this.fb.group({
    cmbRequestTypes: [''],
    cmbClientTypes: [''],
    cmbMethodReceived: [''],
    cmbPlanTypes: [''],
    cmbBenefitDeterminations: [''],
    client: []   
  });
  get f(): { [key: string]: AbstractControl } {
  return this.queueManagerForm.controls;

  }
  constructor(public dialog: MatDialog, private authService: AuthService, private route: ActivatedRoute, 
    private queueService: QueueService, private router: Router, private fb: FormBuilder, 
    private sharedService: SharedDataService,private lookupService:LookUpService,
    private clientService:ClientManagementService,private exportService:ExportService) 
  {    
    
  }
  ngAfterViewInit(): void {
  }

  ngOnInit(): void {
    this.getUserQueues();
    this.getQueueColumnConfiguration();
    this.getAllClientTypes();
    this.getAllPlanTypes();
    this.getAllGroupTypes();
    this.getLookUpsByLookUpName(LookUps.BenefitDetermination);
    this.getLookUpsByLookUpName(LookUps.MethodReceived);
    this.getLookUpsByLookUpName(LookUps.RequestType);
  }
  getUserQueues()
  {
    this.queueService.getUserQueues().subscribe(data => {
      this.userQueues = data.result
    });
  }
  getQueueColumnConfiguration(){
    this.queueService.getQueueColumnConfiguration(8001).subscribe(data => {
      this.selectedQueueColumnConfiguration = data.result;
      this.displayedColumns = this.displayedColumns.concat(this.selectedQueueColumnConfiguration.map(
        x => x.columnValue));  
    });
  }
  onQueueChange(selectedQueue: any) {  
    this.selectedQueueId=  selectedQueue.queueId;
    this.selectedQueueName=  selectedQueue.queueName;
    this.getSelectedQueueResult(this.selectedQueueId);
  }
  getSelectedQueueResult(queueId: any) {
    if (queueId == 8001) {
        this.queueService.getMyOpenCasesQueueData(this.selectedRequestTypes,
        this.selectedClientTypes,
        this.selectedMethodReceived,
        this.selectedPlanTypes,
        this.selectedBenefitDeterminations,
        this.isExportExcel).subscribe({
          next:
            (response: any) => {
              if (response.errorContent.statusCode == "200") {  
                this.queueData = new MatTableDataSource<any>(response.result);
                  setTimeout(() => this.queueData.sort = this.queueTbSort);             
                if (this.isExportExcel == true)
                {                  
                  let exportQueueData: any[] = response.result
                  let new_Date: Date = new Date();
                  let formattedDate = (moment(new_Date)).format('MMDDYYYYHHmmss');   
                  let fileName = this.selectedQueueName.replace(/\s/g, "") + '_' + formattedDate;       
                  this.exportService.exportExcel(exportQueueData,fileName ,"",this.displayedColumns);
                }
                else
                {
                  //this.queueData = response.result;
                 // this.queueData = new MatTableDataSource<any>(response.result);
                 // setTimeout(() => this.queueData.sort = this.queueTbSort);
                }
                this.isExportExcel=false;
              }
            }
        });
    }
  }
  
  getAllClientTypes()
  {
    this.clientService.getAllClientTypes()
    .subscribe(cType => {
      this.clientTypes=cType.result;
    })
  }
  getAllPlanTypes() {
    this.clientService.getAllPlanTypes().subscribe(data => {
        this.planTypes = data.result;      
      });
  }
  getAllGroupTypes()
  {
    this.clientService.getAllGroupTypes()
    .subscribe(groupType => {
      this.groupTypes=groupType.result;
    })
  }
  
  getLookUpsByLookUpName(lookUpName: any) {
    this.lookupService.geLookUpsByLookUpName(lookUpName).subscribe((data: LookUp[]) => {
      switch (lookUpName) {        
        case LookUps.BenefitDetermination:
          this.benefitDeterminations = data;
          break;
        case LookUps.MethodReceived:
          this.MethodReceived = data;
          break;
        case LookUps.RequestType:
            this.RequestTypes = data;
            break;
        default:
          break;
      }
    })
  }

  getQueueSearchResult(IsExport:any){
    this.isExportExcel=IsExport;
    this.getSelectedQueueResult(this.selectedQueueId);    
   
  }
  
  onRequestTypeChange(selectedItems:any){    
    this.selectedRequestTypes=Array.prototype.map.call(selectedItems, function(item) { return item.key; }).join(",");
  }
  onClientTypeChange(selectedItems:any){
    this.selectedClientTypes=Array.prototype.map.call(selectedItems, function(item) { return item.clientTypeId; }).join(",");
  }
  onMethodReceivedChange(selectedItems:any){
    this.selectedMethodReceived=Array.prototype.map.call(selectedItems, function(item) { return item.value; }).join(",");
  }
  onPlanTypeChange(selectedItems:any){
    this.selectedPlanTypes=Array.prototype.map.call(selectedItems, function(item) { return item.planTypeId; }).join(",");
  }
  onBenefitDeterminationChange(selectedItems:any){
    this.selectedBenefitDeterminations=Array.prototype.map.call(selectedItems, function(item) { return item.key; }).join(",");
  }
  clearSearchCriteria()
  {
    this.queueManagerForm.reset()
  }

}







