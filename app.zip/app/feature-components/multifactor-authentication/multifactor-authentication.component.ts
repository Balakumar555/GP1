import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multifactor-authentication',
  templateUrl: './multifactor-authentication.component.html',
  styleUrls: ['./multifactor-authentication.component.css']
})
export class MultifactorAuthenticationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
