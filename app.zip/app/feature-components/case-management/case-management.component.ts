
import { AfterViewInit, Component, OnInit, ViewChild,ViewEncapsulation } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UsersService } from 'src/app/Services/users.service';
import { Buffer } from 'buffer';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';

import { AuthService } from 'src/app/Services/auth.service';
import { Roles } from 'src/app/shared/constants/role';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { CONFIG } from 'src/app/shared/config';
import { Permissions } from 'src/app/shared/constants/permissions';
import { User } from 'src/app/shared/model/user';
import { CaseDetail } from 'src/app/shared/model/caseDetail';
import { CaseService } from './case.service';
//import { EncryptDecryptService } from 'src/app/shared/services/encrypt-decrypt.service';


@Component({
  selector: 'app-case-management',
  templateUrl: './case-management.component.html',
 // styleUrls: ['./case-management.component.css'],
  encapsulation: ViewEncapsulation.None

})

export class CaseManagementComponent implements AfterViewInit {
  

  //@ViewChild('usrTbSort') usrTbSort = new MatSort();  
  //addUser: boolean = false;
  editForm: boolean = false;
  dataLoad: boolean = false;
  _userId: string = "";
  userData: any;
  event: Event | undefined;
  show = false;
  moment = moment;
  role: number = 0;
  displayedColumns: string[] = ['caseId', 'status','assigneeName','partType', 'source', 'dueDate', 'receivedDate', 'incidentDate', 'actions'];
  pageOptions: number[] = [5, 10, 20];
  @ViewChild(MatPaginator, { static: false }) paginator!: MatPaginator;
  userPermissions: any = {};
  
  constructor(
    public dialog: MatDialog,private authService:AuthService, private route: ActivatedRoute ,private caseService: CaseService, private router: Router, private fb: FormBuilder, private sharedService:SharedDataService
  ) {

  }
  ngAfterViewInit(): void {

  }

  ngOnInit(): void {
    this.userPermissions = this.route.snapshot.data['userPermissions'];
    this.bindGrid();
    console.log(sessionStorage.getItem("customerId")!)
    //const currentUser = this.authService.currentUserValue;
   // this.role =this.sharedService.getRole();
  }
  getLink(caseId:any)
  {
    return './case-details/'+ caseId
    
  }
canUserHasAddPermission()
{  
  
  return this.sharedService.hasPermission(Permissions.CreateNewUser, this.userPermissions.result)  
 
}

canUserHasEditPermission()
{    
  return this.sharedService.hasPermission(Permissions.EditExistingUser, this.userPermissions.result)  
 
}
  
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.userData.filter = filterValue.trim().toLowerCase();

    if (this.userData.paginator) {
      this.userData.paginator.firstPage();
    }
  }
  bindGrid() {
    this.caseService.getAllCaseDetail().subscribe(data => {
      this.userData = new MatTableDataSource<CaseDetail>(data.result);
      //this.userData.sort = this.usrTbSort;
      this.userData.paginator = this.paginator;
      this.dataLoad = true;

    })
  }

}







