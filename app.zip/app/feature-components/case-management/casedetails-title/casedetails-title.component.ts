import { Component, ElementRef, EventEmitter, Input, OnInit, Optional, Output, ViewChild, ViewEncapsulation } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, MaxLengthValidator, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import * as moment from 'moment';
import { CaseService } from '../case.service';
import { UsersService } from 'src/app/Services/users.service';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';
import { map, Observable, of, startWith } from 'rxjs';
import { Roles } from 'src/app/shared/constants/role';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { Permissions } from 'src/app/shared/constants/permissions';
import { User } from 'src/app/shared/model/user';
import { LookUpService } from 'src/app/shared/services/LookUp.service';
import { LookUp } from 'src/app/shared/model/LookUp';
import { LookUps } from 'src/app/shared/constants/lookUp';
import { ModelDialogsService } from 'src/app/shared/model-dialog/model-dialog.service';
import { CaseStatus, Category } from 'src/app/shared/model/caseDetail';

@Component({
  selector: 'app-casedetails-title',
  templateUrl: './casedetails-title.component.html',
  styleUrls: ['./casedetails-title.component.css']
})
export class CasedetailsTitleComponent implements OnInit {
  
  filteredOptions!: Observable<User[]>;
  userPermissions: any = {};
  assignee: User | undefined;
  readOnly: boolean = false;

  addCaseDetailForm = this.fb.group({
    memberInfo: this.fb.group({
      firstName: ['', [Validators.required]],
      middleName: [''],
      lastName: ['', [Validators.required]],
      dateOfBirth: [moment(new Date()).format(), [Validators.required]],
      gender: ['', [Validators.required]],
      addressLine1: ['', [Validators.required]],
      addressLine2: [''],
      state: ['', [Validators.required]],
      city: ['', [Validators.required]],
      zip: ['', [Validators.required, Validators.pattern('[0-9]{5}')]],
      homePhone: ['', [Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      workPhone: ['', [Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      fax: [''],
      cellPhone: ['', [Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      communicationPrefrence: [''],
      email: ['', [Validators.email, Validators.maxLength(50)]],
      languagePrefrence: [''],
      memberNumber: [''],
      mbi: [''],
      clientId: [1],
      planId: [1],
      clientName: [''],
      planName: ['']
    }),
    caseId: [''],
    assigneeId: [''],
    assigneeName: [''],
    receivedTime: ['', [Validators.required]],
    statusId: ['', [Validators.required]],
    incidentDate: [moment(new Date()).format(), [Validators.required]],
    dueDate: [moment(new Date()).format(), [Validators.required]],
    receivedDate: [moment(new Date()).format(), [Validators.required]],
    method: ['', [Validators.required]],
    requestor: ['', [Validators.required]],
    requestType: ['', [Validators.required]],
    categoryId: ['', [Validators.required]],
    subCategory: [''],
    source: [''],
    urgency: ['', [Validators.required]],
    highPriority: [false],
    extensionTaken: [false],
    partType: ['', [Validators.required]],
    complianceCase: [false],
    goodCause: [false],
    description: ['', [Validators.required, Validators.maxLength(2000)]],
    isAor: [false],
    firstTier: [''],
    createdDate: [new Date()],
    lastModifiedBy: [],
    lastModifiedDate: [],
    aorInfo: this.fb.group({
      aorFirstName: [''],
      aorMiddleName: [''],
      aorLastName: [''],
      aorEmail: ['', [Validators.email, Validators.maxLength(50)]],
      memberSignatureDate: [moment(new Date()).format()],
      apointeeSignatureDate: [moment(new Date()).format()],
      aorCity: [''],
      aorAddressLine1: [''],
      aorAddressLine2: [''],
      aorPhone: ['', [Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      aorZip: ['', [Validators.pattern('[0-9]{5}')]],
      aorState: [''],
      aorRelationship: [''],
      formReceived: [false],
      aorFormReceivedDate: [moment(new Date()).format()],
      aorFormReceivedTime: ['']

    }),   customerId: localStorage.getItem("customerId")!,
    createdBy: localStorage.getItem("userId")!,
    draftCaseDetailId: [0],
    caseDetailId: [0] })

  constructor(private sharedService: SharedDataService, private fb: FormBuilder) { }

  ngOnInit(): void {
  }
  canUserHasAssignPermission() {

    return this.sharedService.hasPermission(Permissions.AssignCaseWorker, this.userPermissions.result)

  }
  displayFn(user: User): string {
    return user && user.name ? user.name : '';
  }
}
