import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CasedetailsTitleComponent } from './casedetails-title.component';

describe('CasedetailsTitleComponent', () => {
  let component: CasedetailsTitleComponent;
  let fixture: ComponentFixture<CasedetailsTitleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CasedetailsTitleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CasedetailsTitleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
