import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { CaseService } from '../case.service';

@Component({
  selector: 'app-communication-log',
  templateUrl: './communication-log.component.html',
  styleUrls: ['./communication-log.component.css']
})
export class CommunicationLogComponent implements OnInit {
  router: any;
  updateUserInfo: any;
  email = 'emailtest'

  items = [''];

public time = [''];
public date = [''];
  constructor(private caseService: CaseService) {}

  ngOnInit() {
    this.caseService.getNewUserInfo().subscribe(info => {
      this.updateUserInfo = info;
    })
  }

onViewDetials(){
  console.log('view details working')
}
OnSaveNote(){

  console.log('working')
}
addItem(newItem: string) {
  this.items.push(newItem);
  // this.items.push(time);

}
}
