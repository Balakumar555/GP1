import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseNmiOutcomeComponent } from './case-nmi-outcome.component';

describe('CaseNmiOutcomeComponent', () => {
  let component: CaseNmiOutcomeComponent;
  let fixture: ComponentFixture<CaseNmiOutcomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CaseNmiOutcomeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CaseNmiOutcomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
