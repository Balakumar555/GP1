import { Component, OnInit } from '@angular/core';
import { AbstractControl, ControlValueAccessor, FormBuilder, NG_VALUE_ACCESSOR, Validators } from '@angular/forms';
import { CaseService } from '../case.service';

@Component({
  selector: 'app-case-nmi-outcome',
  templateUrl: './case-nmi-outcome.component.html',
  styleUrls: ['./case-nmi-outcome.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi:true,
      useExisting: CaseNmiOutcomeComponent
    }
  ]
})
export class CaseNmiOutcomeComponent implements OnInit,ControlValueAccessor {
  nmiOutcomes:any
  expandCard:boolean=true;
  constructor(private caseService: CaseService, private fb: FormBuilder) { }
  nmiOutcome = this.fb.group({    
    outcome:[, [Validators.required]],
    outcomeDescription:[,[Validators.required]]
  })
  public onTouched: () => void = () => {};
  writeValue(obj: any): void {
    obj && this.nmiOutcome.patchValue(obj, { emitEvent: false });
    if(obj && obj.outcome!=null)
    this.expandCard=false
  }
  registerOnChange(fn: any): void {
    this.nmiOutcome.valueChanges.subscribe(fn);    
  }
  registerOnTouched(fn: any): void {
    this.onTouched=fn;
  }
  setDisabledState?(isDisabled: boolean): void {
    isDisabled ? this.nmiOutcome.disable() : this.nmiOutcome.enable();
  }
  ngOnInit(): void {
    this.getNMIOutcome()
  }
  getNMIOutcome()
  {
    this.caseService.getNMIOutcome().subscribe(data => {
      this.nmiOutcomes = data
    })
  }
  get f(): { [key: string]: AbstractControl } {

    return this.nmiOutcome.controls;

  }
}
