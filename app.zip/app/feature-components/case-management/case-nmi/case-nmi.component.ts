import { Component, OnInit } from '@angular/core';
import { AbstractControl, ControlValueAccessor, FormBuilder, NG_VALUE_ACCESSOR, Validators } from '@angular/forms';
import { CaseService } from '../case.service';

@Component({
  selector: 'app-case-nmi',
  templateUrl: './case-nmi.component.html',
  styleUrls: ['./case-nmi.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi:true,
      useExisting: CaseNmiComponent
    }
  ]
})
export class CaseNmiComponent implements OnInit,ControlValueAccessor {
nmiReasons:any
nmiOutcomes:any
expandCard:boolean=true;
nmiInfo = this.fb.group({
  nmiReason:[, [Validators.required]],
  nmiDescription:[, [Validators.required]] 
})
  constructor(private caseService: CaseService, private fb: FormBuilder) { }
  public onTouched: () => void = () => {};
  writeValue(obj: any): void {
    obj && this.nmiInfo.patchValue(obj, { emitEvent: false });
    if(obj && obj.nmiReason!=null)
    this.expandCard=false
  }
  registerOnChange(fn: any): void {
    this.nmiInfo.valueChanges.subscribe(fn);
  }
  registerOnTouched(fn: any): void {
    this.onTouched=fn;
  }
  setDisabledState?(isDisabled: boolean): void {
    isDisabled ? this.nmiInfo.disable() : this.nmiInfo.enable();
  }

  ngOnInit(): void {
    this.getNMIReason()    
    
  }

  getNMIReason()
  {
    this.caseService.getNMIReason().subscribe(data => {
      this.nmiReasons = data
    })
  }

  get f(): { [key: string]: AbstractControl } {

    return this.nmiInfo.controls;

  }


}
