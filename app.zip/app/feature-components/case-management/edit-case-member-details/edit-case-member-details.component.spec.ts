import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditCaseMemberDetailsComponent } from './edit-case-member-details.component';

describe('EditCaseMemberDetailsComponent', () => {
  let component: EditCaseMemberDetailsComponent;
  let fixture: ComponentFixture<EditCaseMemberDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditCaseMemberDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditCaseMemberDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
