
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { Roles } from 'src/app/shared/constants/role';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from 'src/app/material.module';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CaseManagementComponent } from './case-management.component';
import { AddCaseDetailsComponent } from './add-case-details/add-case-details.component';
import { PreventUnsavedChangesGuard } from 'src/app/core/guards/prevent-unsaved-changes.guard';
import { SharedModule } from 'src/app/shared/shared.module';
import { CommentsSectionComponent } from './comments-section/comments-section.component';
import { CommunicationLogComponent } from './communication-log/communication-log.component';
import { CaseDetailsPageComponent } from './case-details-page/case-details-page.component';
import { VerbalNotificationComponent } from "./verbal-notification/verbal-notification.component";
//import { MemberRepComponent } from './member-rep/member-rep.component';
import { AddCommentComponent } from './comments-section/add-comment/add-comment.component';
//import { CommentListComponent } from './comments-section/comment-list/comment-list.component';
import { DATE_PIPE_DEFAULT_TIMEZONE } from '@angular/common';
import { CaseService } from './case.service';
import { CasedetailsTitleComponent } from './casedetails-title/casedetails-title.component';
//import { CaseDetailsInformationPageComponent } from './case-details-information-page/case-details-information-page.component';
import { ContactInformationComponent } from './contact-information/contact-information.component';
import { CaseInformationComponent } from './case-information/case-information.component';
import { EditCommentComponent } from './comments-section/edit-comment/edit-comment.component';
import { EditCaseMemberDetailsComponent } from './edit-case-member-details/edit-case-member-details.component';

import { MemberinfComponent } from './view-case-member-details/memberinfo/memberinfo.component';
import { MemberRepInfoComponent } from './view-case-member-details/member-rep-info/member-rep-info.component';
import { CaseSummaryComponent } from './view-case-member-details/case-summary/case-summary.component';
import { EditCaseAORDetailsComponent } from './edit-case-aor-details/edit-case-aor-details.component';
import { EditCasePOADetailsComponent } from './edit-case-poa-details/edit-case-poa-details.component';
//import { MemberRepComponent } from './member-rep/member-rep.component';
import { NgxMaskModule } from 'ngx-mask';
import { CaseNmiComponent } from './case-nmi/case-nmi.component';
import { CaseExtensionComponent } from './case-extension/case-extension.component';
import { CaseNmiOutcomeComponent } from './case-nmi-outcome/case-nmi-outcome.component';
//import { NavigationComponent } from 'src/app//feature-components/navigation/navigation.component';
const routes: Routes = [
  {
     path: '', component: CaseManagementComponent, canActivate:[AuthGuard],canDeactivate:[PreventUnsavedChangesGuard],resolve: { userPermissions: CaseService },data: {roles: [Roles.CaseWorker,Roles.Management]}

  } ,
  {
    path:'case-details',component: AddCaseDetailsComponent, canActivate:[AuthGuard],resolve: { userPermissions: CaseService }, canDeactivate:[PreventUnsavedChangesGuard],data: {roles: [Roles.CaseWorker,Roles.Management,Roles.Triage]}
  },
  {path:'case-details/:id',component: AddCaseDetailsComponent, canActivate:[AuthGuard],resolve: { userPermissions: CaseService },data: {roles: [Roles.CaseWorker,Roles.Management,Roles.Triage]}},
  {path:'case-details/:status/:id',component: AddCaseDetailsComponent, canActivate:[AuthGuard],resolve: { userPermissions: CaseService },data: {roles: [Roles.CaseWorker,Roles.Management,Roles.Triage]}},
  {path:'case-details-page/:id',component: CaseDetailsPageComponent,children:[
    {path:'communication-log',component: CommunicationLogComponent, canActivate:[AuthGuard],resolve: { userPermissions: CaseService },data: {roles: [Roles.CaseWorker,Roles.Management,Roles.Triage]}},
    {path: '', component: CommunicationLogComponent, },
    {path: 'verbal-notification', component: VerbalNotificationComponent}
  ],canActivate:[AuthGuard],resolve: { userPermissions: CaseService },data: {roles: [Roles.CaseWorker,Roles.Management,Roles.Triage]}},
  //{path: 'case-details-information-page', component:CaseDetailsInformationPageComponent}
];
@NgModule({
    declarations: [
      CaseManagementComponent,
        AddCaseDetailsComponent,
        CommentsSectionComponent,
        CommunicationLogComponent,
        CaseDetailsPageComponent,
        VerbalNotificationComponent,
        EditCommentComponent,
      //  MemberRepComponent,
     CasedetailsTitleComponent,        
      AddCommentComponent,
      //  CommentListComponent
   //   CaseDetailsInformationPageComponent,
      ContactInformationComponent,
      CaseInformationComponent,
      EditCaseMemberDetailsComponent,
      EditCaseAORDetailsComponent,
      EditCasePOADetailsComponent ,
    //  DuedateComponent,
      MemberinfComponent,
      MemberRepInfoComponent,
      CaseSummaryComponent,
      CaseNmiComponent,
      CaseExtensionComponent,
      CaseNmiOutcomeComponent,
        ],
    providers: [[{ provide: MAT_DIALOG_DATA, useValue: {} }],
        [{ provide: MatDialogRef, useValue: {} }],
        {provide: DATE_PIPE_DEFAULT_TIMEZONE, useValue: {dateFormat: 'shortDate'}}],

    imports: [
        RouterModule.forChild(routes),
        NgxMaskModule.forChild(),
        CommonModule,
        MaterialModule,
        //CoreModule,
        SharedModule,
        //AppModule,
        FormsModule,
        ReactiveFormsModule
    ]
})

export class CaseManagementModule { }
