import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { BehaviorSubject, catchError, map, Observable, retry, tap, throwError } from 'rxjs';
import { getLocaleDateFormat, JsonPipe } from '@angular/common';
import { computeMsgId } from '@angular/compiler';
import { Buffer } from 'buffer';
import { ActivatedRouteSnapshot } from '@angular/router';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { User } from 'src/app/shared/model/user';
import { CaseDetail, CaseStatus, Category } from 'src/app/shared/model/caseDetail';
import { CommentsSectionComponent } from './comments-section/comments-section.component';
import * as moment from 'moment';
import { MemberDetail } from 'src/app/shared/model/memberDetail';
import { LookUp } from 'src/app/shared/model/LookUp';
//import { EncryptDecryptService } from 'src/app/shared/services/encrypt-decrypt.service';



@Injectable({
  providedIn: 'root'
})


export class CaseService {
  //private baseURL = "https://qapoc.pahub.com/GrievanceAPI/Grievances";
  //private baseURL = 'https://localhost:7091/Grievances';
  //_commentList:CommentsElements[] =[];

  constructor(
    private httpClient: HttpClient,
    private sharedService:SharedDataService,
    //private encryptDecryptService: EncryptDecryptService
 ) { }

public newUser = new BehaviorSubject<any>({
  firstName: '',
  email: '',
  g: '',
});

 setNewUserInfo(user: any) {
    this.newUser.next(user);
  }

  getNewUserInfo() {
    return this.newUser.asObservable();
  }

  resolve(route: ActivatedRouteSnapshot)
  {
      return this.sharedService.getUserPrivileges();
  }

  // callAllApi() {
  //   let uerPermissions = this.sharedService.getUserPrivileges()
  //   let memberDetail = this.userService.getCustomerRoles()
  //   let allAffiliationTypes = this.userService.getAllAffiliationTypes()
  //   return forkJoin([activeClients, customerRoles, allAffiliationTypes])
  // }

  getUsersByCustomer(){   
    return this.httpClient.get<any>('/GetActiveUsersByCustomer')
    .pipe(map((response :any)=> {
      const result =Object.keys(response.result).map(x=>({
        userId: response.result[x].userId,
        custId:response.result[x].custId,
        fname: response.result[x].fname,
          lname: response.result[x].lname,
          usrEffectiveDate: response.result[x].usrEffectiveDate,
          usrEndDate: response.result[x].usrEndDate,
          email: response.result[x].email,
          mobile:response.result[x].mobile,
          mname: response.result[x].mname,
          status: response.result[x].status,
          userInitial: response.result[x].userInitial,
          roleId: response.result[x].roleId,
          loginId:response.result[x].loginId,
          roleName:response.result[x].role.roleName,
          affiliation:response.result[x].affiliation
      })) as User[]
      return result;
  } ));
  }

  SaveCase(caseData:any,caseDetailId:any): Observable<any>
  {
    //alert(FName MName LName,LoginId, Pwd, DDActive,Getcalsel,Affi,Phone,Initials,Email)
    //alert('In service before API call')
    //let data = {userPermissions: userPrivileges, userRole: userRole};
    let lastModifiedBy = null
    
    var saveCaseReq={caseData:JSON.stringify(caseData), createdBy:0, draftCaseDetailId:caseDetailId, createdDate:new Date(), lastModifiedBy:0};
    return this.httpClient.post<any>('/CreateDraftCase', saveCaseReq);
  }

  SubmitCase(caseData:any): Observable<any>
  {
    //alert(FName MName LName,LoginId, Pwd, DDActive,Getcalsel,Affi,Phone,Initials,Email)
    //alert('In service before API call')
    var saveCaseReq= caseData;
    return this.httpClient.post<any>('/CreateCase', saveCaseReq);
  }

  UpdateCase(caseData:any): Observable<any>
  {
    //alert(FName MName LName,LoginId, Pwd, DDActive,Getcalsel,Affi,Phone,Initials,Email)
    //alert('In service before API call')
    //var saveCaseReq= caseData;
    return this.httpClient.post<any>('/UpdateCase', caseData);
  }



getAllStatus()
  {
    //var customerId = localStorage.getItem("customerId");
    return this.httpClient.get<any>('/GetAllStatus').pipe(map((response: any) => {
      const result = Object.keys(response.result).map(x => ({
          CaseStatusId: response.result[x].caseStatusId,
          Status: response.result[x].status
      })) as CaseStatus[]
      return result;
    }));

  }

  getAllActions(caseId:any)
  {
    //var customerId = localStorage.getItem("customerId");
    return this.httpClient.get<any>('/GetAllEligibleActions?caseId=' + caseId).pipe(map((response: any) => {
      const result = Object.keys(response.result).map(x => ({
          CaseStatusId: response.result[x].caseStatusId,
          Status: response.result[x].status
      })) as CaseStatus[]
      return result;
    }));

  }

  getCategories()
  {
    //var customerId = localStorage.getItem("customerId");
    return this.httpClient.get<Category>('/GetCategories').pipe(map((response: any) => {
      const result = Object.keys(response.result).map(x => ({
        CategoryId: response.result[x].categoryId,
          CategoryName: response.result[x].categoryName
      })) as Category[]
      return result;
    }));

  }

  getAllCaseDetail()
  {
    var customerId = localStorage.getItem("customerId");
    return this.httpClient.get<any>('/GetAllCaseDetails?customerId=' + customerId);

  }

  getCaseDetailsById(caseId:any) : Observable<CaseDetail>
  {
    var customerId = localStorage.getItem("customerId")!;

    const params = new HttpParams()
      .set('caseId', caseId)
      .set('customerId', customerId);

    return this.httpClient.get<CaseDetail>('/GetCaseDetailById', { params: params }).pipe(
      map((response: any) => response.result)
      );

  }

  getEligibilityMemberDetailById(memberId:any) : Observable<MemberDetail>
  {

    return this.httpClient.get<MemberDetail>('/GetEligibilityMemberDataById?memberId=' + memberId).pipe(
      map((response: any) => response.result)
      );

  }

  discardDraftCase(caseDetailId:any) : Observable<any>
  {
    const params = new HttpParams()
      .set('draftCaseDetailId', caseDetailId);
    return this.httpClient.post<any>('/DiscardDraftCase', '', { params: params });

  }

  getDashboardData(searchParams:any)
  {   
      const params =new HttpParams()
      .set('mbi',searchParams.mbi)
      .set('caseId',searchParams.caseId)
      .set('memberNumber',searchParams.memberNumber)
      .set('dob', searchParams.dob)// moment(searchParams.dob).format())
      .set('firstName',searchParams.firstName)
      .set('lastName',searchParams.lastName)


      // {mbi:searchParams.mbi.toString(),caseId:searchParams.caseId.toString(),memberNumber:searchParams.memberNumber.toString(),dob:searchParams.dob,firstName:searchParams.firstName.toString(),lastName:searchParams.lastName.toString()};
       return this.httpClient.get('/GetDashboardData',{params:params});
}

GetCaseAttachments(customerId:any,caseId: any): Observable<any> { 

  const params = new HttpParams()
    .set('CustomerId', customerId)
    .set('CaseId', caseId)
  return this.httpClient.get('/GetCaseAttachments',{params:params}).pipe(map((response: any) => {
    const result = Object.keys(response.result).map(x => ({
        key: response.result[x].caseAttachmentId,
        value: response.result[x].fileName
    })) as LookUp[]
    return result;
  }));
}

CreateComment(commentDetail:any): Observable<any>
{
  return this.httpClient.post<any>('/CreateCaseComment', commentDetail);
}

UpdateComment(commentDetail:any, isDeleted:boolean): Observable<any>
{
  commentDetail.isDeleted=isDeleted
  return this.httpClient.post<any>('/UpdateCaseComment', commentDetail);
}

getCaseCommentsByCaseId(caseId:any) : Observable<any>
  {
   
    return this.httpClient.get<any>('/GetCaseCommentByCaseId?caseId=' + caseId).pipe(  
      map((response: any) => response.result)      
      );  
     
  }

  getNMIReason() : Observable<any>
  {   
    return this.httpClient.get<any>('/GetNMIReason').pipe(  
      map((response: any) => response.result)      
      );
  }

  getExtensionReason() : Observable<any>
  {   
    return this.httpClient.get<any>('/GetExtensionReason').pipe(  
      map((response: any) => response.result)      
      );
  }

  getNMIOutcome() : Observable<any>
  {   
    return this.httpClient.get<any>('/GetNMIOutcome').pipe(  
      map((response: any) => response.result)      
      );
  }
 
  // addComment( comment:CommentsElements){
  //   comment.ID = this._commentList.length +1;
  //   this._commentList.push(comment);
  // }

  // editComment( comment:CommentsElements){
  //  const index = this._commentList.findIndex(c => c.ID === comment.ID);
  //   this._commentList[index]=comment;
  // }

  // deleteComment(id:number){
  //   const comment = this._commentList.findIndex(c => c.ID === id);
  //   this._commentList.splice(comment, 1);
  // }

  // getAllComments(){
  //   return this._commentList;
  // }

  SaveComment(userData:any): Observable<any>
  {  
    //alert(FName MName LName,LoginId, Pwd, DDActive,Getcalsel,Affi,Phone,Initials,Email)
    //alert('In service before API call')
    var saveUserReq= userData;
    saveUserReq.userTypeId= userData.affiliation
    return this.httpClient.post<any>('/EditUser', saveUserReq);
  } 

}
