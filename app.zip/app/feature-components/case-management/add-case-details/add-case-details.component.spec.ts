import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AddCaseDetailsComponent } from './add-case-details.component';
import { LookUp } from 'src/app/shared/model/LookUp';
import { LookUps } from 'src/app/shared/constants/lookUp';

describe('CaseDetailsComponent', () => {
  let component: AddCaseDetailsComponent;
  let fixture: ComponentFixture<AddCaseDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddCaseDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddCaseDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
