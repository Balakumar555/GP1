import { Component, ElementRef, EventEmitter, Input, OnInit, Optional, Output, ViewChild, ViewEncapsulation } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, MaxLengthValidator, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import * as moment from 'moment';
import { CaseService } from '../case.service';
import { UsersService } from 'src/app/Services/users.service';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';
import { map, Observable, of, startWith } from 'rxjs';
import { Roles } from 'src/app/shared/constants/role';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { Permissions } from 'src/app/shared/constants/permissions';
import { User } from 'src/app/shared/model/user';
import { LookUpService } from 'src/app/shared/services/LookUp.service';
import { LookUp } from 'src/app/shared/model/LookUp';
import { LookUps } from 'src/app/shared/constants/lookUp';
import { ModelDialogsService } from 'src/app/shared/model-dialog/model-dialog.service';
import { CaseStatus, Category } from 'src/app/shared/model/caseDetail';
import decode from 'jwt-decode';
import { IfStmt } from '@angular/compiler';



@Component({
  selector: 'app-case-details',
  templateUrl: './add-case-details.component.html',
  styleUrls: ['./add-case-details.component.css'],
  encapsulation: ViewEncapsulation.None

})


export class AddCaseDetailsComponent implements OnInit {
  panelOpenState = false;
  checked = false;
  isChecked = false;
  indeterminate = false;
  labelPosition: 'before' | 'after' = 'after';
  disabled = false;
  maxDescriptionChar = 2000;
  dueDate = moment(new Date()).format('MM/DD/yyyy');
  caseId: any = '00000X'
  public defaultTime = [new Date().getHours(), new Date().getMinutes()]
  aorFormReceived: any;
  caseDetail: any | undefined
  users!: User[]
  filteredOptions!: Observable<User[]>;
  userPermissions: any = {};
  assignee: User | undefined;
  showDiscard = false;
  caseStatusId: any;
  aorRelationShips!: any[];
  caseStatus!: any[];
  genders!: any[];
  categories!: any[];
  subCategories!: any[];
  benefitDeterminations!: any[];
  requestors!: any[];
  sources!: any[];
  communicationPreferences  !: any[];
  languagePreferences!: any[];
  relationshipCodes!: any[];
  representativeTypes!: any[];
  requestTypes!: any[];
  states!: any[];
  showSubCategory:boolean=false
  @Output() populateDueDate = new EventEmitter<{ dueDate: string, dueDateAlert: boolean }>()

  addCaseDetailForm = this.fb.group({
    caseId: [''],
    assigneeId: [''],
    assigneeName: [''],
    receivedTime: ['', [Validators.required]],
    statusId: ['', [Validators.required]],
    incidentDate: [moment(new Date()).format()],
    dueDate: [moment(new Date()).format(), [Validators.required]],
    receivedDate: [moment(new Date()).format(), [Validators.required]],
    method: ['', [Validators.required]],
    requestor: ['', [Validators.required]],
    requestType: ['', [Validators.required]],
    categoryId: ['', [Validators.required]],
    subCategory: [''],
    source: [''],
    urgency: ['', [Validators.required]],
    highPriority: [false],
    extensionTaken: [false],
    partType: ['', [Validators.required]],
    complianceCase: [false],
    goodCause: [false],
    description: ['', [Validators.required, Validators.maxLength(2000)]],
    isAor: [false],
    firstTier: [''],
    createdDate: [new Date()],
    lastModifiedBy: [],
    lastModifiedDate: [],
    customerId: localStorage.getItem("customerId")!,
    createdBy: localStorage.getItem("userId")!,
    draftCaseDetailId: [0],
    caseDetailId: [0],
    closedDate: [moment(new Date()).format()],
    //preferredContact:[''],
    memberInfo: this.fb.group({
      firstName: ['', [Validators.required]],
      middleName: [''],
      lastName: ['', [Validators.required]],
      dateOfBirth: [moment(new Date()).format(), [Validators.required]],
      gender: ['', [Validators.required]],
      addressLine1: ['', [Validators.required]],
      addressLine2: [''],
      state: ['', [Validators.required]],
      city: ['', [Validators.required]],
      zip: ['', [Validators.required, Validators.pattern('[0-9]{5}')]],
      homePhone: ['', [Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      workPhone: ['', [Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      fax: [''],
      cellPhone: ['', [Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      communicationPrefrence: [''],
      email: ['', [Validators.email, Validators.maxLength(50)]],
      languagePrefrence: [''],
      memberNumber: [''],
      mbi: [''],
      clientId: [1],
      planId: [1],
      clientName: [''],
      planName: [''],
      memberRepresentativeId:[0]
    }),
    aorInfo: this.fb.group({
      aorFirstName: [''],
      aorMiddleName: [''],
      aorLastName: [''],
      aorEmail: ['', [Validators.email, Validators.maxLength(50)]],
      memberSignatureDate: [moment(new Date()).format()],
      apointeeSignatureDate: [moment(new Date()).format()],
      aorCity: [''],
      aorAddressLine1: [''],
      aorAddressLine2: [''],
      aorPhone: ['', [Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      aorZip: ['', [Validators.pattern('[0-9]{5}')]],
      aorState: [''],
      aorRelationship: [''],
      formReceived: [false],
      aorFormReceivedDate: [moment(new Date()).format()],
      aorFormReceivedTime: ['']

    }),
  })
  caseWorker = new FormControl();
  readOnly: boolean = false;
  caseDetailId: any;
  caseWorkedId: any = null;
  customerId = localStorage.getItem("customerId")!
  maxDate = moment(new Date()).format()
  maxTime = moment(new Date(), "HH:mm")
  disableExtension: boolean = false
  alertDueDate: boolean = false
  showSubmit:boolean=true
  memberAccordionExpanded:boolean=true
  constructor(private dialogService: ModelDialogsService, private el: ElementRef, private fb: FormBuilder, private router: Router, private caseService: CaseService, private userService: UsersService, private toastr: ToastrService, protected route: ActivatedRoute, private sharedService: SharedDataService, private lookupService: LookUpService) {
    console.log("id", this.route.snapshot.params)
    if ('id' in this.route.snapshot.params) {
      // let userId = this.sharedService.getUserId()
      this.readOnly = true;
    }

    this.route.params.subscribe((params: Params) => {
      this.caseDetailId = params['id'] || ''
    })

    // this.users =  this.userService.getUsersByRole(Roles.CaseWorker);
    this.userService.getUsersByRole(Roles.CaseWorker).subscribe(data => {
      this.users = data
    })

    let memberData = this.sharedService.getMemberDetail()
    if (memberData) {
      this.addCaseDetailForm.controls.memberInfo.get("memberNumber")?.patchValue(memberData.planInfo.memberNumber)
      this.addCaseDetailForm.controls.memberInfo.get("mbi")?.patchValue(memberData.planInfo.MBI)
      this.addCaseDetailForm.controls.memberInfo.get("clientId")?.patchValue(memberData.planInfo.clientId)
      this.addCaseDetailForm.controls.memberInfo.get("planId")?.patchValue(memberData.planInfo.planId)
      this.addCaseDetailForm.controls.memberInfo.get("memberRepresentativeId")?.patchValue(this.sharedService.getEligibilityMemberId())
      this.addCaseDetailForm.controls.memberInfo.patchValue(memberData.memberInfo)

      // this.addCaseDetailForm.get("memberInfo.MBI")?.patchValue(memberData.planInfo.MBI)
      // this.addCaseDetailForm.get("memberInfo.memberNumber")?.patchValue(memberData.planInfo.memberNumber)
      if (memberData.aorInfo) {
        this.isChecked = true
        this.addCaseDetailForm.get("isAor")?.patchValue(true)
        this.addCaseDetailForm.controls.aorInfo.setValue(memberData.aorInfo)
      }

    }

    // this.filteredOptions =this.caseWorkerFormControl?.valueChanges.pipe(
    //   startWith('') ,
    //   debounceTime(400),
    //   distinctUntilChanged(),
    //   switchMap((val) =>  {
    //    // if(val && typeof val != 'object')
    //         return this.filterValue(val && typeof val === 'object' ? val.name :val)
    //     //   else
    //     //   return of([])
    //    })
    // )







    this.getLookUpsByLookUpName(LookUps.AORRelationShip);
    this.getLookUpsByLookUpName(LookUps.Gender);
    this.getLookUpsByLookUpName(LookUps.SubCategory);
    this.getLookUpsByLookUpName(LookUps.Source);
    this.getLookUpsByLookUpName(LookUps.LanguagePreference);
    this.getLookUpsByLookUpName(LookUps.CommunicationPreference);
    this.getLookUpsByLookUpName(LookUps.RelationCode);
    this.getLookUpsByLookUpName(LookUps.RepresentativeType);
    this.getLookUpsByLookUpName(LookUps.RequestType);
    this.getLookUpsByLookUpName(LookUps.State);
    this.getLookUpsByLookUpName(LookUps.BenefitDetermination);
    this.getLookUpsByLookUpName(LookUps.Requestor);




    this.caseService.getAllStatus().subscribe((data: CaseStatus[]) => {
      this.caseStatus = data;
    });

    this.caseService.getCategories().subscribe((data: Category[]) => {
      this.categories = data;
    });

  }



  getLookUpsByLookUpName(lookUpName: any) {
    this.lookupService.geLookUpsByLookUpName(lookUpName).subscribe((data: LookUp[]) => {
      switch (lookUpName) {
        case LookUps.Gender:
          this.genders = data;
          break; //this.ngOnInit
        case LookUps.RelationCode:
          this.relationshipCodes = data;
          break;
        case LookUps.AORRelationShip:
          this.aorRelationShips = data;
          break;
        case LookUps.CommunicationPreference:
          this.communicationPreferences = data;
          break;
        case LookUps.LanguagePreference:
          this.languagePreferences = data;
          break;
        case LookUps.RelationCode:
          this.relationshipCodes = data;
          break;
        case LookUps.RepresentativeType:
          this.representativeTypes = data;
          break;
        case LookUps.RequestType:
          this.requestTypes = data;
          break;
        case LookUps.Source:
          this.sources = data;
          break;
        case LookUps.State:
          this.states = data;
          break;
        case LookUps.SubCategory:
          this.subCategories = data;
          break;
        case LookUps.BenefitDetermination:
          this.benefitDeterminations = data;
          break;
          case LookUps.Requestor:
            this.requestors = data;
            break;
        default:
          break;
      }
    })
  }

  canUserHasAssignPermission() {

    return this.sharedService.hasPermission(Permissions.AssignCaseWorker, this.userPermissions.result)

  }

  RedirectToParent() {
    this.router.navigate(['/case-management']);
  }


  displayFn(user: User): string {
    return user && user.name ? user.name : '';
  }

  showDueDate() {
    if (Number(this.addCaseDetailForm.get("statusId")?.value!) > 1)
      return true
    else
      return false
  }
  ngOnInit(): void {
    console.log(this.addCaseDetailForm.value)
    const token = localStorage.getItem('access_token');
    // decode the token to get its payload
    const tokenPayload: any = decode(token!);
    console.log(tokenPayload.UserId)
    let loggedInUserId = tokenPayload.UserId
    this.userPermissions = this.route.snapshot.data['userPermissions'];
    if (this.canUserHasAssignPermission()) {
      this.addValidators(['assigneeId'])
    }
    else {
      this.removeValidators(['assigneeId'])
    }


    if (this.readOnly) {
      this.caseService.getCaseDetailsById(this.caseDetailId)
        .subscribe({
          next:
            (response: any) => {
              // var data='{"memberInfo":{"firstName":"","middleName":"","lastName":"","dateOfBirth":"2023-01-31T23:37:39-05:00","gender":"","addressLine1":"","addressLine2":"","state":"","city":"","zip":"","homePhone":"","workPhone":"","fax":"","cellPhone":"","communicationPrefrence":"","email":"","languagePrefrence":""},"caseId":"","assigneeId":"","assigneeName":"","receivedTime":"23:37","statusId":"2","incidentDate":"2023-01-31T23:37:39-05:00","dueDate":"2023-01-31T23:37:39-05:00","receivedDate":"2023-01-31T23:37:39-05:00","method":"Oral","requestor":"","requestType":"","categoryId":"","subCategory":"","source":"","urgency":"Standard","highPriority":false,"extensionTaken":false,"partType":"","complianceCase":false,"goodCause":false,"description":"","isAor":false,"firstTier":"","createdDate":"2023-02-01T04:37:39.933Z","lastModifiedBy":null,"lastModifiedDate":null,"aorInfo":{"aorFirstName":null,"aorMiddleName":null,"aorLastName":null,"aorEmail":null,"memberSignatureDate":null,"apointeeSignatureDate":null,"aorCity":null,"aorAddressLine1":null,"aorAddressLine2":null,"aorPhone":null,"aorZip":null,"aorState":null,"aorRelationship":null,"formReceived":null,"aorFormReceivedDate":null,"aorFormReceivedTime":null},"customerId":"1","createdBy":"70"}'
              // response=JSON.parse(data)
              console.log("--------------->", response);
             

              response.draftCaseDetailId = 0
              response.receivedTime = moment(response.receivedDate).format("HH:mm")
              if (response.aorInfo != null && response.aorInfo.aorFormReceivedDate)
                response.aorInfo.aorFormReceivedTime = moment(response.aorInfo.aorFormReceivedDate).format("HH:mm")
              else
                response.aorInfo.aorFormReceivedTime = ''
              this.caseId = response.caseId ?? this.caseId
              var user = {
                userId: response.assigneeId,
                name: response.assigneeName
              }
              //  this.addCaseDetailForm.get("draftCaseDetailId")?.setValue(0)
              let dueDate = moment(response.dueDate)
              let totalDaysLeft = moment.duration(moment(new Date()).startOf('day').diff(dueDate.startOf('day'))).asDays()
              if (totalDaysLeft >= 0 || totalDaysLeft == -1) {
                this.alertDueDate = true
              }
              this.dueDate = moment(response.dueDate).format('MM/DD/yyyy hh:mm A')
              this.addCaseDetailForm.setValue(response);
              this.addCaseDetailForm.get("categoryId")?.patchValue(response.categoryId.toString())
              this.addCaseDetailForm.get("statusId")?.patchValue(response.statusId.toString())
              var control = this.addCaseDetailForm.get("assigneeId") as FormControl
              this.populateDueDate.emit({ dueDate: this.dueDate, dueDateAlert: this.alertDueDate })
              // this.sharedService.setOption("caseDueDate",this.dueDate)
              //this.sharedService.setOption("alertDueDate",this.alertDueDate)
              control.setValue(user);
              if (Number.parseInt(loggedInUserId) === response.assigneeId)
              {
                this.addCaseDetailForm.enable()
                this.showSubmit=true
                if(!response.isAor)
                this.addCaseDetailForm.controls.aorInfo.disable()
              }
              else
              {
                this.addCaseDetailForm.disable()
                this.showSubmit=false
              }
              this.addCaseDetailForm.get("statusId")?.disable()
            },
          // error: (e) => this.toastr.error("Something went wrong!")
        });
        this.memberAccordionExpanded=false
    }
    else {
      if (!this.isChecked) {
        let recDate = moment(new Date(this.addCaseDetailForm.get("receivedDate")?.value!))
        this.addCaseDetailForm.controls.aorInfo.reset()
        this.addCaseDetailForm.controls.aorInfo.disable()
      }
      this.addCaseDetailForm.get("statusId")?.patchValue("1")
      this.createDraftCase()
      this.getEligibilityMemberDetail(this.sharedService.getEligibilityMemberId())
      this.sharedService.clearOption("eligibilityMemberId")
    }

    var assigneeId = this.addCaseDetailForm.get("assigneeId") as FormControl;
    this.filteredOptions = assigneeId.valueChanges.pipe(
      startWith(''),
      map(value => {
        const name = typeof value === 'string' ? value : value?.name;
        return name ? this._filter(name as string) : this.users?.slice();
      }),
    );
    this.sharedService.clearOption("memberDetail")
  }

  getEligibilityMemberDetail(memberId: any) {
    if (memberId && memberId != null)
      this.caseService.getEligibilityMemberDetailById(memberId)
        .subscribe({
          next:
            (response: any) => {
              console.log(response)
              this.addCaseDetailForm.controls.memberInfo.patchValue(response.memberInfo)
              if (response.isAor==true && response.aorInfo.aorFormReceivedDate)
                response.aorInfo.aorFormReceivedTime = moment(response.aorInfo.aorFormReceivedDate).format("HH:mm")
              else
                response.aorInfo.aorFormReceivedTime = ''
              if (response.isAor==true) {
                this.isChecked = true
                this.addCaseDetailForm.get("isAor")?.patchValue(true)
                this.addCaseDetailForm.controls.aorInfo.patchValue(response.aorInfo)
                this.addCaseDetailForm.controls.aorInfo.enable()
              }
            }
        })
  }
  check: boolean = false;
  // myfunction() {
  //   if (this.check == false) {
  //     this.check = true;
  //   }
  //   else {
  //     this.check = false;
  //   }
  // }
  private _filter(name: string): User[] {
    const filterValue = name.toLowerCase();

    return this.users!.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  transformDate(date: any, timeControlName: any, controlName: AbstractControl) {
    const d = new Date(date);
    let time = this.addCaseDetailForm.get(timeControlName)?.value!;
    d.setHours(parseInt(time.split(':')[0]));
    d.setMinutes(parseInt(time.split(':')[1]));
    controlName?.patchValue(d);
  }
  get ReceivedDate() { return this.addCaseDetailForm.get('receivedDate'); }
  get AorFormReceivedDate() { return this.addCaseDetailForm.get('aorInfo.aorFormReceivedDate'); }
  showHideAOR() {
    this.isChecked = !this.isChecked;
    if (!this.isChecked) {
      this.removeValidators(['aorInfo.aorFirstName', 'aorInfo.aorLastName', 'aorInfo.aorCity', 'aorInfo.aorZip', 'aorInfo.aorState', 'aorInfo.aorRelationship', 'aorInfo.aorAddressLine1'])
      this.addCaseDetailForm.controls.aorInfo.reset()
      this.addCaseDetailForm.controls.aorInfo.disable()
    }
    else {
      this.addValidators(['aorInfo.aorFirstName', 'aorInfo.aorLastName', 'aorInfo.aorCity', 'aorInfo.aorZip', 'aorInfo.aorState', 'aorInfo.aorRelationship', 'aorInfo.aorAddressLine1'])

      this.addCaseDetailForm.controls.aorInfo.enable()
    }

  }
  addValidators(controls: string[]) {
    controls.forEach(c => {
      this.addCaseDetailForm.get(c)?.setValidators(Validators.required);
      this.addCaseDetailForm.get(c)?.updateValueAndValidity();
    });
  }

  removeValidators(controls: string[]) {
    controls.forEach(c => {
      this.addCaseDetailForm.get(c)?.clearValidators();
      this.addCaseDetailForm.get(c)?.updateValueAndValidity();
    });
  }
  urgencyChange(event: any) {
    if (event.value == 'Urgent') {

      this.disableExtension = true
      this.addCaseDetailForm.get("extensionTaken")?.setValue(false)
    }
    else
      this.disableExtension = false

    console.log(event.value);

  }
  createDraftCase() {
    var formData = this.addCaseDetailForm.getRawValue();
    this.caseDetailId = this.caseDetailId == "" ? 0 : this.caseDetailId
    this.addCaseDetailForm.get("draftCaseDetailId")?.setValue(this.caseDetailId)
    this.caseService.SaveCase(formData, this.caseDetailId)
      .subscribe({
        next:
          (response: any) => {
            if (response.errorContent.statusCode == "200") {
              this.caseDetailId = response.result
              //this.addCaseDetailForm.markAsPristine()
              // this.addCaseDetailForm.reset()
              // this.router.navigate(['/case-management']);
            }
          },
        error: (e) => this.toastr.error(e)
      });
  }
  saveCase() {
    var formData = this.addCaseDetailForm.getRawValue();
    this.caseDetailId = this.caseDetailId == "" ? 0 : this.caseDetailId
    this.addCaseDetailForm.get("draftCaseDetailId")?.setValue(this.caseDetailId)

    this.caseService.SaveCase(formData, this.caseDetailId)
      .subscribe({
        next:
          (response: any) => {
            if (response.errorContent.statusCode == "200") {
              this.toastr.success('Data saved successfully');
              this.caseDetailId = response.result
              this.showDiscard = true;
              this.addCaseDetailForm.markAsPristine()
              // this.addCaseDetailForm.reset()
              // this.router.navigate(['/case-management']);
            }
          },
        error: (e) => this.toastr.error(e)
      });
  }



  discardCase() {
    this.dialogService.confirm("Discard Draft Case", "Are you sure you want to Discard?", true).subscribe((res: boolean) => {
      if (res === true) {
        this.caseService.discardDraftCase(this.caseDetailId)
          .subscribe({
            next:
              (response: any) => {
                if (response.errorContent.statusCode == "200") {
                  this.toastr.success('Discard successfully');
                  this.showDiscard = false;
                  this.addCaseDetailForm.reset()
                  this.caseDetailId = ''
                  // window.location.reload()
                  this.router.navigate(['/member-management']);

                }
              },
            error: (e) => this.toastr.error(e)
          });
        return
      } else {
        return false;
      }
    });

  }

  submitCase() {
    //console.log((this.caseWorkerFormControl.value).userId)
    this.maxTime = moment(new Date(), "HH:mm")
    this.aorFormReceived = this.addCaseDetailForm.get('aorInfo.formReceived')?.value!

    if (this.aorFormReceived) {
      this.addValidators(['aorInfo.aorFormReceivedDate', 'aorInfo.memberSignatureDate', 'aorInfo.apointeeSignatureDate', 'aorInfo.aorFormReceivedTime'])
    }
    else {
      this.removeValidators(['aorInfo.aorFormReceivedDate', 'aorInfo.memberSignatureDate', 'aorInfo.apointeeSignatureDate', 'aorInfo.aorFormReceivedTime'])
    }

    if (this.AorFormReceivedDate && this.AorFormReceivedDate.value != null) {
      this.transformDate(this.addCaseDetailForm.get("aorInfo.aorFormReceivedDate")?.value!, "aorInfo.aorFormReceivedTime", this.AorFormReceivedDate)
    }

    if (!this.addCaseDetailForm.valid) {
      return;
    }

    if (this.maxTime.isBefore(moment(this.addCaseDetailForm.get("receivedTime")?.value!, "HH:mm")) && !this.readOnly) {
      this.dialogService.confirm("Received Date Time", "Received Date Time should be less than Current Date Time", false).subscribe((res: boolean) => {
        if (res === true) {
          const invalidControl = this.el.nativeElement.querySelector('[formcontrolname=receivedTime]');
          invalidControl.focus();
          return
        } else {
          return false;
        }
      });
    }
    else {
      this.createUpdateCase()
    }
  }

  private createUpdateCase() {
    if (this.addCaseDetailForm.get('assigneeId') && this.addCaseDetailForm.get('assigneeId')?.value != '') {

      let assigneeIdControl = this.addCaseDetailForm.get('assigneeId') as FormControl
      this.caseWorkedId = (assigneeIdControl.value).userId
    }
    else {
      this.addCaseDetailForm.get('assigneeId')?.setValue(localStorage.getItem("userId")!)
    }
    this.transformDate(this.addCaseDetailForm.get("receivedDate")?.value!, "receivedTime", this.ReceivedDate!)
    this.addCaseDetailForm.get("caseDetailId")?.setValue(this.caseDetailId)
    var formData = this.addCaseDetailForm.value;
    if (this.caseWorkedId && this.caseWorkedId != null)
      formData.assigneeId = this.caseWorkedId
    if (this.readOnly)
      this.updateCase(formData)
    else
      this.createCase(formData)
  }

  updateCase(formData: any) {
    this.caseService.UpdateCase(formData)
      .subscribe({
        next:
          (response: any) => {
            if (response.errorContent.statusCode == "200") {
              this.toastr.success('Case updated successfully');
              this.addCaseDetailForm.reset()
              this.router.navigate(['/case-management']);            
             
            }
          },
        error: (e) => this.toastr.error(e)
      });
  }

  createCase(formData: any) {
    this.caseService.SubmitCase(formData)
      .subscribe({
        next:
          (response: any) => {
            if (response.errorContent.statusCode == "200") {
              this.toastr.success('Data saved successfully');
              this.addCaseDetailForm.reset()
              this.router.navigate(['/case-management']);
            }
          },
        error: (e) => this.toastr.error(e)
      });
  }

  methodChange(event:any)
  {
    if(event.value=='Written')
    {
this.showSubCategory=true;
    }
    else
    this.showSubCategory=false
  }

}



