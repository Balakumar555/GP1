import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseExtensionComponent } from './case-extension.component';

describe('CaseExtensionComponent', () => {
  let component: CaseExtensionComponent;
  let fixture: ComponentFixture<CaseExtensionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CaseExtensionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CaseExtensionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
