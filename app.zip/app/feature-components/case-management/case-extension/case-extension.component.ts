import { Component, OnInit } from '@angular/core';
import { AbstractControl, ControlValueAccessor, FormBuilder, NG_VALUE_ACCESSOR, Validators } from '@angular/forms';
import { CaseService } from '../case.service';

@Component({
  selector: 'app-case-extension',
  templateUrl: './case-extension.component.html',
  styleUrls: ['./case-extension.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi:true,
      useExisting: CaseExtensionComponent
    }
  ]
})
export class CaseExtensionComponent implements OnInit,ControlValueAccessor {
expandCard:boolean=true;
  constructor(private caseService: CaseService, private fb: FormBuilder) { }
  public onTouched: () => void = () => {};
  writeValue(obj: any): void {
    obj && this.extensionInfo.patchValue(obj, { emitEvent: false });
    if(obj && obj.extensionReason!=null)
    this.expandCard=false
  }
  registerOnChange(fn: any): void {
    this.extensionInfo.valueChanges.subscribe(fn);
  }
  registerOnTouched(fn: any): void {
    this.onTouched=fn;
  }
  setDisabledState?(isDisabled: boolean): void {
    isDisabled ? this.extensionInfo.disable() : this.extensionInfo.enable();
  }
  extensionReasons:any
  extensionInfo = this.fb.group({
    extensionReason:[, [Validators.required]],
    extensionDescription:[, [Validators.required]],
    
  })
  ngOnInit(): void {
    this.getExtensionReasons()
  }

  getExtensionReasons()
  {
    this.caseService.getExtensionReason().subscribe(data => {
      this.extensionReasons = data
    })
  }
  get f(): { [key: string]: AbstractControl } {

    return this.extensionInfo.controls;

  }

}
