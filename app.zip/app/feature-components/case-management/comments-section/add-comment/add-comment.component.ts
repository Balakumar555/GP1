import { Component, ElementRef, EventEmitter, Inject, Input, OnInit, Optional, Output, ViewChild, ViewEncapsulation } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, MaxLengthValidator, Validators } from '@angular/forms';
import { UsersService } from 'src/app/Services/users.service';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';
import { map, Observable, of, startWith } from 'rxjs';
import { ModelDialogsService } from 'src/app/shared/model-dialog/model-dialog.service';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { Router } from '@angular/router';
import {MatDialog, MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import { inject } from '@angular/core/testing';
import * as moment from 'moment';
import { CaseService } from '../../case.service';
import { LookUp } from 'src/app/shared/model/LookUp';


@Component({
  selector: 'app-add-comment',
  templateUrl: './add-comment.component.html',
  styleUrls: ['./add-comment.component.css']
})
export class AddCommentComponent implements OnInit {

   addCommentForm = this.fb.group({
    comment: ['', [Validators.required, Validators.maxLength(2500)]],
    attachmentId: [0],
    caseId:['']
  });
  submitted = false;

postDescription: FormControl = new FormControl('');
input: FormControl = new FormControl('');
public _commentForm!: FormGroup;
caseAttachments!: any[];
attachmentId:number=0
@Output() addPost = new EventEmitter<string>();

  newPostName = '';

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogService: ModelDialogsService, 
              private el: ElementRef, 
              private fb: FormBuilder, 
              private router: Router, 
              private userService: UsersService, 
              private toastr: ToastrService,  
              private sharedService: SharedDataService,    
              public dialogRef: MatDialogRef<AddCommentComponent>,
              private caseService: CaseService
  ) { }


  ngOnInit(): void {
   
    if (this.data.caseId) {
      this.GetCaseAttachments(this.data.caseId)
      this.addCommentForm.get("caseId")?.patchValue(this.data.caseId)
     // this.input.patchValue(this.data.defaultValue);
    }
  }

  public trimFormValues(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach((key) => {
      if (formGroup.controls[key].value && (key != "attachmentId" && key != "caseId"))
        formGroup.controls[key].setValue(formGroup.controls[key].value.trim())
    });
  }

  onAddPost() {
console.log(this.addCommentForm.value)
  //  this.addCommentForm.markAllAsTouched()
 
 if (!this.addCommentForm.valid) {
   return;
 }
//  this.addComments.get("clientIds")?.setValue(clientIds.toString())
 this.trimFormValues(this.addCommentForm);    
 this.submitted = true;
 var formData = this.addCommentForm.value;
 this.attachmentId=this.addCommentForm.get("attachmentId")?.value! 
    
  if(this.attachmentId===0)
   formData.attachmentId=null  
 this.caseService.CreateComment(formData)
   .subscribe({
     next:
       (response: any) => {
         if (response.errorContent.statusCode == "200") {
           this.toastr.success('Data saved successfully');
            this.dialogRef.close(response.errorContent.statusCode);
         // this.dialogRef.closeAll();
         }
       },
     error: (e) => this.toastr.error(e.error.errorContent.message)
   });
}
// resetForm() {
//  this.addComments.reset();
// }
  // onAddPost(){
  //   if(isNaN(this.data.ID)){
  //     this._case.addComment(this._commentForm.value);
  //     this.dialogRef.closeAll();
  //   }else{
  //     this._case.editComment(this._commentForm.value);
  //     this.dialogRef.closeAll();
  //   }
  //     }


  onNoClick(): void {
    this.dialogRef.close();
  }

  GetCaseAttachments(caseId: any) {

    this.caseService.GetCaseAttachments(0,caseId).subscribe((data: LookUp[]) => {
      this.caseAttachments=data
    })
  
  }
  

}

