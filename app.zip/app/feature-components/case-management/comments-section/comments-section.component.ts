import { Component, Input, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { filter } from 'rxjs';
import { CaseService } from '../case.service';
import { AddCommentComponent } from './add-comment/add-comment.component';
import { AbstractControl, AbstractControlOptions, FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';
import { EditCommentComponent } from './edit-comment/edit-comment.component';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';
import { ModelDialogsService } from 'src/app/shared/model-dialog/model-dialog.service';

@Component({
  selector: 'app-comments-section',
  templateUrl: './comments-section.component.html',
  styleUrls: ['./comments-section.component.css']
})
export class CommentsSectionComponent implements OnInit {



  @Input() caseId: any
  @Input() enableComment: boolean=false
  comments: any=[]
  moment = moment;
  constructor(public dialog: MatDialog,
    public caseSerivce: CaseService,
    private dialogRef: MatDialog,
    private fb: FormBuilder,
    private caseService: CaseService,
    private toastr: ToastrService, 
    private dialogService: ModelDialogsService

  ) { }

  ngOnInit(): void {
    this.getCaseComments()
  }

  getCaseComments() {
    this.caseSerivce.getCaseCommentsByCaseId(this.caseId).subscribe(data => {
      this.comments = data;
    })
  }
  addNewComment() {
    const dialogRef = this.dialog.open(AddCommentComponent, {
      data: { caseId: this.caseId }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result == "200") {
        this.getCaseComments()
      }
    });
  }

  editComment(commentdetail:any)
  {
    
    const dialogRef = this.dialog.open(EditCommentComponent, {
      data: { commentDetail: commentdetail }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result == "200") {
        this.getCaseComments()
      }
    });
  }

  deleteComment(commentdetail:any)
  {
    this.dialogService.confirm("Delete Comment", "Are you sure you want to Delete?", true).subscribe((res: boolean) => {
      if (res === true) {
    commentdetail.commentId=commentdetail.caseCommentId
    this.caseService.UpdateComment(commentdetail,true)
    .subscribe({
      next:
        (response: any) => {
          if (response.errorContent.statusCode == "200") {
            this.toastr.success('Data saved successfully');
            this.getCaseComments()       
          }
        },
      error: (e) => this.toastr.error(e.error.errorContent.message)
    });
    return
  }
  else
  return false
  })
  }

}
