import { Component, ElementRef, Inject, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ModelDialogsService } from 'src/app/shared/model-dialog/model-dialog.service';
import { LookUp } from 'src/app/shared/model/LookUp';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';
import { CaseService } from '../../case.service';

@Component({
  selector: 'app-edit-comment',
  templateUrl: './edit-comment.component.html',
  styleUrls: ['./edit-comment.component.css']
})
export class EditCommentComponent implements OnInit {

  constructor( @Inject(MAT_DIALOG_DATA) public data: any,
  private dialogService: ModelDialogsService, 
            private el: ElementRef, 
            private fb: FormBuilder, 
            private router: Router,              
            private toastr: ToastrService,  
            private sharedService: SharedDataService,    
            public dialogRef: MatDialogRef<EditCommentComponent>,
            private caseService: CaseService) { }
            
  editCommentForm = this.fb.group({
    comment: ['', [Validators.required, Validators.maxLength(2500)]],
    attachmentId: ['0'],
    commentId:[]
  });
  caseAttachments!: any[];
  get f(): { [key: string]: AbstractControl } {

    return this.editCommentForm.controls;

  }
  ngOnInit(): void {
    this.GetCaseAttachments(this.data.commentDetail.caseDetailId)
this.bindCommentForm()
  }

  bindCommentForm() {

    if (this.data.commentDetail) {
      
     // this.editCommentForm.patchValue(this.data.commentDetail)
      this.editCommentForm.get("comment")?.patchValue(this.data.commentDetail.comment);
      this.editCommentForm.get("attachmentId")?.patchValue(this.data.commentDetail.caseAttachmentId ? this.data.commentDetail.caseAttachmentId.toString():0);  
      this.editCommentForm.get("commentId")?.patchValue(this.data.commentDetail.caseCommentId);
        
    }
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  GetCaseAttachments(caseId: any) {

    this.caseService.GetCaseAttachments(0,caseId).subscribe((data: LookUp[]) => {
      this.caseAttachments=data
    })
  
  }

  editComment()
  {
    if (!this.editCommentForm.valid) {
      return;
    } 
    let attachmentId=this.editCommentForm.get("attachmentId")?.value
   

    var formData = this.editCommentForm.value;  
    if(attachmentId?.toString()==='0')
    formData.attachmentId=null  
    this.caseService.UpdateComment(formData,false)
      .subscribe({
        next:
          (response: any) => {
            if (response.errorContent.statusCode == "200") {
              this.toastr.success('Data saved successfully');
               this.dialogRef.close(response.errorContent.statusCode);            
            }
          },
        error: (e) => this.toastr.error(e.error.errorContent.message)
      });
  }
}
