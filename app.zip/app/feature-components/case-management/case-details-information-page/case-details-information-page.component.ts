import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import * as moment from 'moment';

@Component({
  selector: 'app-case-details-information-page',
  templateUrl: './case-details-information-page.component.html',
  styleUrls: ['./case-details-information-page.component.css']
})
export class CaseDetailsInformationPageComponent implements OnInit {

  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
  }

  addCaseDetailForm = this.fb.group({
    memberInfo: this.fb.group({
      firstName: ['', [Validators.required]],
      middleName: [''],
      lastName: ['', [Validators.required]],
      dateOfBirth: [moment(new Date()).format(), [Validators.required]],
      gender: ['', [Validators.required]],
      addressLine1: ['', [Validators.required]],
      addressLine2: [''],
      state: ['', [Validators.required]],
      city: ['', [Validators.required]],
      zip: ['', [Validators.required, Validators.pattern('[0-9]{5}')]],
      homePhone: ['', [Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      workPhone: ['', [Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      fax: [''],
      cellPhone: ['', [Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      communicationPrefrence: [''],
      email: ['', [Validators.email, Validators.maxLength(50)]],
      languagePrefrence: [''],
      memberNumber: [''],
      mbi: [''],
      clientId: [1],
      planId: [1],
      clientName: [''],
      planName: ['']
    }),
    caseId: [''],
    assigneeId: [''],
    assigneeName: [''],
    receivedTime: ['', [Validators.required]],
    statusId: ['', [Validators.required]],
    incidentDate: [moment(new Date()).format(), [Validators.required]],
    dueDate: [moment(new Date()).format(), [Validators.required]],
    receivedDate: [moment(new Date()).format(), [Validators.required]],
    method: ['', [Validators.required]],
    requestor: ['', [Validators.required]],
    requestType: ['', [Validators.required]],
    categoryId: ['', [Validators.required]],
    subCategory: [''],
    source: [''],
    urgency: ['', [Validators.required]],
    highPriority: [false],
    extensionTaken: [false],
    partType: ['', [Validators.required]],
    complianceCase: [false],
    goodCause: [false],
    description: ['', [Validators.required, Validators.maxLength(2000)]],
    isAor: [false],
    firstTier: [''],
    createdDate: [new Date()],
    lastModifiedBy: [],
    lastModifiedDate: [],
    aorInfo: this.fb.group({
      aorFirstName: [''],
      aorMiddleName: [''],
      aorLastName: [''],
      aorEmail: ['', [Validators.email, Validators.maxLength(50)]],
      memberSignatureDate: [moment(new Date()).format()],
      apointeeSignatureDate: [moment(new Date()).format()],
      aorCity: [''],
      aorAddressLine1: [''],
      aorAddressLine2: [''],
      aorPhone: ['', [Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      aorZip: ['', [Validators.pattern('[0-9]{5}')]],
      aorState: [''],
      aorRelationship: [''],
      formReceived: [false],
      aorFormReceivedDate: [moment(new Date()).format()],
      aorFormReceivedTime: ['']

    }),
    customerId: localStorage.getItem("customerId")!,
    createdBy: localStorage.getItem("userId")!,
    draftCaseDetailId: [0],
    caseDetailId: [0]
  })
}
