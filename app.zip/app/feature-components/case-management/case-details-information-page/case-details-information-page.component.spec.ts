import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseDetailsInformationPageComponent } from './case-details-information-page.component';

describe('CaseDetailsInformationPageComponent', () => {
  let component: CaseDetailsInformationPageComponent;
  let fixture: ComponentFixture<CaseDetailsInformationPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CaseDetailsInformationPageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CaseDetailsInformationPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
