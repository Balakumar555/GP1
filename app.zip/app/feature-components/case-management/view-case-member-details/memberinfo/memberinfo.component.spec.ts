import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MemberinfComponent } from './memberinfo.component';

describe('MemberinfComponent', () => {
  let component: MemberinfComponent;
  let fixture: ComponentFixture<MemberinfComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MemberinfComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MemberinfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
