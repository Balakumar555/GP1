import { Component, Input, OnInit } from '@angular/core';
import { MemberSummary } from 'src/app/shared/model/caseDetail';

@Component({
  selector: 'app-memberinfo',
  templateUrl: './memberinfo.component.html',
  styleUrls: ['./memberinfo.component.css']
})
export class MemberinfComponent implements OnInit {
  @Input() memberSummaryData!:MemberSummary
 
  

  constructor() { }

  ngOnInit(): void {
  }

}
