import { Component, Input, OnInit } from '@angular/core';
import { AORSummary } from 'src/app/shared/model/caseDetail';

@Component({
  selector: 'app-member-rep-info',
  templateUrl: './member-rep-info.component.html',
  styleUrls: ['./member-rep-info.component.css']
})
export class MemberRepInfoComponent implements OnInit {
  @Input() memberAORSummaryData!:AORSummary 


  constructor() { }

  ngOnInit(): void {
  }

}
