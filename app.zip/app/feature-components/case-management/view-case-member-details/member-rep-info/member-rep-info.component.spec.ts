import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MemberRepInfoComponent } from './member-rep-info.component';

describe('MemberRepInfoComponent', () => {
  let component: MemberRepInfoComponent;
  let fixture: ComponentFixture<MemberRepInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MemberRepInfoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MemberRepInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
