import { Component, Input, OnInit, Pipe, PipeTransform } from '@angular/core';
import { CaseSummary } from 'src/app/shared/model/caseDetail';
import { ShortenPipe } from 'src/app/shared/shorten.pipe';

@Component({
  selector: 'app-case-summary',
  templateUrl: './case-summary.component.html',
  styleUrls: ['./case-summary.component.css']
})

export class CaseSummaryComponent implements OnInit {

  showTxt="Show More"
counter = 100;
description:any
showReadMore:boolean=true;
@Input() caseSummaryData!:CaseSummary
  constructor() {
   

   }

  ngOnInit(): void {
    // if (this.caseSummaryData && this.caseSummaryData.description && this.caseSummaryData.description.length>100)
    // this.showReadMore=true
  }  

  isReadMore = true
hideText = true
showTextDes = false
  showText() {
     this.isReadMore = !this.isReadMore;
     this.hideText =! this.hideText;
     this.showTextDes = !this.showTextDes;
  }

}
