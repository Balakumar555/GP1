import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditCaseAORDetailsComponent } from './edit-case-aor-details.component';

describe('EditCaseMemberDetailsComponent', () => {
  let component: EditCaseAORDetailsComponent;
  let fixture: ComponentFixture<EditCaseAORDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditCaseAORDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditCaseAORDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
