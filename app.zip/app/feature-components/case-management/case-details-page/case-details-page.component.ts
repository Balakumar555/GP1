import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, NgModel } from '@angular/forms';
import { ActivatedRoute, Params, Router, Routes } from '@angular/router';
import { state, style, transition, trigger, animate } from "@angular/animations";
import { User } from 'src/app/shared/model/user';
import { map, Observable, startWith } from 'rxjs';
import { AddCaseDetailsComponent } from '../add-case-details/add-case-details.component';
import * as moment from 'moment';
import decode from 'jwt-decode';
import { CaseService } from '../case.service';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { Permissions } from 'src/app/shared/constants/permissions';
import { AORSummary, CaseStatus, CaseSummary, MemberSummary } from 'src/app/shared/model/caseDetail';
import { UsersService } from 'src/app/Services/users.service';
import { Roles } from 'src/app/shared/constants/role';
import { caseStatus } from 'src/app/shared/constants/caseStatus';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';
import { MatSelectChange } from '@angular/material/select';
@Component({
  selector: 'app-case-details-page',
  templateUrl: './case-details-page.component.html',
  styleUrls: ['./case-details-page.component.css'],
  animations: [
    trigger('activeToggle', [
      state('openToggle', style({
        transform: 'rotate(0deg)'
      })),
      state('closeToggle', style({
        transform: 'rotate(180deg)'
      })),
      transition('openToggle => closeToggle', animate(300)),
      transition('closeToggle => openToggle', animate(400))

    ]),
  ]
})


export class CaseDetailsPageComponent implements OnInit {
  expandIconMemberInfo = true;
  minimizeIconMemberInfo = false;
  expandIconCaseSummary = true;
  minimizeIconCaseSummary = false;
  showCaseSummary: boolean = true;
  showMemberSummary: boolean = true;
  showAORSummary: boolean = true;
  showEditCase: boolean = false;
  showEditmember: boolean = false;
  showEditAOR: boolean = false;
  showEditPOA: boolean = false;
  expandToggle = false;
  check: boolean = true;
  hide: boolean = false;
  coltwo: boolean = false;
  hidetwo: boolean = true;
  state: string = 'default';
  status: 'open' | 'closed' = 'closed';
  stateToggle = 'openToggle'
  caseToggle = 'openToggle'
  Toggle = 'open'
  users!: User[]
  showVerbal: boolean = false
  showNotificationComponent: boolean = false
  filteredOptions!: Observable<User[]>;
  expandCS: boolean = false;
  expandMI: boolean = false;
  expandAOR: boolean = false;
  alertDueDate: boolean = false
  showDueDate: boolean = false
  caseSummaryData: CaseSummary = {} as any
  memberSummaryData: MemberSummary = {} as any
  aorSummaryData: AORSummary = {} as any
  caseSummaryLoad: boolean = false
  dueDate!: any
  caseId: any;
  userPermissions: any = {};
  isAor: boolean = false
  caseStatus!: any[];
  showNeedMoreInformation: boolean = false;
  showNMIResolution: boolean = false;
  showTakeExtension: boolean = false;
  expandNMI: boolean = false;
  expandNMIResolution: boolean = false;
  extensionTake:boolean=false;
  nmiAvailable:boolean=false;
  enableEdit:boolean=true;



  constructor(private router: Router, private fb: FormBuilder, protected route: ActivatedRoute, private userService: UsersService, private caseService: CaseService, private sharedService: SharedDataService, private toastr: ToastrService) {
    this.route.params.subscribe((params: Params) => {
      this.caseId = params['id'] || ''
    })
    this.userService.getUsersByRole(Roles.CaseWorker).subscribe(data => {     
      this.users = data
    })

    this.caseService.getAllActions(this.caseId).subscribe((data: CaseStatus[]) => {
      this.caseStatus = data;
    });
  }

  showEditableCase() {
    this.showCaseSummary = false
    this.showEditCase = true;
  }

  showEditableMember() {
    this.showMemberSummary = false
    this.showEditmember = true;
  }
  showEditableAOR() {
    this.showAORSummary = false;
    this.showEditAOR = true;
  }
  showEditablePOA() {
    this.showMemberSummary = false
    this.showEditPOA = true;
  }
  showSummary() {
    this.showCaseSummary = true
    this.showEditCase = false;
  }
  showMemberDetail() {
    this.showMemberSummary = true
    this.showEditmember = false;
  }
  showAORDetail() {
    this.showAORSummary = true;
    this.showEditAOR = false;
  }
  caseReviewForm = this.fb.group({
    caseInfo: [""],
    memberInfo: [""],
    aorInfo: [""],
    poaInfo: [""],
    assigneeId: [""],
    statusId: [""],
    caseDetailId: [],
    nmiInfo: [""],
    nmiOutcome: [""],
    extensionInfo: [""]
  })
  ngOnInit(): void {
    const token = localStorage.getItem('access_token');
    // decode the token to get its payload
    const tokenPayload: any = decode(token!);
    console.log(tokenPayload.UserId)
    let loggedInUserId = tokenPayload.UserId
    this.getCaseDetails(loggedInUserId)
    this.userPermissions = this.route.snapshot.data['userPermissions'];
    
    var assigneeId = this.caseReviewForm.get("assigneeId") as FormControl;
    this.filteredOptions = assigneeId.valueChanges.pipe(
      startWith(''),
      map(value => {
        const name = typeof value === 'string' ? value : value?.name;
        return name ? this._filter(name as string) : this.users?.slice();
      }),
    );
  }
  private _filter(name: string): User[] {
    const filterValue = name.toLowerCase();

    return this.users!.filter(option => option.name.toLowerCase().includes(filterValue));
  }
  canUserHasAssignPermission() {

    return this.sharedService.hasPermission(Permissions.AssignCaseWorker, this.userPermissions.result)

  }
  getCaseDetails(loggedInUserId: any) {
    this.caseService.getCaseDetailsById(this.caseId)
      .subscribe({
        next:
          (response: any) => {
            // var data='{"memberInfo":{"firstName":"","middleName":"","lastName":"","dateOfBirth":"2023-01-31T23:37:39-05:00","gender":"","addressLine1":"","addressLine2":"","state":"","city":"","zip":"","homePhone":"","workPhone":"","fax":"","cellPhone":"","communicationPrefrence":"","email":"","languagePrefrence":""},"caseId":"","assigneeId":"","assigneeName":"","receivedTime":"23:37","statusId":"2","incidentDate":"2023-01-31T23:37:39-05:00","dueDate":"2023-01-31T23:37:39-05:00","receivedDate":"2023-01-31T23:37:39-05:00","method":"Oral","requestor":"","requestType":"","categoryId":"","subCategory":"","source":"","urgency":"Standard","highPriority":false,"extensionTaken":false,"partType":"","complianceCase":false,"goodCause":false,"description":"","isAor":false,"firstTier":"","createdDate":"2023-02-01T04:37:39.933Z","lastModifiedBy":null,"lastModifiedDate":null,"aorInfo":{"aorFirstName":null,"aorMiddleName":null,"aorLastName":null,"aorEmail":null,"memberSignatureDate":null,"apointeeSignatureDate":null,"aorCity":null,"aorAddressLine1":null,"aorAddressLine2":null,"aorPhone":null,"aorZip":null,"aorState":null,"aorRelationship":null,"formReceived":null,"aorFormReceivedDate":null,"aorFormReceivedTime":null},"customerId":"1","createdBy":"70"}'
            // response=JSON.parse(data)

            console.log("--------------->", response);
            this.isAor = response.isAor
            response.draftCaseDetailId = 0
            // response.caseInfo.preferredContact=95
            response.receivedTime = moment(response.receivedDate).format("HH:mm")
            this.setCaseSummary(response)
            this.setMemberSummary(response.memberInfo)
            response.caseInfo.receivedTime = response.receivedTime
            response.caseInfo.draftCaseDetailId = response.draftCaseDetailId = 0
            if (this.isAor && response.aorInfo != null && response.aorInfo.aorFormReceivedDate) {
              response.aorInfo.aorFormReceivedTime = moment(response.aorInfo.aorFormReceivedDate).format("HH:mm")
              this.setAORSummary(response.aorInfo)
            }
            else
              response.aorInfo.aorFormReceivedTime = ''
            this.caseId = response.caseId ?? this.caseId
            var user = {
              userId: response.assigneeId,
              name: response.assigneeName
            }
            //  this.caseDetailForm.get("draftCaseDetailId")?.setValue(0)
            let dueDate = moment(response.dueDate)
            let totalDaysLeft = moment.duration(moment(new Date()).startOf('day').diff(dueDate.startOf('day'))).asDays()
            if (totalDaysLeft >= 0 || totalDaysLeft == -1) {
              this.alertDueDate = true
            }
            this.dueDate = moment(response.dueDate).format('MM/DD/yyyy HH:mm')
            this.caseReviewForm.patchValue(response)
            // this.caseReviewForm.get("caseInfo")!.patchValue(response.caseInfo);
            // this.caseReviewForm.get("memberInfo")!.patchValue(response.memberInfo);
            // this.caseReviewForm.get("aorInfo")!.patchValue(response.aorInfo);

            this.caseReviewForm.get("caseInfo")?.get("categoryId")?.patchValue(response.categoryId.toString())
            this.caseReviewForm.get("caseInfo")?.get("statusId")?.patchValue(response.statusId.toString())
            var assigneeControl = this.caseReviewForm.get("assigneeId") as FormControl
            this.sharedService.setOption("caseDueDate", this.dueDate)
            this.sharedService.setOption("alertDueDate", this.alertDueDate)
            assigneeControl.setValue(user);
            this.caseReviewForm.get("statusId")?.patchValue(response.statusId.toString())
            this.caseReviewForm.get("caseDetailId")?.patchValue(response.caseDetailId)

            if (Number.parseInt(loggedInUserId) === response.assigneeId)
              this.caseReviewForm.enable()
            else
            {
              this.caseReviewForm.disable()
              this.enableEdit=false
            }

            this.caseReviewForm.get("assigneeId")?.disable()
            if (response.statusId == caseStatus.NeedMoreInformation) {
              this.showNeedMoreInformation = true
              this.nmiAvailable=true
              this.caseReviewForm.get("nmiInfo")?.disable()
            }
            else
              this.showNeedMoreInformation = false
              if(response.caseInfo.extensionTaken==true)
              {
              this.showTakeExtension=true
              this.extensionTake=true
              this.caseReviewForm.get("extensionInfo")?.disable()
              }
          },
        // error: (e) => this.toastr.error("Something went wrong!")
      });
  }
  saveInfo() {
    console.log(this.caseReviewForm.value)
    this.caseReviewForm.markAllAsTouched()
    if (!this.caseReviewForm.valid) {
      return;
    }
    var formData = this.caseReviewForm.value;
    this.updateCase(formData)
  }



  updateCase(formData: any) {
    this.caseService.UpdateCase(formData)
      .subscribe({
        next:
          (response: any) => {
            if (response.errorContent.statusCode == "200") {
              this.toastr.success('Case updated successfully');
              window.location.reload();
              // this.router.routeReuseStrategy.shouldReuseRoute = function () {
              //   return false;
              // };
              //this.router.navigate(['/case-management']);            

            }
          },
        error: (e) => this.toastr.error(e)
      });
  }

  displayFn(user: User): string {
    return user && user.name ? user.name : '';
  }

  setDueDate(event: any) {
    this.dueDate = event.dueDate
    this.alertDueDate = event.dueDateAlert
    this.showDueDate = true
  }

  expandIcon = true;
  minimizeIcon = false;
  expandCard() {
    if (this.expandCS == true) { this.expandCS = false; }
    else { this.expandCS = true; }
    this.expandIconCaseSummary = !this.expandIconCaseSummary;
    this.minimizeIconCaseSummary = !this.minimizeIconCaseSummary;
  }
  expandMemberInfo() {
    if (this.expandMI == true) { this.expandMI = false; }
    else { this.expandMI = true; }
    this.expandIconMemberInfo = !this.expandIconMemberInfo;
    this.minimizeIconMemberInfo = !this.minimizeIconMemberInfo;
  }
  expandAORInfo() {
    if (this.expandAOR == true) { this.expandAOR = false; }
    else { this.expandAOR = true; }
    this.expandIconMemberInfo = !this.expandIconMemberInfo;
    this.minimizeIconMemberInfo = !this.minimizeIconMemberInfo;
  }
  expandCollapsedNotification() {
    this.stateToggle == 'openToggle' ? this.stateToggle = 'closeToggle' : this.stateToggle = 'openToggle';
    if (this.coltwo == false) {
      this.coltwo = true;
    }
    else {
      this.coltwo = false;

    }
    if (this.hidetwo == false) {
      this.hidetwo = true;
      this.status = 'closed';
      this.hide = false
      this.check = true
    }
    else {
      this.hidetwo = false;
    }

  }

  showVerbalNotification() {
    this.showVerbal = true
    this.showNotificationComponent = true
  }

  showNotification() {
    this.showNotificationComponent = false
    this.showVerbal = false
  }

  expandCollapsedCaseInfo() {
    this.caseToggle == 'openToggle' ? this.caseToggle = 'closeToggle' : this.caseToggle = 'openToggle';

    if (this.status === 'open') {
      this.status = 'closed';
    } else {
      this.status = 'open';
      this.coltwo = true
      this.hidetwo = false
    }

    if (this.hide == false) {
      this.hide = true;
    }
    else {
      this.hide = false;
    }


    if (this.check == true) {
      this.check = false;
    }
    else {
      this.check = true;
    }
  }
  setCaseSummary(caseData: any) {
    this.caseSummaryData.categoryName = caseData.categoryName
    this.caseSummaryData.method = caseData.method
    this.caseSummaryData.planName = caseData.planName
    this.caseSummaryData.receivedDate = moment(caseData.receivedDate).format('MM/DD/yyyy')
    this.caseSummaryData.requestType = caseData.requestType
    this.caseSummaryData.requestor = caseData.requestor
    this.caseSummaryData.receivedTime = caseData.receivedTime
    this.caseSummaryData.description = caseData.description
    this.caseSummaryData.status = caseData.status
    this.caseSummaryData.urgency = caseData.urgency

  }
  setMemberSummary(member: any) {
    this.memberSummaryData.mbi = member.mbi
    this.memberSummaryData.memberId = member.memberNumber
    this.memberSummaryData.member = member.firstName + ' ' + member.lastName
    this.memberSummaryData.dob = moment(member.dateOfBirth).format('MM/DD/yyyy')
    this.memberSummaryData.city = member.city
    this.memberSummaryData.state = member.stateName
    this.memberSummaryData.address = member.addressLine1 + " "+member.addressLine2
    this.memberSummaryData.planType = member.planType
    this.memberSummaryData.phone = member.cellPhone
    this.memberSummaryData.homePhone = member.homePhone
    this.memberSummaryData.workPhone = member.workPhone

  }
  setAORSummary(aor: any) {

    this.aorSummaryData.aorName = aor.aorFirstName + ' ' + aor.aorLastName
    this.aorSummaryData.city = aor.aorCity
    this.aorSummaryData.state = aor.aorStateName
    this.aorSummaryData.address = aor.aorAddressLine1 + ' ' + aor.aorAddressLine2
    // this.aorSummaryData.communicationPrefrence=aor.communicationPrefrence
    this.aorSummaryData.email = aor.aorEmail
    this.aorSummaryData.phone = aor.aorPhone
  }

  actionChange(event: MatSelectChange) {
    if (event.source.triggerValue === 'Need More Information') {
      this.showNeedMoreInformation = true;
      this.caseReviewForm.get("nmiInfo")?.reset()
    }
    else {
      this.showNeedMoreInformation = false;
    }
    if (event.source.triggerValue === 'Resolve NMI')
      this.showNMIResolution = true
    else
      this.showNMIResolution = false
    if (event.source.triggerValue === 'Take Extension')
      this.showTakeExtension = true
    else
      this.showTakeExtension = false


  }

}


