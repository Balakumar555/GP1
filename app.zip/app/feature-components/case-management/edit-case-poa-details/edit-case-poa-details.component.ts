import { Component, ElementRef, Input, OnInit } from '@angular/core';
import { AbstractControl, ControlValueAccessor, FormBuilder, FormControl, FormGroup, NG_VALUE_ACCESSOR, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
//import { ToastrService } from 'ngx-toastr';
import { map, Observable, startWith } from 'rxjs';
import { UsersService } from 'src/app/Services/users.service';
import { ModelDialogsService } from 'src/app/shared/model-dialog/model-dialog.service';
import { User } from 'src/app/shared/model/user';
import { LookUpService } from 'src/app/shared/services/LookUp.service';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { CaseService } from '../case.service';
import decode from 'jwt-decode';
import { LookUp } from 'src/app/shared/model/LookUp';
import { LookUps } from 'src/app/shared/constants/lookUp';
import { CaseStatus, Category } from 'src/app/shared/model/caseDetail';


@Component({
  selector: 'app-edit-case-poa-details',
  templateUrl: './edit-case-poa-details.component.html',
  styleUrls: ['./edit-case-poa-details.component.css'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      multi:true,
      useExisting: EditCasePOADetailsComponent
    }
  ]
})
export class EditCasePOADetailsComponent implements OnInit,ControlValueAccessor {
  panelOpenState = false;
  checked = false;
  isChecked = false;
  indeterminate = false;
  labelPosition: 'before' | 'after' = 'after';
  disabled = false;
  maxDescriptionChar = 2000;
  dueDate = moment(new Date()).format('MM/DD/yyyy');
  caseId: any = '00000X'
  public defaultTime = [new Date().getHours(), new Date().getMinutes()]
  aorFormReceived: any;
  caseDetail: any | undefined
  users!: User[]
  filteredOptions!: Observable<User[]>;
  userPermissions: any = {};
  assignee: User | undefined;
  showDiscard = false;
  caseStatusId:any;
  aorRelationShips!: any[];
  caseStatus!: any[];
  genders!: any[];
  categories!: any[];
  subCategories!: any[];
  benefitDeterminations!: any[];
  sources!: any[];
  communicationPreferences  !: any[];
  languagePreferences!: any[];
  relationshipCodes!: any[];
  representativeTypes!: any[];
  requestTypes!: any[];
  states!: any[];
  //@Input() parentFormGroup!:FormGroup

  poaDetailForm = this.fb.group({   
    aorFirstName: [''],
    aorMiddleName: [''],
    aorLastName: [''],
    aorEmail: ['', [Validators.email, Validators.maxLength(50)]],
    memberSignatureDate: [moment(new Date()).format()],
    apointeeSignatureDate: [moment(new Date()).format()],
    aorCity: [''],
    aorAddressLine1: [''],
    aorAddressLine2: [''],
    aorPhone: ['', [Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
    aorZip: ['', [Validators.pattern('[0-9]{5}')]],
    aorState: [''],
    aorRelationship: [''],
    formReceived: [false],
    aorFormReceivedDate: [moment(new Date()).format()],
    aorFormReceivedTime: ['']
  })

  caseWorker = new FormControl();
  readOnly: boolean = false;
  caseDetailId: any;
  caseWorkedId: any = null;
  customerId = localStorage.getItem("customerId")!
  maxDate = moment(new Date()).format()
  maxTime = moment(new Date(), "HH:mm")
  disableExtension: boolean = false
  alertDueDate: boolean = false
  constructor(
               private dialogService: ModelDialogsService, 
               private el: ElementRef,
               private fb: FormBuilder, 
               private router: Router, 
               private caseService: CaseService,
               private userService: UsersService, 
             //  private toastr: ToastrService, 
               protected route: ActivatedRoute,
               private sharedService: SharedDataService, 
               private lookupService: LookUpService) {
                this.getLookUpsByLookUpName(LookUps.AORRelationShip, this.customerId);
                this.getLookUpsByLookUpName(LookUps.Gender, this.customerId);
              //  this.getLookUpsByLookUpName(LookUps.SubCategory, this.customerId);
              //  this.getLookUpsByLookUpName(LookUps.Source, this.customerId);
                this.getLookUpsByLookUpName(LookUps.LanguagePreference, this.customerId);
                this.getLookUpsByLookUpName(LookUps.CommunicationPreference, this.customerId);
                this.getLookUpsByLookUpName(LookUps.RelationCode, this.customerId);
                this.getLookUpsByLookUpName(LookUps.RepresentativeType, this.customerId);
                //this.getLookUpsByLookUpName(LookUps.RequestType, this.customerId);
                this.getLookUpsByLookUpName(LookUps.State, this.customerId);
                //this.getLookUpsByLookUpName(LookUps.BenefitDetermination, this.customerId);
            
            
            
              
                }
                public onTouched: () => void = () => {};
                writeValue(obj: any): void {
                  obj && this.poaDetailForm.setValue(obj, { emitEvent: false });
                }
                registerOnChange(fn: any): void {
                  this.poaDetailForm.valueChanges.subscribe(fn);
                }
                registerOnTouched(fn: any): void {
                  this.onTouched=fn;
                }
                setDisabledState?(isDisabled: boolean): void {
                  isDisabled ? this.poaDetailForm.disable() : this.poaDetailForm.enable();
                }

  ngOnInit(): void { 
   // this.parentFormGroup.addControl("memberInfoForm",this.memberInfoForm)
  }

  getLookUpsByLookUpName(lookUpName: any, customerId: any) {
    this.lookupService.geLookUpsByLookUpName(lookUpName).subscribe((data: LookUp[]) => {
      switch (lookUpName) {
        case LookUps.Gender:
          this.genders = data;
          break; //this.ngOnInit
        case LookUps.RelationCode:
          this.relationshipCodes = data;
          break;
        case LookUps.AORRelationShip:
          this.aorRelationShips = data;
          break;
        case LookUps.CommunicationPreference:
          this.communicationPreferences = data;
          break;
        case LookUps.LanguagePreference:
          this.languagePreferences = data;
          break;
        case LookUps.RelationCode:
          this.relationshipCodes = data;
          break;
        case LookUps.RepresentativeType:
          this.representativeTypes = data;
          break;
        case LookUps.RequestType:
          this.requestTypes = data;
          break;
        case LookUps.Source:
          this.sources = data;
          break;
        case LookUps.State:
          this.states = data;
          break;
        case LookUps.SubCategory:
          this.subCategories = data;
          break;
        case LookUps.BenefitDetermination:
          this.benefitDeterminations = data;
          break;
        default:
          break;
      }
    })
  }

  getCaseMemberDetail(memberId:any)
  {
    if(memberId && memberId !=null)
    this.caseService.getEligibilityMemberDetailById(memberId)
        .subscribe({
          next:
            (response: any) => {
              console.log(response)
              this.poaDetailForm.patchValue(response.memberInfoForm)              
            }
        })
  }
  check: boolean = false;

}
