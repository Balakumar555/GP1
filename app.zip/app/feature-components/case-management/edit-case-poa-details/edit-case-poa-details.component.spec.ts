import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditCasePOADetailsComponent } from './edit-case-poa-details.component';

describe('EditCaseMemberDetailsComponent', () => {
  let component: EditCasePOADetailsComponent;
  let fixture: ComponentFixture<EditCasePOADetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditCasePOADetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditCasePOADetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
