import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VerbalNotificationComponent } from './verbal-notification.component';

describe('VerbalNotificationComponent', () => {
  let component: VerbalNotificationComponent;
  let fixture: ComponentFixture<VerbalNotificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VerbalNotificationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VerbalNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
