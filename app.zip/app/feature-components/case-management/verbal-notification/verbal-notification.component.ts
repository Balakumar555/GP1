import { Component, ElementRef, EventEmitter, Inject, OnInit, Output, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, Validators } from '@angular/forms';
//import { ResizeEvent } from 'angular-resizable-element';
import { CaseService } from '../case.service';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { UsersService } from 'src/app/Services/users.service';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';


@Component({
  selector: 'app-verbal-notification',
  templateUrl: './verbal-notification.component.html',
  styleUrls: ['./verbal-notification.component.css']
})
export class VerbalNotificationComponent implements OnInit {
  


  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private caseService: CaseService,
    private verbalNotForm:FormBuilder,
    private sharedService: SharedDataService,    
    ) {}


  verbalNoti = this.verbalNotForm.group({
    receivedDate1:['' ],
    outReach:[''],
    recipent:[''],
    outReachStatus:[''],
    spokeTo:[''],
    messageDetail:[''],
    })
    submitted = false;

    postDescription: FormControl = new FormControl('');
      input: FormControl = new FormControl('');

    receivedDate1:any;
    outReach:any;
  ngOnInit() {
    if (this.data.defaultValue) {
      this.input.patchValue(this.data.defaultValue);
    }
  }
  onAddNewLog(){
    console.log(this.verbalNoti.value);
this.receivedDate1 = this.receivedDate1.value;
this.outReach = this.outReach.value;
return true;
  }

  // OnSaveNote(value: string) {
  //   this.newItemEvent.emit(value);
  // }
//   addNewItem(value: string, ) {
//     this.newItemEvent.emit(value);
//  }

}