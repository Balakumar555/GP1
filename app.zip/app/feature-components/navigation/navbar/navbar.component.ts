import { Component, OnInit,  ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from 'src/app/Services/auth.service';
import { trigger,state,style,animate, transition } from '@angular/animations';


@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
  animations:[
    trigger('openSetup', [
      state(  'open',style({  backgroundColor:'red', opacity:'1'})),
      state('closed',style({backgroundColor:'green', opacity:'0',})
      ),
      transition('open => closed', animate("1000ms")),
      transition('closed => open', animate(400))
      // transition('* => open', [animate('.5s', style({ opacity: '*' }))]),
    ]), 
    [
      // Each unique animation requires its own trigger. The first argument of the trigger function is the name
      trigger('rotatedState', [
        state('default', style({ transform: 'rotate(0)' })),
        state('rotated', style({ transform: 'rotate(-180deg)' })),
        transition('rotated => default', animate('1500ms ease-out')),
        transition('default => rotated', animate('400ms ease-in'))
    ])
]
  ],


  encapsulation: ViewEncapsulation.None

})
export class NavbarComponent implements OnInit {
  [x: string]: any;
isUserLoggedIn : Observable<boolean> | undefined;
showme: string | undefined;
width: string = ''
visible:boolean =false
iconup:boolean =false
icondown:boolean =true
iconupSupport:boolean =false
icondownSupport:boolean =true
visibleSupport:boolean =false
stateToggle = 'open'
state: string = 'default';


  constructor( public router :Router, private authService: AuthService) { }
name:string="";
  ngOnInit(): void {
    this.isUserLoggedIn = this.authService.isLoggedIn();
  this.name = localStorage.getItem('fName')! +' ' +  localStorage.getItem('lName')
  }

  logout(){
    this.authService.logout();
    this.router.navigate(['/login']);
  }
  rotate() {
    this.state = (this.state === 'default' ? 'rotated' : 'default');
}
 
getName(){
  alert("hello")
}

onClick(){
  this.stateToggle == 'open' ? this.stateToggle = 'closed' : this.stateToggle = 'open';
  this.visible =!this.visible
  this.iconup = !this.iconup
  this.icondown = !this.icondown
}

onClickSupport(){
  this.visibleSupport =!this.visibleSupport
  this.iconupSupport = !this.iconupSupport
  this.icondownSupport = !this.icondownSupport
}

mouseout(){
  this.visibleSupport = false;
  this.visible = false;
  this.iconup = false;
  this.icondown = true;
  this.icondownSupport = true;
  this.iconupSupport =false;

}
}