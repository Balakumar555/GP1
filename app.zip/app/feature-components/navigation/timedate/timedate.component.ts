import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timedate',
  templateUrl: './timedate.component.html',
  styleUrls: ['./timedate.component.css']
})
export class TimedateComponent implements OnInit {
  date: number = Date.now();

  constructor() { }

  ngOnInit(): void {
  }

}
