import { Component, OnInit } from '@angular/core';
import { LOCALE_ID, NgModule } from '@angular/core';


@Component({
  selector: 'app-sub-header',
  templateUrl: './sub-header.component.html',
  styleUrls: ['./sub-header.component.css']
})
export class SubHeaderComponent implements OnInit {

  
  constructor() {
    // var date = new Date();
    // var current_date = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+ date.getDate();
    // document.getElementById("p1").innerHTML = current_date;
  }

  ngOnInit(): void {
  }


  
}
