import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from 'src/app/Services/auth.service';
import {trigger,state,style,animate,transition,} from '@angular/animations';

@Component({
  selector: 'app-mobile-navbar',
  templateUrl: './mobile-navbar.component.html',
  styleUrls: ['./mobile-navbar.component.css'],
  animations:[
    trigger('openClose', [
      // ...
      state(
        'closed',
        style({
          height: '250px',
          opacity: 1,
        
        })
      ),
      state(
        'open',
        style({
          height: '0px',
          opacity: 0,
        })
      ),
     
      transition('open <=> closed', [animate('0.3s')]),
    
    ]),
  ],
})
export class MobileNavbarComponent implements OnInit {
  [x: string]: any;
isUserLoggedIn : Observable<boolean> | undefined;
showme: string | undefined;
width: string = ''
visible:boolean =false
iconup:boolean =false
icondown:boolean =true
iconupSupport:boolean =false
icondownSupport:boolean =true
visibleSupport:boolean =false
mobileNar = "openClose"

mobileBar:boolean = false
isOpen = true;

  constructor( public router :Router, private authService: AuthService) { }
name:string="";
  ngOnInit(): void {
    this.isUserLoggedIn = this.authService.isLoggedIn();
  this.name = localStorage.getItem('fName')! +' ' +  localStorage.getItem('lName')
  }

  logout(){
    this.authService.logout();
    this.router.navigate(['/login']);
  }
 
getName(){
  alert("hello")
}

onClick(){
  this.visible =!this.visible
  this.iconup = !this.iconup
  this.icondown = !this.icondown
}

onClickSupport(){
  this.visibleSupport =!this.visibleSupport
  this.iconupSupport = !this.iconupSupport
  this.icondownSupport = !this.icondownSupport
}

mouseout(){
  this.visibleSupport = false;
  this.visible = false;
  this.iconup = false;
  this.icondown = true;
  this.icondownSupport = true;
  this.iconupSupport =false;

}

openClick(){
this.mobileBar =!this.mobileBar
}
toggle() {
  this.isOpen = false ;

}

}
