import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from 'src/app/Services/auth.service';

@Component({
  selector: 'app-hero',
  templateUrl: './hero.component.html',
  styleUrls: ['./hero.component.css'],
  encapsulation: ViewEncapsulation.None

})
export class HeroComponent implements OnInit {

  isUserLoggedIn : Observable<boolean> | undefined;
  showme: string | undefined;
  width: string = ''
  visible:boolean =false
  iconup:boolean =false
  icondown:boolean =true
  iconupSupport:boolean =false
  icondownSupport:boolean =true
  visibleSupport:boolean =false

  constructor(public router :Router, private authService: AuthService) { }

  name:string="";
  ngOnInit(): void {
    this.isUserLoggedIn = this.authService.isLoggedIn();
  this.name = localStorage.getItem('fName')! +' ' +  localStorage.getItem('lName')
  }

}
