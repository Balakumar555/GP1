import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';
import { AddNewMemberComponent } from './add-new-member/add-new-member.component';
import { MemberManagementService } from './member-management.service';

@Component({
  selector: 'app-patient-search',
  templateUrl: './member-management.component.html',
  styleUrls: ['./member-management.component.css'],
  encapsulation: ViewEncapsulation.None

})
export class MemberManagementComponent implements OnInit {

  constructor(public dialog: MatDialog, private router: Router, private fb: FormBuilder, private memberService:MemberManagementService, private toastr: ToastrService,private sharedService: SharedDataService) { }
  @ViewChild('memberTbSort') memberTbSort = new MatSort();  
  
  dataLoad: boolean = false;  
  memberData: any;
  event: Event | undefined;
  show = false;
  moment = moment;
  maxDate = moment(new Date()).format()
  displayedColumns: string[] = ['memberName','memberNumber','memberDOB','clientName','planName','mbi','eligibilityStart','eligibilityEnd','eligibleStatus','actions'];
  memberSearchForm = this.fb.group({
    memberNumber: [''],
    mbi: [''],    
    lastName: [''],
    firstName: [''],
    dob: ['']    
  })
  ngOnInit() {
  }

  addNewMember() {
    const dialogRef = this.dialog.open(AddNewMemberComponent, {
      data: {}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result == "200") {
        //this.bindGrid();        
      }
    });
  }

  atLeastTwoFieldsRequired(validator: ValidatorFn, controls:string[], group:FormGroup)
  {
    let totalRequiredControls:number = 0
    controls.forEach(c=>
        {
            if(!validator(group.controls[c]))
            {
             totalRequiredControls=totalRequiredControls+1
            }
        })
        if(totalRequiredControls<2)
        {
          group.controls['dob'].setErrors({'atleastTwoRequired': true})
          group.controls['firstName'].setErrors({'atleastTwoRequired': true})
          group.controls['lastName'].setErrors({'atleastTwoRequired': true})
        }
        else
        {
          group.controls['dob'].setErrors(null)
          group.controls['firstName'].setErrors(null)
          group.controls['lastName'].setErrors(null)
        }
        // return (totalRequiredControls < 2)?{
        //   atLeastOne: true,
        // }:null;
  }

  resetForm()
  {
    this.memberSearchForm.reset()
  }
  setMemberId(memberId:any)
  {
    this.sharedService.setOption("eligibilityMemberId",memberId)
  }
  getEligibilityMemberData()
  {
   let mbi = this.memberSearchForm.get('mbi')
   let memberNumber = this.memberSearchForm.get('memberNumber')   
   let dob = this.memberSearchForm.get('dob')

  //  if(mbi?.value?.trim()=='' && memberNumber?.value?.trim()=='' && caseId?.value?.trim()=='')
  //  {
  //     this.atLeastTwoFieldsRequired(Validators.required,['dob','lastName','firstName'],this.memberSearchForm)
  //  }
   if(!mbi?.value && !memberNumber?.value)
   {
      this.atLeastTwoFieldsRequired(Validators.required,['dob','lastName','firstName'],this.memberSearchForm)
   }
   else
   {
    this.memberSearchForm.controls['dob'].setErrors(null)
    this.memberSearchForm.controls['firstName'].setErrors(null)
    this.memberSearchForm.controls['lastName'].setErrors(null)
   }
   
    if (!this.memberSearchForm.valid) {
      return;
    }

    if(dob && dob.value)
    {
      this.memberSearchForm.get("dob")?.setValue(moment(new Date(dob.value!)).format())
    }
    else
    {
      this.memberSearchForm.get("dob")?.setValue('')
    }
var formData = this.memberSearchForm.value
    this.memberService.getEligibilityMemberData(formData)
      .subscribe({
        next:
          (response: any) => {
            if (response.errorContent.statusCode == "200") {
              this.memberData = new MatTableDataSource<any>(response.result);
              setTimeout(() => this.memberData.sort = this.memberTbSort);
      //this.memberData.sort = this.memberTbSort;      
      this.dataLoad = true;             
             // this.resetForm()
             
            }
          },
        error: (e) => this.toastr.error(e)
      });
  }

  
 

}
