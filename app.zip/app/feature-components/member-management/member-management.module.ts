import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { UsersService } from 'src/app/Services/users.service';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { Roles } from 'src/app/shared/constants/role';
import { FormsModule } from '@angular/forms';
import { MaterialModule } from 'src/app/material.module';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ReactiveFormsModule } from '@angular/forms';
import { MemberManagementComponent } from './member-management.component';
import { AddNewMemberComponent } from './add-new-member/add-new-member.component';
import { PreventUnsavedChangesGuard } from 'src/app/core/guards/prevent-unsaved-changes.guard';
import { SharedModule } from 'src/app/shared/shared.module';
import { NgxMaskModule } from 'ngx-mask';
//import { NavigationComponent } from 'src/app//feature-components/navigation/navigation.component';
const routes: Routes = [
  {
     path: '', component: MemberManagementComponent,    
    canActivate:[AuthGuard],canDeactivate:[PreventUnsavedChangesGuard],resolve: { userPermissions: UsersService },data: {roles: [Roles.CaseWorker,Roles.Management,,Roles.Triage]}
    
  } ,
  {
    path:'add-new-member',component: AddNewMemberComponent, canActivate:[AuthGuard],resolve: { userPermissions: UsersService }, canDeactivate:[PreventUnsavedChangesGuard],data: {roles: [Roles.CaseWorker,Roles.Management,Roles.Triage]}
  },
 // {path:'case-details/:id',component: AddCaseDetailsComponent, canActivate:[AuthGuard],resolve: { userPermissions: UsersService },data: {roles: [Roles.CaseWorker,Roles.Management,Roles.Triage]}}     
   
];
@NgModule({
  declarations: [MemberManagementComponent,
    AddNewMemberComponent],
  imports: [
    RouterModule.forChild(routes),
    NgxMaskModule.forChild(),
    CommonModule,
    FormsModule,
    MaterialModule,
    //CoreModule,
    SharedModule,
    ReactiveFormsModule,
  ],
  providers:[[{ provide: MAT_DIALOG_DATA, useValue: {} }],
  [{provide: MatDialogRef,  useValue: {}}],]
})

export class MemberManagementModule { }
