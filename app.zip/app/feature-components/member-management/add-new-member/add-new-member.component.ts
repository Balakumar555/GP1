import { Component, EventEmitter, Input, OnInit, Optional, Output, ViewChild, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UsersService } from 'src/app/Services/users.service';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';
import * as moment from 'moment';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { MemberManagementService } from '../member-management.service';
import { LookUpService } from 'src/app/shared/services/LookUp.service';
import { ClientManagementService } from '../../client-plan-group-management/client-management.service';
import { ClientDetail } from 'src/app/shared/model/clientDetail';
import { LookUp } from 'src/app/shared/model/LookUp';
import { LookUps } from 'src/app/shared/constants/lookUp';


@Component({
  selector: 'app-add-new-member',
  templateUrl: './add-new-member.component.html',
  styleUrls: ['./add-new-member.component.css'],
  encapsulation: ViewEncapsulation.None

})
export class AddNewMemberComponent implements OnInit {

  isChecked = false;
  poaIsChecked = false;
  aorFormReceived: any;
  poaFormReceived: any;

  customerId = localStorage.getItem("customerId")!
  addMemberForm = this.fb.group({
    planInfo: this.fb.group({
      altMemberId: [''],
      memberNumber: ['', [Validators.required]],
      MBI: ['', [Validators.required]],
      relationCode: [''],
      personNumber: [''],
      groupNumber: [''],
      eligibilityEndDate: [moment(new Date()).format(), [Validators.required]],
      eligibilityEffectiveDate: [moment(new Date()).format(), [Validators.required]],
      cardHolderContractNumber: ['', [Validators.required]],
      cmsContractNumber: ['', [Validators.required]],
      clientId: ['', [Validators.required]],
      planId: ['', [Validators.required]],
    }),
    memberInfo: this.fb.group({
      firstName: ['', [Validators.required,  Validators.pattern('^[a-zA-Z ]+$')]],
      middleName: [''],
      lastName: ['', [Validators.required,Validators.pattern('^[a-zA-Z ]+$')]],
      dateOfBirth: [moment(new Date()).format(), [Validators.required]],
      gender: ['', [Validators.required]],
      addressLine1: ['', [Validators.required]],
      addressLine2: [''],
      state: ['', [Validators.required]],
      city: ['', [Validators.required]],
      zip: ['', [Validators.required, Validators.pattern('[0-9]{5}')]],
      homePhone: ['', [Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      workPhone: ['', [Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      fax: [''],
      cellPhone: ['', [Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      communicationPrefrence: [''],
      email: ['', [Validators.email, Validators.maxLength(50)]],
      languagePrefrence: [],
    }),
    aorInfo: this.fb.group({
      aorFirstName: [''],
      aorMiddleName: [''],
      aorLastName: [''],
      aorEmail: ['', [Validators.email, Validators.maxLength(50)]],
      memberSignatureDate: [moment(new Date()).format()],
      apointeeSignatureDate: [moment(new Date()).format()],
      aorCity: [''],
      aorAddressLine1: [''],
      aorAddressLine2: [''],
      aorPhone: ['', [Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      aorZip: ['', [Validators.pattern('[0-9]{5}')]],
      aorState: [''],
      aorRelationship: [''],
      formReceived: [false],
      aorFormReceivedDate: [moment(new Date()).format()],
      aorFormReceivedTime: ['']

    }),
    poaInfo: this.fb.group({
      poaFirstName: [''],
      poaLastName: [''],
      poaEmail: ['', [Validators.email, Validators.maxLength(50)]],
      poaEffectiveDate: [moment(new Date()).format()],
      poaTerminationDate: [moment(new Date()).format()],
      poaCountry: [''],
      poaCity: [''],
      poaAddrLine1: [''],
      poaAddrLine2: [''],
      poaPhone: ['', [Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
      poaZip: ['', [Validators.pattern('[0-9]{5}')]],
      poaState: [''],
      poaRelationship: [''],
      poaformReceived: [false],
      poaFormReceivedDate: [moment(new Date()).format()],    

    }),
    isAor: [false],
    isPoa: [false],
    createdDate: [new Date()],
    lastModifiedBy: [],
    lastModifiedDate: [],
    customerId:0,
    createdBy:0

  })
  clients!: any[];
  plans!: any[];
  maxdate = moment(new Date()).format()


  aorRelationShips!: any[];
  poaRelationShips!: any[];
  caseStatus!: any[];
  genders!: any[];
  categories!: any[];
  communicationPreferences  !: any[];
  languagePreferences!: any[];
  relationshipCodes!: any[];
  representativeTypes!: any[];
  requestTypes!: any[];
  sources!: any[];
  states!: any[];





  get AorFormReceivedDate() { return this.addMemberForm.get('aorInfo.aorFormReceivedDate');



}
get PoaFormReceivedDate() { return this.addMemberForm.get('poaInfo.poaFormReceivedDate')};

  constructor(private fb: FormBuilder, private router: Router, private memberService: MemberManagementService, private clientService: ClientManagementService, private toastr: ToastrService, protected route: ActivatedRoute, private sharedService: SharedDataService, private lookupService: LookUpService) {
    this.getClients();
    this.getLookUpsByLookUpName(LookUps.Gender);
    this.getLookUpsByLookUpName(LookUps.RelationCode);
    this.getLookUpsByLookUpName(LookUps.LanguagePreference);
    this.getLookUpsByLookUpName(LookUps.CommunicationPreference);
    this.getLookUpsByLookUpName(LookUps.State);
    //this.getLookUpsByLookUpName(LookUps.RepresentativeType, this.customerId);
    this.getLookUpsByLookUpName(LookUps.AORRelationShip);
    // this.getLookUpsByLookUpName(LookUps.POARelationShip, this.customerId);





  }
  get f(): { [key: string]: AbstractControl } {

    return this.addMemberForm.controls;

  }
  get getEffectiveDate() { return this.addMemberForm.get('planInfo.eligibilityEffectiveDate'); }
  ngOnInit(): void {
    if (!this.isChecked) {
      //let recDate = moment(new Date(this.addCaseDetailForm.get("receivedDate")?.value!))
      this.addMemberForm.controls.aorInfo.reset()
      this.addMemberForm.controls.aorInfo.disable()
      this.addMemberForm.controls.poaInfo.reset()
      this.addMemberForm.controls.poaInfo.disable()


    }
  }

  onClientChange(client: any) {
    this.plans=[]
    this.addMemberForm.get('planInfo.planId')?.setValue('')
    this.getPlans(client)
  }

  getLookUpsByLookUpName(lookUpName: any) {
    this.lookupService.geLookUpsByLookUpName(lookUpName).subscribe((data: LookUp[]) => {
      switch (lookUpName) {
        case LookUps.Gender:
          this.genders = data;
          break;this.ngOnInit
       
        case LookUps.AORRelationShip:
          this.aorRelationShips = data;
          break;

          // case LookUps.POARelationShip:
          //   this.poaRelationShips = data;
          //   break;

        case LookUps.CaseStatus:
          this.caseStatus = data;
          break;
        case LookUps.Category:
          this.categories = data;
          break;

        case LookUps.CommunicationPreference:
          this.communicationPreferences = data;
          break;

        case LookUps.LanguagePreference:
          this.languagePreferences = data;
          break;
        case LookUps.RelationCode:
          this.relationshipCodes = data;
          break;
        case LookUps.RepresentativeType:
          this.representativeTypes = data;
          break;

        case LookUps.RequestType:
          this.requestTypes = data;
          break;

        case LookUps.Source:
          this.sources = data;
          break;

        case LookUps.State:
          this.states = data;
          break;
        default:
          break;
      }
    })
  }
  getClients() {
    this.clientService.getActiveClientsByCustomer().subscribe((data: ClientDetail[]) => {
      this.clients = data;
    })
  }

  getPlans(clientId: any) {
    this.clientService.getAllPlansByClientId(clientId).subscribe((data: any) => {
      this.plans = data.result;
    })
  }
  addValidators(controls: string[]) {
    controls.forEach(c => {
      this.addMemberForm.get(c)?.setValidators(Validators.required);
      this.addMemberForm.get(c)?.updateValueAndValidity();
    });
  }

  removeValidators(controls: string[]) {
    controls.forEach(c => {
      this.addMemberForm.get(c)?.clearValidators();
      this.addMemberForm.get(c)?.updateValueAndValidity();
    });
  }
  showHideAOR() {
    this.isChecked = !this.isChecked;
    if (!this.isChecked) {
      this.removeValidators(['aorInfo.aorFirstName', 'aorInfo.aorLastName', 'aorInfo.aorCity', 'aorInfo.aorZip', 'aorInfo.aorState', 'aorInfo.aorRelationship', 'aorInfo.aorAddressLine1','aorInfo.aorPhone','aorInfo.aorEmail'])
      this.addMemberForm.controls.aorInfo.reset()
      this.addMemberForm.controls.aorInfo.disable()
    }
    else {
      this.addValidators(['aorInfo.aorFirstName', 'aorInfo.aorLastName', 'aorInfo.aorCity', 'aorInfo.aorZip', 'aorInfo.aorState', 'aorInfo.aorRelationship', 'aorInfo.aorAddressLine1','aorInfo.aorPhone','aorInfo.aorEmail'])

      this.addMemberForm.controls.aorInfo.enable()
    }

  }


  showHidePOA() {
    this.poaIsChecked = !this.poaIsChecked;
    if (!this.poaIsChecked) {
      this.removeValidators(['poaInfo.poaFirstName', 'poaInfo.poaLastName', 'poaInfo.poaCity', 'poaInfo.poaZip', 'poaInfo.poaState', 'poaInfo.poaRelationship', 'poaInfo.poaAddressLine1', 'poaInfo.poaPhone','poaInfo.poaEmail'])
      this.addMemberForm.controls.poaInfo.reset()
      this.addMemberForm.controls.poaInfo.disable()
    }
    else {
      this.addValidators(['poaInfo.poaFirstName', 'poaInfo.poaLastName', 'poaInfo.poaCity', 'poaInfo.poaZip', 'poaInfo.poaState', 'poaInfo.poaRelationship', 'poaInfo.poaAddressLine1','poaInfo.poaPhone','poaInfo.poaEmail'])
      this.addMemberForm.controls.poaInfo.enable()
    }

  }


  transformDate(date: any, timeControlName: any, controlName: AbstractControl) {
    const d = new Date(date);
    let time = this.addMemberForm.get(timeControlName)?.value!;
    d.setHours(parseInt(time.split(':')[0]));
    d.setMinutes(parseInt(time.split(':')[1]));
    controlName?.patchValue(d);
  }
validateAOR(event:any)
{
  this.aorFormReceived = this.addMemberForm.get('aorInfo.formReceived')?.value!
  if (this.aorFormReceived && this.aorFormReceived == "true") {
    this.addValidators(['aorInfo.aorFormReceivedDate', 'aorInfo.memberSignatureDate', 'aorInfo.apointeeSignatureDate', 'aorInfo.aorFormReceivedTime'])
 
  }
  else {
    this.removeValidators(['aorInfo.aorFormReceivedDate', 'aorInfo.memberSignatureDate', 'aorInfo.apointeeSignatureDate', 'aorInfo.aorFormReceivedTime'])
  }
}
validatePOA(event:any)
{
  this.poaFormReceived = this.addMemberForm.get('poaInfo.poaformReceived')?.value!
  if (this.poaFormReceived && this.poaFormReceived == "true") {
    this.addValidators(['poaInfo.poaFormReceivedDate', 'poaInfo.poaEffectiveDate', 'poaInfo.poaTerminationDate'])
 
  }
  else {
    this.removeValidators(['poaInfo.poaFormReceivedDate', 'poaInfo.poaEffectiveDate', 'poaInfo.poaTerminationDate'])
  }
}
  addMember() {

    //this.aorFormReceived = this.addMemberForm.get('aorInfo.formReceived')?.value!
   // this.poaFormReceived = this.addMemberForm.get('poaInfo.poafrmReceived')?.value!

   // //if (this.aorFormReceived && this.aorFormReceived == "true") {
  //    this.addValidators(['aorInfo.aorFormReceivedDate', 'aorInfo.memberSignatureDate', 'aorInfo.apointeeSignatureDate', 'aorInfo.aorFormReceivedTime'])
   // }
  //  else {
 //     this.removeValidators(['aorInfo.aorFormReceivedDate', 'aorInfo.memberSignatureDate', 'aorInfo.apointeeSignatureDate', 'aorInfo.aorFormReceivedTime'])
 //   }

    // if (this.poaFormReceived && this.poaFormReceived == "true") {
    //   this.addValidators(['poaInfo.pofrmReceivedDate', 'poaInfo.memberSignatureDate', 'aorInfo.apointeeSignatureDate', 'aorInfo.aorFormReceivedTime'])
    // }
    // else {
    //   this.removeValidators(['poaInfo.frmFormReceivedDate', 'poaInfo.memberSignatureDate', 'aorInfo.apointeeSignatureDate', 'aorInfo.aorFormReceivedTime'])
    // }



    if (!this.addMemberForm.valid) {
      return;
    }
    if (this.AorFormReceivedDate && this.AorFormReceivedDate.value != null) {
      this.transformDate(this.addMemberForm.get("aorInfo.aorFormReceivedDate")?.value!, "aorInfo.aorFormReceivedTime", this.AorFormReceivedDate)
    }
    this.addMemberForm.get('aorInfo.formReceived')!.setValue(this.aorFormReceived == "true" ? true : false);
    this.addMemberForm.get('poaInfo.poaformReceived')!.setValue(this.poaFormReceived == "true" ? true : false);

    //console.log(this.addMemberForm.value)
    this.sharedService.setOption('memberDetail', this.addMemberForm.value)
    // this.router.navigate(['/case-management/case-details'])
    //
    this.memberService.SaveMember(this.addMemberForm.value).subscribe({
      next:
        (response: any) => {
          if (response.errorContent.statusCode == "200") {
            this.sharedService.setOption("eligibilityMemberId",response.result)
            this.router.navigate(['/case-management/case-details'])
            this.toastr.success('Data saved successfully');

          }
        },
      error: (e) => this.toastr.error(e.error.errorContent.message)
    });
  }
}
function PoaFormReceivedDate() {
  throw new Error('Function not implemented.');
}

