import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, RouterState } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { UsersService } from 'src/app/Services/users.service';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { Roles } from 'src/app/shared/constants/role';
import { AbstractControlOptions, FormBuilder, FormGroup, FormsModule, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { MaterialModule } from 'src/app/material.module';
//import { CoreModule } from 'src/app/core/core.module';
//import { SharedModule } from 'src/app/shared/shared.module';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ReactiveFormsModule } from '@angular/forms';  
import { MatSort } from '@angular/material/sort';
import * as moment from 'moment';
import { MatPaginator } from '@angular/material/paginator';

import { IfStmt } from '@angular/compiler';
import { CaseService } from '../case-management/case.service';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';
import { MatTableDataSource } from '@angular/material/table';
import { animate, state, style, transition, trigger } from '@angular/animations';




@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})

export class HomeComponent implements OnInit {
  searchTitle: boolean = true;
  status: 'open' | 'closed' = 'closed';
  private communication:{ name:string}[]=[];

  @ViewChild('caseTbSort') caseTbSort = new MatSort();  
  
  dataLoad: boolean = false;
  _userId: string = "";
  caseData: any;
  event: Event | undefined;
  show = false;
  moment = moment;
  maxDate = moment(new Date()).format()
  role: number = 0;
  userRole:string=''
  displayedColumns: string[] = ['caseID', 'receivedDate', 'memberNumber', 'memberName','memberDOB','mbi', 'closedDate', 'categoryName', 'caseOutcome'];
  dashboardForm = this.fb.group({
    memberNumber: [''],
    mbi: [''],
    caseId: [''],
    lastName: [''],
    firstName: [''],
    dob: ['']    
  })
  //{ validator: atLeastOne(Validators.required, ['dob','lastName','firstName']) } as AbstractControlOptions
  


  //pageOptions: number[] = [5, 10, 20];
  //@ViewChild(MatPaginator, { static: false }) paginator!: MatPaginator;
  userPermissions: any = {};
  sharedService: any;
  


   constructor(private router: Router,
                private fb: FormBuilder,
                private caseService: CaseService,
                private toastr: ToastrService,
                private route: ActivatedRoute
                )  
   {}
   
   expandToggle = true;
   check:boolean =true;
   hide:boolean = false;
   coltwo:boolean =true;
   hidetwo:boolean = false;
   state: string= 'default';

  

  

  

  ngOnInit(): void {
  
   
  }
  canUserHasAddPermission()
  {  
    // return this.sharedService.hasPermission(Permissions.CreateNewUser, this.userPermissions.result)  
  }
  
  canUserHasEditPermission()
  {    
    // return this.sharedService.hasPermission(Permissions.EditExistingUser, this.userPermissions.result)  
  }
  

  atLeastTwoFieldsRequired(validator: ValidatorFn, controls:string[], group:FormGroup)
  {
    let totalRequiredControls:number = 0
    controls.forEach(c=>
        {
            if(!validator(group.controls[c]))
            {
             totalRequiredControls=totalRequiredControls+1
            }
        })
        if(totalRequiredControls<2)
        {
          group.controls['dob'].setErrors({'atleastTwoRequired': true})
          group.controls['firstName'].setErrors({'atleastTwoRequired': true})
          group.controls['lastName'].setErrors({'atleastTwoRequired': true})
        }
        else
        {
          group.controls['dob'].setErrors(null)
          group.controls['firstName'].setErrors(null)
          group.controls['lastName'].setErrors(null)
        }
        // return (totalRequiredControls < 2)?{
        //   atLeastOne: true,
        // }:null;
  }

  resetForm()
  {
    this.dashboardForm.reset()
  }
  getDashboardData()
  {
   let mbi = this.dashboardForm.get('mbi')
   let memberNumber = this.dashboardForm.get('memberNumber')
   let caseId = this.dashboardForm.get('caseId')
   let dob = this.dashboardForm.get('dob')

  //  if(mbi?.value?.trim()=='' && memberNumber?.value?.trim()=='' && caseId?.value?.trim()=='')
  //  {
  //     this.atLeastTwoFieldsRequired(Validators.required,['dob','lastName','firstName'],this.dashboardForm)
  //  }
   if(!mbi?.value && !memberNumber?.value && !caseId?.value)
   {
      this.atLeastTwoFieldsRequired(Validators.required,['dob','lastName','firstName'],this.dashboardForm)
   }
   else
   {
    this.dashboardForm.controls['dob'].setErrors(null)
    this.dashboardForm.controls['firstName'].setErrors(null)
    this.dashboardForm.controls['lastName'].setErrors(null)
   }
   
    if (!this.dashboardForm.valid) {
      return;
    }

    if(dob && dob.value)
    {
      this.dashboardForm.get("dob")?.setValue(moment(new Date(dob.value!)).format())
    }
    else
    {
      this.dashboardForm.get("dob")?.setValue('')
    }
var formData = this.dashboardForm.value
    this.caseService.getDashboardData(formData)
      .subscribe({
        next:
          (response: any) => {
            if (response.errorContent.statusCode == "200") {
              this.caseData = new MatTableDataSource<any>(response.result);
              setTimeout(() => this.caseData.sort = this.caseTbSort);
      //this.caseData.sort = this.caseTbSort;      
      this.dataLoad = true;             
             // this.resetForm()
             
            }
          },
        error: (e) => this.toastr.error(e)
      });
  }
 
// onclick(){
//   this.searchTitle =!this.searchTitle
// }
  


}
