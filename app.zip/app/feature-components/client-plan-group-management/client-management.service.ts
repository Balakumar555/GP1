import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { BehaviorSubject, map, Observable } from 'rxjs';
import { ActivatedRouteSnapshot } from '@angular/router';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { User } from 'src/app/shared/model/user';
import { CaseDetail } from 'src/app/shared/model/caseDetail';
import { ClientDetail } from 'src/app/shared/model/clientDetail';
import * as moment from 'moment';

@Injectable({
    providedIn: 'root'
})
export class ClientManagementService {
    //private baseURL = "https://qapoc.pahub.com/GrievanceAPI/Grievances";
    //private baseURL = 'https://localhost:7091/Grievances';  
    constructor(private httpClient: HttpClient, private sharedService: SharedDataService) { }
    private client = new BehaviorSubject<any>(0);
    private plan = new BehaviorSubject<any>(0);
    selectedClient = this.client.asObservable();
    selectedPlan = this.plan.asObservable();
    moment = moment;
    setSlectedClient(client: any) {
        this.client.next(client)
    }

    setSlectedplan(plan: any) {
        this.plan.next(plan)
    }
    resolve(route: ActivatedRouteSnapshot) {
        return this.sharedService.getUserPrivileges();
    }
    getClientsByCustomer() {

        return this.httpClient.get<any>('/GetAllClientsByCustomerId')
            .pipe(map((response: any) => {
                const result = Object.keys(response.result).map(x => ({
                    clientCode: response.result[x].clientCode,
                    clientId: response.result[x].clientId,
                    clientName: response.result[x].clientName,
                    description: response.result[x].description,
                    effectiveDate: response.result[x].effectiveDate,
                    endDate: response.result[x].endDate,
                    clientTypeId: response.result[x].clientTypeId,
                    createdBy: response.result[x].createdBy,
                    createdDate: response.result[x].createdDate,
                    customerId: response.result[x].customerId,
                    lastModifiedBy:response.result[x].lastModifiedBy,
                    lastModifiedDate:response.result[x].lastModifiedDate,
                    status:response.result[x].status,
                    logo:response.result[x].logo
                })) as ClientDetail[]
                return result;
            }));
    }

    getActiveClientsByCustomer() {
         return this.httpClient.get<any>('/GetActiveClientsByUserId')
            .pipe(map((response: any) => {
                const result = Object.keys(response.result).map(x => ({
                    clientCode: response.result[x].clientCode,
                    clientId: response.result[x].clientId,
                    clientName: response.result[x].clientName,
                    description: response.result[x].description,
                    effectiveDate: response.result[x].effectiveDate,
                    endDate: response.result[x].endDate,
                    clientTypeId: response.result[x].clientTypeId,
                    createdBy: response.result[x].createdBy,
                    createdDate: response.result[x].createdDate,
                    customerId: response.result[x].customerId,
                    lastModifiedBy:response.result[x].lastModifiedBy,
                    lastModifiedDate:response.result[x].lastModifiedDate
                })) as ClientDetail[]
                return result;
            }));
    }

    getAllPlansByClientId(clientId: any) {
        return this.httpClient.get<any>('/GetAllPlansByClientId?clientId=' + clientId);
    }

    getAllGroupsByPlanId(planId: any) {
        return this.httpClient.get<any>('/GetAllGroupsByPlanId?planId=' + planId);
    }

    SaveClient(clientData: any): Observable<any> {       
        
        const formData: FormData = new FormData();   
        formData.append('logo', clientData.logo);
        formData.append('clientTypeId', clientData.clientTypeId);
        formData.append('customerId', clientData.customerId);
        formData.append('clientName', clientData.clientName);
        formData.append('clientCode', clientData.clientCode);
        formData.append('description', clientData.description);
        formData.append('effectiveDate', (moment(clientData.effectiveDate)).format('MM/DD/YYYY') );
        formData.append('endDate', (moment(clientData.endDate)).format('MM/DD/YYYY'));
        formData.append('createdDate', (moment(clientData.createdDate)).format('MM/DD/YYYY'));
        formData.append('createdBy', clientData.createdBy);
        formData.append('logo', clientData.logo);      
        return this.httpClient.post<any>('/CreateClient', formData);
    }
    UpdateClient(clientData: any): Observable<any> {
        const formData: FormData = new FormData();
        formData.append('clientId', clientData.clientId);
        formData.append('logo', clientData.logo);
        formData.append('clientTypeId', clientData.clientTypeId);
        formData.append('customerId', clientData.customerId);
        formData.append('clientName', clientData.clientName);
        formData.append('clientCode', clientData.clientCode);
        formData.append('description', clientData.description);
        formData.append('effectiveDate', (moment(clientData.effectiveDate)).format('MM/DD/YYYY') );
        formData.append('endDate', (moment(clientData.endDate)).format('MM/DD/YYYY'));
        formData.append('logo', clientData.logo);  
        return this.httpClient.post<any>('/UpdateClient', formData);
    }
    SavePlan(planData: any): Observable<any> {

        var savePlanReq = planData;
        return this.httpClient.post<any>('/CreatePlan', savePlanReq);
    }
    UpdatePlan(planData: any): Observable<any> {

        var savePlanReq = planData;
        return this.httpClient.post<any>('/UpdatePlan', savePlanReq);
    }

    SaveGroup(groupData: any): Observable<any> {

        var saveGroupReq = groupData;
        return this.httpClient.post<any>('/CreateGroup', saveGroupReq);
    }

    UpdateGroup(groupData: any): Observable<any> {

        var saveGroupReq = groupData;
        return this.httpClient.post<any>('/UpdateGroup', saveGroupReq);
    }




    getAllClientTypes() {
        return this.httpClient.get<any>('/GetAllClientTypes');
    }

    getAllPlanTypes() {
        return this.httpClient.get<any>('/GetAllPlanTypes');
    }

    getAllGroupTypes() {
        return this.httpClient.get<any>('/GetAllGroupTypes');
    }

    getAllCaseDetail() {
        //var customerId = localStorage.getItem("customerId");
        return this.httpClient.get<any>('/GetAllCaseDetails');

    }

    getCaseDetailsById(caseId: any): Observable<CaseDetail> {
        var customerId = localStorage.getItem("customerId")!;

        const params = new HttpParams()
          .set('caseId', caseId)
          .set('customerId', customerId);
        return this.httpClient.get<CaseDetail>('/GetCaseDetailById', { params: params }).pipe(
            map((response: any) => response.result)
        );

    }


}
