import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientPlanGroupComponent } from './client-plan-group-management.component';

describe('ClientComponent', () => {
  let component: ClientPlanGroupComponent;
  let fixture: ComponentFixture<ClientPlanGroupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClientPlanGroupComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClientPlanGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
