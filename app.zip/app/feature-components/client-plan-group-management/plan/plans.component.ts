import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSelectionListChange } from '@angular/material/list';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AuthService } from 'src/app/Services/auth.service';
import { UsersService } from 'src/app/Services/users.service';
import { ClientDetail } from 'src/app/shared/model/clientDetail';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { ClientManagementService } from '../client-management.service';
import { AddPlansFormComponent } from './add-plans-form/add-plans-form.component';
import { EditPlanFormComponent } from './edit-plan-form/edit-plan-form.component';


@Component({
  selector: 'app-plans',
  templateUrl: './plans.component.html',
  styleUrls: ['./plans.component.css']
})
export class PlansComponent implements OnInit {

  constructor(public dialog: MatDialog,private authService:AuthService, private route: ActivatedRoute ,private userService: UsersService, private router: Router, private fb: FormBuilder, private clientService:ClientManagementService) { }

clientId:any=null
plans!:any[]
selectedPlan: any
clonedPlansDetails!:any[]
enableList:boolean =false;
enableEdit:boolean=false;
subscription!:Subscription

  ngOnInit(): void {      
   this.subscription= this.clientService.selectedClient.subscribe(value=>{
      this.clientId=value;
      if(this.clientId >0)
      {
      this.bindList(this.clientId)
      this.enableList=true
      this.enableEdit=false
    }
     console.log(this.clientId)
    })
    
    
  }
  ngOnDestroy() {
    this.subscription.unsubscribe()
    this.clientService.setSlectedplan(null)
}
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;    
   this.plans=filterValue.length>0 ? this.clonedPlansDetails.filter(value=> value.planName.toLowerCase().includes(filterValue))
   : this.clonedPlansDetails
  
  }

  selectionChanged(event: MatSelectionListChange): void {
    let selectedPlan = event.options.filter(o => o.selected).map(o => o.value); 
    this.selectedPlan = selectedPlan[0]   
    this.clientService.setSlectedplan(selectedPlan[0].clientPlanId)
    this.enableEdit=true
}
bindList(clientId:any)
{
  this.clientService.getAllPlansByClientId(clientId).subscribe((data: any ) => {
    this.clonedPlansDetails=this.plans = data.result;
  })
}
addNewPlan() {
    const dialogRef = this.dialog.open(AddPlansFormComponent, {
      data: {},
      width: '45%'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result == "200") {
        this.bindList(this.clientId);        
      }
    });
  }

  editPlan(obj: any) {
    const dialogRef = this.dialog.open(EditPlanFormComponent, {
      data: obj,
      width: '45%'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result == "200") {
        this.bindList(this.clientId);
        this.enableEdit=false        
      }
    });
  }
}
