import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPlansFormComponent } from './add-plans-form.component';

describe('AddPlansFormComponent', () => {
  let component: AddPlansFormComponent;
  let fixture: ComponentFixture<AddPlansFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddPlansFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddPlansFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
