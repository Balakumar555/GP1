import { Component, Inject, OnInit, Optional } from '@angular/core';
import { AbstractControl, AbstractControlOptions, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';
import { ClientManagementService } from '../../client-management.service';

@Component({
  selector: 'app-add-plans-form',
  templateUrl: './add-plans-form.component.html',
  styleUrls: ['./add-plans-form.component.css']
})
export class AddPlansFormComponent implements OnInit {
  //dialogRef: any;

  constructor(private toastr: ToastrService, public dialogRef: MatDialogRef<AddPlansFormComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any, private router: Router, private fb: FormBuilder, private clientService: ClientManagementService) { }

  addPlanForm = this.fb.group({
    planTypeId: ['', [Validators.required]],
    clientId: ['', [Validators.required]],
    planName: ['', [Validators.required]],
    planCode: ['', [Validators.required]],
    description: ['', [Validators.required]],
    effectiveDate: [moment(new Date()).format(), [Validators.required]],
    endDate: [moment(new Date()).format(), [Validators.required]],
    createdDate: [moment(new Date()).format(), [Validators.required]],
    lastModifiedDate: [null],
    lastModifiedBy: [null],
    createdBy: 0,
  })
  
  planTypes: any
  ngOnInit(): void {
    this.getAllPlanTypes()
    this.clientService.selectedClient.subscribe(value => {
      this.addPlanForm.get("clientId")?.setValue(value)
      console.log(value)
    })
  }
  
  getAllPlanTypes() {
    this.clientService.getAllPlanTypes()
      .subscribe(planType => {
        this.planTypes = planType.result;
        // console.log(roles);
      })
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  get f(): { [key: string]: AbstractControl } {

    return this.addPlanForm.controls;

  }
  savePlan() {
    if (!this.addPlanForm.valid) {
      return;
    }

    //this.trimFormValues(this.addUserForm);
    //this.submitted = true;
    var formData = this.addPlanForm.value;
    this.clientService.SavePlan(formData)
      .subscribe({
        next:
          (response: any) => {
            if (response.errorContent.statusCode == "200") {
              this.toastr.success('Data saved successfully');
              this.dialogRef.close(response.errorContent.statusCode);
            }
          },
        error: (e) => this.toastr.error(e.error.errorContent.message)
      });
  }
}
