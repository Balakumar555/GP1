import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPlanFormComponent } from './edit-plan-form.component';

describe('AddPlansFormComponent', () => {
  let component: EditPlanFormComponent;
  let fixture: ComponentFixture<EditPlanFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditPlanFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditPlanFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
