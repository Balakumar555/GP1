import { Component, EventEmitter, OnInit, Output, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatListOption, MatSelectionListChange } from '@angular/material/list';
import { MatSelect } from '@angular/material/select';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/Services/auth.service';
import { UsersService } from 'src/app/Services/users.service';
import { ClientDetail } from 'src/app/shared/model/clientDetail';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { ClientManagementService } from '../client-management.service';
import { AddClientFormComponent } from './add-client-form/add-client-form.component';
import { EditClientFormComponent } from './edit-client-form/edit-client-form.component';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.css'],
  encapsulation: ViewEncapsulation.None

})
export class ClientComponent implements OnInit {
  clients!: any[]
  clonedClientsDetails!: any[]
  selectedClient: any
  enableEdit: boolean = false;
 // @ViewChild('client') select!: MatListOption ;
 // selectedOptions: MatListOption
  constructor(public dialog: MatDialog, private authService: AuthService, private route: ActivatedRoute, private userService: UsersService, private router: Router, private fb: FormBuilder, private clientService: ClientManagementService) { }

  ngOnInit(): void {
    this.bindList()

  }
  ngOnDestroy() {
    this.clientService.setSlectedClient(null)
}
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.clients = filterValue.length > 0 ? this.clonedClientsDetails.filter(value => value.clientName.toLowerCase().includes(filterValue))
      : this.clonedClientsDetails

  }

  selectionChanged(event: MatSelectionListChange): void {
    let selected = event.options.filter(o => o.selected).map(o => o.value);
    // this.addNewItem(selected[0])
    this.selectedClient = selected[0]
    this.clientService.setSlectedClient(selected[0].clientId)
    this.clientService.setSlectedplan(0)
    this.enableEdit = true
  }
  bindList() {
    this.clientService.getClientsByCustomer().subscribe((data: ClientDetail[]) => {
      this.clonedClientsDetails = this.clients = data;     
    })
  }
  addNewClient() {
    const dialogRef = this.dialog.open(AddClientFormComponent, {
      data: {},
      width: '45%',
      //  disableClose: true,
      //hasBackdrop: true
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result == "200") {
        this.bindList();
                
      }
    });
  }

  editClient(obj: any) {
    const dialogRef = this.dialog.open(EditClientFormComponent, {
      data: obj,
      width: '45%'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result == "200") {
        this.bindList();
        this.enableEdit=false  
      }
    });

  }
}
