import { Component, Inject, OnInit, Optional } from '@angular/core';
import { ConfirmDialogComponent } from 'src/app/shared/confirm-dialog/confirm-dialog.component';
import {
  AbstractControl,
  AbstractControlOptions,
  FormBuilder,
  FormControl,
  Validators,
} from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';
import { ClientManagementService } from '../../client-management.service';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-add-client-form',
  templateUrl: './add-client-form.component.html',
  styleUrls: ['./add-client-form.component.css'],
})
export class AddClientFormComponent implements OnInit {
  item: any;
  SelectedFile: any;
  message: string = '';
  preview: string = '';
  fileName: string = '';
  progress: number = 0;
  selectedFiles?: FileList;
  currentFile?: File;
  IsLogovalid: boolean = false;
  imageValidateMsg: any = 'File should not exceed more than 3 MB';
  index: any;
  //dialogRef: any;

  constructor(
    public dialog: MatDialog,
    private toastr: ToastrService,
    public dialogRef: MatDialogRef<AddClientFormComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any,
    private router: Router,
    private fb: FormBuilder,
    private clientService: ClientManagementService
  ) {}

  addClientForm = this.fb.group({
    clientTypeId: ['', [Validators.required]],
    customerId: localStorage.getItem('customerId'),
    clientName: ['', [Validators.required]],
    clientCode: ['', [Validators.required]],
    description: ['', [Validators.required]],
    effectiveDate: ['', [Validators.required]],
    endDate: ['', [Validators.required]],
    createdDate: [moment(new Date()).format()],
    createdBy: localStorage.getItem('userId')!,
    fileEle: new FormControl(''),
    logo: new FormControl('')
  });

  clientTypes!: any[];
  ngOnInit(): void {
    this.getAllClientTypes();
  }
  onNoClick(): void {
    this.dialogRef.close();
  }

  getAllClientTypes() {
    this.clientService.getAllClientTypes().subscribe((clientType) => {
      this.clientTypes = clientType.result;
      // console.log(roles);
    });
  }
  get f(): { [key: string]: AbstractControl } {
    return this.addClientForm.controls;
  }
  saveClient() {
    if (!this.addClientForm.valid) {
      return;
    }

    //this.trimFormValues(this.addUserForm);
    //this.submitted = true;
    var formData = this.addClientForm.value;
    this.clientService.SaveClient(formData).subscribe({
      next: (response: any) => {
        if (response.errorContent.statusCode == '200') {
          this.toastr.success('Data saved successfully');
          this.dialogRef.close(response.errorContent.statusCode);
        }
      },
      error: (e) => this.toastr.error(e.error.errorContent.message),
    });
  }
  selectFile(event: any): void {
    this.IsLogovalid=false;
    this.message = '';
    this.preview = '';
    this.progress = 0;
    console.log(event.target.files);
    this.selectedFiles = event.target.files;

    if (this.selectedFiles) {
      if (
        event.target.files[0].type === 'image/jpeg' ||
        event.target.files[0].type === 'image/png' ||
        event.target.files[0].type === 'image/jpg'
      ) {
        // if (event.target.files[0].height < 1000) {
        // if (event.target.files[0].size < 5000) {
        const file: File | null = this.selectedFiles.item(0);

        if (file) {
          this.preview = '';
          this.currentFile = file;
          this.fileName = event.target.files[0].name;
          const reader = new FileReader();

          reader.onload = (e: any) => {
            // console.log(e.target.result);
            this.preview = e.target.result;
            
          };

          reader.readAsDataURL(this.currentFile);
        }
        const fileSource = event.target.files[0];
        this.addClientForm.patchValue({
          logo: fileSource
        });
        } else {
        this.IsLogovalid = true;
        this.imageValidateMsg = 'Upload jpeg, jpg or png only';
      }
    }    
  }

  delete() {
   const confirmDialog = this.dialog.open(ConfirmDialogComponent, {
     data: {
       title: 'Delete Client logo',
       message: 'Are you sure you want to delete this Client logo? '
     }
   });
   confirmDialog.afterClosed().subscribe(result => {
     if (result === true) {
      this.preview = '';
       this.currentFile=undefined;      
       this.toastr.success('Client logo deleted successfully.');           
     }
   });

 }


}
