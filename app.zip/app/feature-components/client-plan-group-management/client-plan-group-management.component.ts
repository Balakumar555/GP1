import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/Services/auth.service';
import { UsersService } from 'src/app/Services/users.service';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { AddClientFormComponent } from './client/add-client-form/add-client-form.component';

@Component({
  selector: 'app-client-plan-group',
  templateUrl: './client-plan-group-management.component.html',
  styleUrls: ['./client-plan-group-management.component.css']
})
export class ClientPlanGroupComponent implements OnInit {
  clientId:any

clientForPlan:any
  constructor(public dialog: MatDialog,private authService:AuthService, private route: ActivatedRoute ,private userService: UsersService, private router: Router, private fb: FormBuilder, private sharedService:SharedDataService) { }

  ngOnInit(): void {
  }

  getClientId(newItem: string) {
    this.clientId=newItem;
    
  }
 
}
