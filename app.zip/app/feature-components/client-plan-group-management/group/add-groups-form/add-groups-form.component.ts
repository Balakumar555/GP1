import { Component, Inject, OnInit, Optional } from '@angular/core';
import { AbstractControl, AbstractControlOptions, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';
import { ClientManagementService } from '../../client-management.service';

@Component({
  selector: 'app-add-groups-form',
  templateUrl: './add-groups-form.component.html',
  styleUrls: ['./add-groups-form.component.css']
})
export class AddGroupsFormComponent implements OnInit {
  //dialogRef: any;

  constructor(private toastr: ToastrService, public dialogRef: MatDialogRef<AddGroupsFormComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any, private router: Router, private fb: FormBuilder,private clientService:ClientManagementService) { }

    addGroupForm = this.fb.group({   
      groupTypeId : ['', [Validators.required]],
      clientPlanId : ['', [Validators.required]],
      groupName : ['', [Validators.required]],
      groupNumber : ['', [Validators.required]],
      description : ['', [Validators.required]],
       effectiveDate :[moment(new Date()).format(), [Validators.required]],
       endDate : [moment(new Date()).format(), [Validators.required]],
       createdDate : [moment(new Date()).format(), [Validators.required]],		 
       lastModifiedDate :[null],
      lastModifiedBy : [null],  
      createdBy: 0,
    })
    groupTypes:any
  ngOnInit(): void {
    this.getAllGroupTypes()
    this.clientService.selectedPlan.subscribe(value=>{
      this.addGroupForm.get("clientPlanId")?.setValue(value)
       console.log(value)
      })
  }  
  onNoClick(): void {
    this.dialogRef.close();
  }
  get f(): { [key: string]: AbstractControl } {

    return this.addGroupForm.controls;

  }
  getAllGroupTypes()
  {
    this.clientService.getAllGroupTypes()
    .subscribe(groupType => {
      this.groupTypes=groupType.result;
     // console.log(roles);
    })
  }
  saveGroup()
  {
   if (!this.addGroupForm.valid) {
        return;
      }
  
      //this.trimFormValues(this.addUserForm);
      //this.submitted = true;
      var formData = this.addGroupForm.value;
      this.clientService.SaveGroup(formData)
        .subscribe({
          next:
            (response: any) => {
              if (response.errorContent.statusCode == "200") {
                this.toastr.success('Data saved successfully');
                this.dialogRef.close(response.errorContent.statusCode);
              }
            },
          error: (e) => this.toastr.error(e.error.errorContent.message)
        });
  }

}
