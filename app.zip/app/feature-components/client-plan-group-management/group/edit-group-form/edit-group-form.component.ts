import { Component, Inject, OnInit, Optional } from '@angular/core';
import { AbstractControl, AbstractControlOptions, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';
import { ClientManagementService } from '../../client-management.service';

@Component({
  selector: 'app-edit-group-form',
  templateUrl: './edit-group-form.component.html',
  styleUrls: ['./edit-group-form.component.css']
})
export class EditGroupFormComponent implements OnInit {
  //dialogRef: any;

  constructor(private toastr: ToastrService, public dialogRef: MatDialogRef<EditGroupFormComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any, private router: Router, private fb: FormBuilder,private clientService:ClientManagementService) { }

    editGroupForm = this.fb.group({   
      clientPlanGroupId : ['', [Validators.required]],
      groupTypeId : ['', [Validators.required]],
      clientPlanId : ['', [Validators.required]],
      groupName : ['', [Validators.required]],
      groupNumber : ['', [Validators.required]],
      description : ['', [Validators.required]],
       effectiveDate :[moment(new Date()).format(), [Validators.required]],
       endDate : [moment(new Date()).format(), [Validators.required]],
       createdDate : [moment(new Date()).format(), [Validators.required]],		 
       lastModifiedDate :[moment(new Date()).format(), [Validators.required]],
      lastModifiedBy : 0,  
    createdBy:0
    })
    groupTypes:any
  ngOnInit(): void {
    this.getAllGroupTypes()
    this.clientService.selectedPlan.subscribe(value=>{
      this.editGroupForm.get("clientPlanId")?.setValue(value)
       console.log(value)
      })
      if (this.data.clientPlanId) {
        this.editGroupForm.patchValue(this.data);
      }
  }  
  onNoClick(): void {
    this.dialogRef.close();
  }

  getAllGroupTypes()
  {
    this.clientService.getAllGroupTypes()
    .subscribe(groupType => {
      this.groupTypes=groupType.result;
     // console.log(roles);
    })
  }
  get f(): { [key: string]: AbstractControl } {

    return this.editGroupForm.controls;

  }
  updateGroup()
  {
    
    this.editGroupForm.get("lastModifiedDate")?.setValue(moment(new Date()).format())
   if (!this.editGroupForm.valid) {
        return;
      }
  
      //this.trimFormValues(this.addUserForm);
      //this.submitted = true;
      var formData = this.editGroupForm.value;
      this.clientService.UpdateGroup(formData)
        .subscribe({
          next:
            (response: any) => {
              if (response.errorContent.statusCode == "200") {
                this.toastr.success('Data saved successfully');
                this.dialogRef.close(response.errorContent.statusCode);
              }
            },
          error: (e) => this.toastr.error(e.error.errorContent.message)
        });
  }

}
