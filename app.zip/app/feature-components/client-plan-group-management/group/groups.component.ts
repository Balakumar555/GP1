import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSelectionListChange } from '@angular/material/list';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/Services/auth.service';
import { UsersService } from 'src/app/Services/users.service';
import { ClientDetail } from 'src/app/shared/model/clientDetail';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { ClientManagementService } from '../client-management.service';
import { AddGroupsFormComponent } from './add-groups-form/add-groups-form.component';
import { EditGroupFormComponent } from './edit-group-form/edit-group-form.component';

@Component({
  selector: 'app-groups',
  templateUrl: './groups.component.html',
  styleUrls: ['./groups.component.css'],
  encapsulation: ViewEncapsulation.None

})
export class GroupsComponent implements OnInit {
  planId: any
  groups!: any[]
  clonedGroupsDetails!: any[]
  enableList: boolean = false;
  enableEdit: boolean = false;
  selectedGroup:any
  constructor(public dialog: MatDialog, private authService: AuthService, private route: ActivatedRoute, private userService: UsersService, private router: Router, private fb: FormBuilder, private clientService: ClientManagementService) { }

  ngOnInit(): void {
    this.clientService.selectedPlan.subscribe(value => {
      this.planId = value;
      if (this.planId > 0) {
        this.bindList(this.planId)
        this.enableList = true
        this.enableEdit=false
      }
      else {
        this.enableList = false
        this.groups = []
      }

    })
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.groups = filterValue.length > 0 ? this.clonedGroupsDetails.filter(value => value.groupName.toLowerCase().includes(filterValue))
      : this.clonedGroupsDetails

  }

  bindList(planId: any) {
    this.clientService.getAllGroupsByPlanId(planId).subscribe((data: any) => {
      this.clonedGroupsDetails = this.groups = data.result;
    })
  }
  selectionChanged(event: MatSelectionListChange): void {
    let selectedGroup = event.options.filter(o => o.selected).map(o => o.value);
    this.selectedGroup = selectedGroup[0]  
    this.enableEdit = true
  }
  addNewGroup() {
    const dialogRef = this.dialog.open(AddGroupsFormComponent, {
      data: {},
      width: '45%'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result == "200") {
        this.bindList(this.planId);
      }
    });
  }

  editGroup(obj: any) {
    const dialogRef = this.dialog.open(EditGroupFormComponent, {
      data: obj,
      width: '45%'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result == "200") {
        this.bindList(this.planId);  
        this.enableEdit=false        
      }
    });
  }
}
