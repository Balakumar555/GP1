import { Component, EventEmitter, Input, OnInit, Optional, Output, ViewChild, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/Services/auth.service';
import { UsersService } from 'src/app/Services/users.service';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { formatDate } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Inject } from '@angular/core';
import * as moment from 'moment';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatChipInputEvent } from '@angular/material/chips';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { FormControl } from '@angular/forms';
import { forkJoin, Observable } from 'rxjs';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { TooltipPosition } from '@angular/material/tooltip';
import { ClientManagementService } from '../../client-plan-group-management/client-management.service';
import { ClientDetail } from 'src/app/shared/model/clientDetail';
import { affiliationTypes } from 'src/app/shared/constants/affiliationTypes';
import { AffiliatedClient } from 'src/app/shared/model/affiliatedClient';
import { MatSelect } from '@angular/material/select';
import { MatOption } from '@angular/material/core';
//import { MatSelect } from '@angular/material/select';
//import { MatOption } from '@angular/material/core';




@Component({
  selector: 'app-edit-user-form',
  templateUrl: './edit-user-form.component.html',
  styleUrls: ['./edit-user-form.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class EditUserFormComponent implements OnInit {
  positionOptions: TooltipPosition[] = ['below'];
  position = new FormControl(this.positionOptions[0]);
  [x: string]: any;
   @ViewChild('select') select!: MatSelect ;
  addUser: boolean = false;
  excludeClient: AffiliatedClient[] = []
  includeClient: AffiliatedClient[] = []
  // @Output() eventChange = new EventEmitter<Event>();
  // @Input() title!: string;
  // onClick(event: Event) {
  //   this.eventChange.emit(event);
  // }

  separatorKeysCodes: number[] = [ENTER, COMMA];
  fruitCtrl = new FormControl('');
  filteredFruits!: Observable<string[]>;
  fruits: string[] = ['Lemon'];
  allFruits: string[] = ['Apple', 'Lemon', 'Lime', 'Orange', 'Strawberry'];
  allRoles: any[] = [];
  clients!: any[];
  affiliatedClients: AffiliatedClient[] = [];
  allAffiliationTypes: any[] = []
  selectedClients:AffiliatedClient[] = [];
  isClient = false
  isInternal = true
  // allSelected=false;
  editUserForm = this.fb.group({
    fname: ['', [Validators.required, Validators.maxLength(20)]],
    lname: ['', [Validators.required, Validators.maxLength(20)]],
    mname: ['', Validators.maxLength(20)],
    loginId: ['', [Validators.required, Validators.maxLength(25)]],
    affiliation: [,[Validators.required]],
    mobile: ['', [Validators.required, Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
    userInitial: ['', [Validators.required, Validators.maxLength(2)]],
    email: ['', [Validators.required, Validators.email, Validators.maxLength(50)]],
    custId: localStorage.getItem("customerId")!.toString(),
    userId: localStorage.getItem("userId")!.toString(),
    status: ['', [Validators.required]],
    usrEffectiveDate: [[Validators.required]],
    usrEndDate: [new Date(), [Validators.required]],
    internal: [],
    client: [],
    // mfaEnabled: [],
    // createdBy: [],
    // createdDate: [],
    // modifyby: [],
    // modifiedDate: [],
    roleId: ['', Validators.required],
    roleName: [''],
    clientIds: []
    // privileges:[''],
    // userPrivileges:[],
    // otp:[''],
    // access_token:['']
  });
  moment = moment;

  get f(): { [key: string]: AbstractControl } {

    return this.editUserForm.controls;

  }
  constructor(private toastr: ToastrService, public dialogRef: MatDialogRef<EditUserFormComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any, private userService: UsersService, private fb: FormBuilder, private sharedService: SharedDataService, private clientService: ClientManagementService) { }


  ngOnInit(): void {
    console.log(this.data);
    this.callAllApi().subscribe(responseList => {
      this.clients = responseList[0];
      this.clients.forEach(client => {
        this.affiliatedClients.push({ clientId: client.clientId, clientName: client.clientName })
      })
      this.allRoles = responseList[1].result;
      this.allAffiliationTypes = responseList[2].result;
      this.bindUserForm();
      this.bindAffiliatedClients(responseList[3].result)

    });
    // this.getClients();
    //  this.getCutomerRoles();
    //  this.getAffiliationTypes();   

  }

  bindUserForm() {
    if (this.data.userId) {
      this.editUserForm.setValue(this.data);
      let endDate!: any;
      endDate = moment(this.data.usrEndDate).format("MM/DD/yyyy");
      this.editUserForm.controls.usrEndDate.setValue(new Date(endDate));
    }
  }

  compareWithFn(item1:any,item2:any) {
    return item1 && item2 ? item1.clientId === item2.clientId : item1 === item2;
  }
  
  bindAffiliatedClients(affiliatedClients: AffiliatedClient[]) {
    if (this.data.affiliation == affiliationTypes.client) {
      this.isClient=true
      this.isInternal=false;
      this.editUserForm.controls.client.setValue(affiliatedClients as any)
      affiliatedClients.forEach(client=>{
        this.includeClient.push(client)
      })
    }
    else { 
      this.isClient=false
      this.isInternal=true;
      this.editUserForm.controls.internal.setValue(affiliatedClients as any) 
      affiliatedClients.forEach(client=>{
        this.excludeClient.push(client)
      })    
    }
  }
  getClients() {
    this.clientService.getClientsByCustomer().subscribe((data: ClientDetail[]) => {
      this.clients = data;
    })
  }

  callAllApi() {
    let activeClients = this.clientService.getClientsByCustomer()
    let customerRoles = this.userService.getCustomerRoles()
    let allAffiliationTypes = this.userService.getAllAffiliationTypes()
    let affiliatedUserClients = this.userService.getAffiliatedUserClient(this.data.userId)
    return forkJoin([activeClients, customerRoles, allAffiliationTypes, affiliatedUserClients])
  }

  addExcludeClient(client: any,selected: boolean) {
    if(selected && !this.excludeClient.includes(client))
    this.excludeClient.push(client)
    else
    this.excludeClient.splice(client,1)
  }

  removeExcludeClient(client: any) {

    for (let item = 0; item <= this.excludeClient.length; item++) {
      if (this.excludeClient[item].clientId === client.clientId) {
        this.excludeClient.splice(item, 1)
        break
      }
    }
    //const clients = this.excludeClient.values 
    this.editUserForm.get("internal")?.setValue(this.excludeClient as any)
  }

  addIncludeClient(client: any,selected: boolean) {
    if(selected && !this.includeClient.includes(client))
    this.includeClient.push(client)
    else
    this.includeClient.splice(client,1)
  }

  removeIncludeClient(client: any) {

    for (let item = 0; item <= this.includeClient.length; item++) {
      if (this.includeClient[item].clientId === client.clientId) {
        this.includeClient.splice(item, 1)
        break
      }
    }
    //const clients = this.excludeClient.values 
    this.editUserForm.get("client")?.setValue(this.includeClient as any)
  }

  getCutomerRoles() {
    this.userService.getCustomerRoles()
      .subscribe(roles => {
        this.allRoles = roles.result;
        console.log(roles);
      })
  }

  getAffiliationTypes() {
    this.userService.getAllAffiliationTypes().subscribe(affiliationType => {
      this.allAffiliationTypes = affiliationType.result;
      this.editUserForm.get("affiliation")?.setValue(affiliationTypes.internal as any)
    })
  }
  onAffiliationChange(affiliation: any) {
    if (affiliation == affiliationTypes.client) {
      this.isClient = true
      this.isInternal = false
      this.includeClient = []
      this.excludeClient = []
      this.editUserForm.get("internal")?.reset()
    }
    else {
      this.isClient = false
      this.isInternal = true
      this.excludeClient = []
      this.includeClient = []
      this.editUserForm.get("client")?.reset()
    }

  }
  public trimFormValues(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach((key) => {
      if (formGroup.controls[key].value && (key != "usrEffectiveDate" && key != "usrEndDate" && key != "client" && key != "internal"))
        formGroup.controls[key].setValue(formGroup.controls[key].value?.toString().trim())
    });
  }
  validateClientList()
  {
    if(this.isClient==true)
    {
      if(this.includeClient.length ==0)
      {
        this.editUserForm.get('client')?.setErrors({'atleastOneRequired': true})
      }
      else
      {
        this.editUserForm.get('client')?.setErrors(null)
      }
    }
    if(this.isInternal==true)
    {
      if(this.excludeClient.length == this.affiliatedClients.length)
      {
        this.editUserForm.get('internal')?.setErrors({'atleastOneSkip': true})
      }
      else
      {
        this.editUserForm.get('internal')?.setErrors(null)
      }
    }
  }
  editUser() {
    this.validateClientList()
    this.editUserForm.markAllAsTouched()
    let clientIds: any = []
    this.excludeClient.forEach(function (client) {
      clientIds.push(client.clientId)     
    })
    this.includeClient.forEach(function (client) {
      clientIds.push(client.clientId)      
    })
    if (!this.editUserForm.valid) {
      return;
    }
    this.editUserForm.get("clientIds")?.setValue(clientIds)
    this.trimFormValues(this.editUserForm);
    var formData = this.editUserForm.value;
    this.userService.SaveUser(formData)
      .subscribe({
        next:
          (response: any) => {
            if (response.errorContent.statusCode == "200") {
              this.toastr.success('Data saved successfully');
              this.dialogRef.close(response.errorContent.statusCode);
            }
          },
        error: (e) => this.toastr.error('Error while updating the user record')
      });
  }
  // toggleAllSelection() {
  //   this.allSelected=!this.allSelected
  //   if (this.allSelected) {
  //     this.select.options.forEach((item: MatOption) => item.select());
  //   } else {
  //     this.select.options.forEach((item: MatOption) => item.deselect());
  //   }
  // }
  onNoClick(): void {
    this.dialogRef.close();
  }
  // loadUser(userId:string)
  // {
  //   this.userService.loadUser(userId)
  //   .subscribe(
  //       (response: any)=>{ 
  //       if(response.errorContent.statusCode =="200")
  //       { 
  //         localStorage.setItem('EditedUserId',response.result.map((a: { userId: any; }) => a.userId))
  //        console.log(JSON.stringify(response.result));       
  //         this.editUserForm.setValue(response.result[0]);       
  //         let endDate!: any;             
  //        endDate = formatDate(response.result[0].usrEndDate, 'yyyy-MM-dd', 'en');       
  //        this.editUserForm.controls.usrEndDate.setValue(endDate); 
  //       }
  //       },
  //   ); 
  // }

  // resetForm()
  // {
  //   this.editUserForm.reset();
  // }









}
