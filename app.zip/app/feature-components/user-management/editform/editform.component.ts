import { Component, EventEmitter, Input, OnInit, Optional, Output, ViewChild, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/Services/auth.service';
import { UsersService } from 'src/app/Services/users.service';
import { AbstractControl, FormBuilder, Validators } from '@angular/forms';
import { formatDate } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {Inject} from '@angular/core';
import { AddUserFormComponent } from '../add-user-form/add-user-form.component';
interface Car {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-editform',
  templateUrl: './editform.component.html',
  styleUrls: ['./editform.component.css']
})
export class EditformComponent implements OnInit {

  addUser : boolean = false;
  @Output() eventChange = new EventEmitter<Event>();
  @Input() title!:string;
  onClick(event: Event) {
    this.eventChange.emit(event);
  }



  
  addUserForm = this.fb.group({    
    fname: ['',[Validators.required]],
    lname: ['',[Validators.required]],
   password:['',[Validators.required]],  
  mname:[''],
  loginId:['',[Validators.required]], 
  affiliation:['',[Validators.required]],
  mobile:['',[Validators.required]],
  userInitial:[''],
  email:['',[Validators.required]],
  custId:[0],
  userId:[0],
  status:[''],
  usrEffectiveDate:[],
  usrEndDate:[],
  mfaEnabled:[],
  createdBy:[],
  createdDate: [],
  modifyby:[],
  modifiedDate:[]
  });
  
  
  get f(): { [key: string]: AbstractControl } {

    return this.addUserForm.controls;

  }
  constructor(public dialogRef: MatDialogRef<EditformComponent>,
   @Optional() @Inject(MAT_DIALOG_DATA) public data: any,private userService: UsersService, private router :Router, private fb: FormBuilder) { }

  ngOnInit(): void {
    console.log(this.data);
    if(this.data.userId)
    this.addUserForm.setValue(this.data);
    //this.CustId= parseInt(localStorage.getItem("customerId")!) 
  }

  save()
  {
    var formData = this.addUserForm.value;
     this.userService.SaveUser(formData)
    .subscribe(
        (response: any)=>{ 
        if(response.errorContent.statusCode =="200")
        {
          //alert('Service call successful.')
        }
        },
    ); 
  }

  SaveUser(FName:string, MName:string, LName:string,LoginId:string, Pwd:string, DDActive:string,StDt:string,Affi:string,Phone:string,Initials:string,Email:string,EndDt:string)
  {
    var formData = this.addUserForm.value;
     this.userService.SaveUser(formData)
    .subscribe(
        (response: any)=>{ 
        if(response.errorContent.statusCode =="200")
        {
         // alert('Service call successful.')
        }
        },
    ); 
}
onNoClick(): void {
  this.dialogRef.close();
}
loadUser(userId:string)
{
  this.userService.loadUser(userId)
  .subscribe(
      (response: any)=>{ 
      if(response.errorContent.statusCode =="200")
      { 
        localStorage.setItem('EditedUserId',response.result.map((a: { userId: any; }) => a.userId))
       console.log(JSON.stringify(response.result));       
        this.addUserForm.setValue(response.result[0]);
        let stratDate!: any;
        let endDate!: any;
       stratDate = formatDate(response.result[0].usrEffectiveDate, 'yyyy-MM-dd', 'en');        
       endDate = formatDate(response.result[0].usrEndDate, 'yyyy-MM-dd', 'en');
       this.addUserForm.controls.usrEffectiveDate.setValue(stratDate);
       this.addUserForm.controls.usrEndDate.setValue(endDate); 
      }
      },
  ); 
}

resetForm()
{
  this.addUserForm.reset();
}

}
