import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { UserManagementComponent } from './user-management.component';
import { AddUserFormComponent } from './add-user-form/add-user-form.component';
import { EditUserFormComponent } from './edit-user-form/edit-user-form.component';
import { UsersService } from 'src/app/Services/users.service';
import { AuthGuard } from 'src/app/core/guards/auth.guard';
import { Roles } from 'src/app/shared/constants/role';
import { FormsModule } from '@angular/forms';
import { MaterialModule } from 'src/app/material.module';
//import { CoreModule } from 'src/app/core/core.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxMaskModule } from 'ngx-mask';
//import { NavigationComponent } from 'src/app//feature-components/navigation/navigation.component';
const routes: Routes = [
  {
    path: '', component:UserManagementComponent, 
   children:[
    {path: 'adduserform', component:AddUserFormComponent},
    {path: 'edituserform', component:EditUserFormComponent}
  ], 
  canActivate:[AuthGuard],resolve: { userPermissions: UsersService },data: {roles: [Roles.Administrator,Roles.Management]}
    
  }
];
@NgModule({
  declarations: [UserManagementComponent,
   AddUserFormComponent,EditUserFormComponent],
  imports: [
    RouterModule.forChild(routes),
    NgxMaskModule.forChild(),
    CommonModule,
    FormsModule,
    MaterialModule,
    //CoreModule,
    SharedModule,
    ReactiveFormsModule,
  ],
  providers:[[{ provide: MAT_DIALOG_DATA, useValue: {} }],
  [{provide: MatDialogRef,  useValue: {}}],]
})

export class UserManagementModule { }
