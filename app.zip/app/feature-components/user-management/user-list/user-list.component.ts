import { Component, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  getData() {
    throw new Error('Method not implemented.');
  }

  constructor() { }

  ngOnInit(): void {
  }
  hidden = true;

  @Input()
  set event(event: Event) {
    if (event) {
      this.toggle();
    }
  }

  toggle() {
    this.hidden = !this.hidden;
  }
}

