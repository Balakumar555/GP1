
import { AfterViewInit, Component, OnInit, ViewChild,ViewEncapsulation } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UsersService } from 'src/app/Services/users.service';
import { AddUserFormComponent } from './add-user-form/add-user-form.component';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';
import { EditUserFormComponent } from './edit-user-form/edit-user-form.component';
import { AuthService } from 'src/app/Services/auth.service';
import { Roles } from 'src/app/shared/constants/role';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { CONFIG } from 'src/app/shared/config';
import { Permissions } from 'src/app/shared/constants/permissions';
import { User } from 'src/app/shared/model/user';


@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.css'],
  encapsulation: ViewEncapsulation.None

})

export class UserManagementComponent implements AfterViewInit {
  

  @ViewChild('usrTbSort') usrTbSort = new MatSort();  
  addUser: boolean = false;
  editForm: boolean = false;
  dataLoad: boolean = false;
  _userId: string = "";
  userData: any;
  event: Event | undefined;
  show = false;
  moment = moment;
  role: number = 0;
  userRole:string=''
  displayedColumns: string[] = ['loginId', 'fName', 'lName', 'role','createdDate', 'endDate', 'status', 'actions'];
  pageOptions: number[] = [5, 10, 20];
  @ViewChild(MatPaginator, { static: false }) paginator!: MatPaginator;
  userPermissions: any = {};
  
  constructor(
    public dialog: MatDialog,private authService:AuthService, private route: ActivatedRoute ,private userService: UsersService, private router: Router, private fb: FormBuilder, private sharedService:SharedDataService
  ) {

  }
  ngAfterViewInit(): void {

  }

  ngOnInit(): void {
    this.userPermissions = this.route.snapshot.data['userPermissions'];
    let data =  this.route.snapshot.data['userPermissions'];
    // if(data != null) {
    //     data.userPermissions.subscribe((response: any) => {
    //       this.userPermissions = response.result;
    //     });
    //     data.userRole.subscribe((response: any) => {
    //       this.userRole = response.result;
    //     });
    // }
    this.bindGrid();
    //const currentUser = this.authService.currentUserValue;
   // this.role =this.sharedService.getRole();
  }
  
canUserHasAddPermission()
{  
  
  return this.sharedService.hasPermission(Permissions.CreateNewUser, this.userPermissions.result)  
 
}

canUserHasEditPermission()
{    
  return this.sharedService.hasPermission(Permissions.EditExistingUser, this.userPermissions.result)  
 
}
  editUser(obj: any) {    
    const dialogRef = this.dialog.open(EditUserFormComponent, {
      data: obj
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result == "200") {
        this.bindGrid();       
      }
    });
    
  }
  addNewUser() {
    const dialogRef = this.dialog.open(AddUserFormComponent, {
      data: {}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result == "200") {
        this.bindGrid();        
      }
    });
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.userData.filter = filterValue.trim().toLowerCase();

    if (this.userData.paginator) {
      this.userData.paginator.firstPage();
    }
  }
  bindGrid() {
    this.userService.getUsersByCustomer().subscribe(data => {
      this.userData = new MatTableDataSource<User>(data);
      this.userData.sort = this.usrTbSort;
      this.userData.paginator = this.paginator;
      this.dataLoad = true;

    })
  }

}







