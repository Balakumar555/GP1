import { Component, ElementRef, EventEmitter, Input, OnInit, Optional, Output, ViewChild, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/Services/auth.service';
import { UsersService } from 'src/app/Services/users.service';
import { AbstractControl, AbstractControlOptions, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { formatDate } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Inject } from '@angular/core';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';
import { NoWhitespaceDirective } from 'src/app/shared/directives/no-whitespace.directive';
import {COMMA, ENTER} from '@angular/cdk/keycodes';

import {FormControl} from '@angular/forms';
import {MatAutocomplete, MatAutocompleteSelectedEvent} from '@angular/material/autocomplete';
import {MatChipInputEvent} from '@angular/material/chips';
import {forkJoin, Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { TooltipPosition } from '@angular/material/tooltip';
import { AffiliatedClient } from 'src/app/shared/model/affiliatedClient';
import { affiliationTypes } from 'src/app/shared/constants/affiliationTypes';
import { ClientManagementService } from '../../client-plan-group-management/client-management.service';
import { ModelDialogsService } from 'src/app/shared/model-dialog/model-dialog.service';


@Component({
  selector: 'app-add-user-form',
  templateUrl: './add-user-form.component.html',
  styleUrls: ['./add-user-form.component.css'],
  encapsulation: ViewEncapsulation.None
})


export class AddUserFormComponent implements OnInit {

  separatorKeysCodes: number[] = [ENTER, COMMA];
  fruitCtrl = new FormControl('');
  filteredFruits: Observable<string[]>;
  fruits: string[] = [];
  allFruits: string[] = ['Client 1', 'Client 2', 'Client 3', 'Client 4', 'Client 5'];
  positionOptions: TooltipPosition[] = ['below'];
  position = new FormControl(this.positionOptions[0]);

  [x: string]: any;

  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;
  filteredRoles!: Observable<any[]>;
  roles:any[]=[];
  allRoles:any[]=[];
  clients!: any[];  
  affiliatedClients: AffiliatedClient[] = [];
  allAffiliationTypes: any[] = []
  selectedClients:AffiliatedClient[] = [];
  isClient = false
  isInternal = true
  excludeClient: AffiliatedClient[] = []
  includeClient: AffiliatedClient[] = []
  @ViewChild('fruitInput') fruitInput: ElementRef<HTMLInputElement> | undefined;

  

  addUserForm = this.fb.group({
    fname: ['', [Validators.required, Validators.maxLength(20)]],
    lname: ['', [Validators.required, Validators.maxLength(20)]],
    password: ['', [Validators.required]],
    mname: ['', Validators.maxLength(20)],
    loginId: ['', [Validators.required, Validators.maxLength(25)]],
    affiliation: [, [Validators.required, Validators.maxLength(10)]],
    mobile: ['', [Validators.required, Validators.maxLength(10), Validators.pattern('^[0-9]+$')]],
    userInitial: ['', [Validators.required, Validators.maxLength(2)]],
    email: ['', [Validators.required, Validators.email, Validators.maxLength(50)]],
    //custId:[0],
    userId: [''],
    status: ['A', [Validators.required]],
    UsrEffDate: [new Date(), [Validators.required]],
    usrEndDate: [new Date("1/1/9999"), [Validators.required]],
    mfaEnabled: [],
    createdBy: [],
    createdDate: [],
    modifyby: [],
    modifiedDate: [],
    internal: [],
    client: [],
    clientIds: [''],
    CustId: localStorage.getItem("customerId")!,
    ConfirmPwd: ['',[Validators.required]],
    roleId:['', Validators.required]
  }, {validator:this.passwordConfirming} as AbstractControlOptions);
  submitted = false;
  pwdHide = true;
  confirmPwdHide = true;
  get f(): { [key: string]: AbstractControl } {
  return this.addUserForm.controls;

  }
  get ConfirmPwd() { return this.addUserForm.get('ConfirmPwd'); }
  constructor(private dialogService: ModelDialogsService,private toastr: ToastrService, public dialogRef: MatDialogRef<AddUserFormComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data: any, private userService: UsersService, private router: Router, private fb: FormBuilder,private sharedService:SharedDataService,private clientService: ClientManagementService) { 
      this.filteredFruits = this.fruitCtrl.valueChanges.pipe(
        startWith(null),
        map((fruit: string | null) => (fruit ? this._filter(fruit) : this.allFruits.slice())),
      );
    }

    add(event: MatChipInputEvent): void {
      const value = (event.value || '').trim();
  
      // Add our fruit
      if (value) {
        this.fruits.push(value);
      }
  
      // Clear the input value
      event.chipInput!.clear();
      this.fruitCtrl.setValue(null);
    }
  
    remove(fruit: string): void {
      const index = this.fruits.indexOf(fruit);
  
      if (index >= 0) {
        this.fruits.splice(index, 1);
      }
    }
  
    selected(event: MatAutocompleteSelectedEvent): void {
      this.fruits.push(event.option.viewValue);
      this.fruitInput!.nativeElement.value = '';
      this.fruitCtrl.setValue(null);
    }
  
    private _filter(value: string): string[] {
      const filterValue = value.toLowerCase();
  
      return this.allFruits.filter(fruit => fruit.toLowerCase().includes(filterValue));
    }
  ngOnInit(): void {

    this.callAllApi().subscribe(responseList => {
      this.clients = responseList[0];
      this.clients.forEach(client => {
        this.affiliatedClients.push({ clientId: client.clientId, clientName: client.clientName })
      })
      this.allRoles = responseList[1].result;
      this.allAffiliationTypes = responseList[2].result;
      if (this.data.userId)
      this.addUserForm.setValue(this.data);
      this.addUserForm.get("affiliation")?.setValue(affiliationTypes.internal as any)

    });   
    
  } 

  public trimFormValues(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach((key) => {
      if (formGroup.controls[key].value && (key != "affiliation" && key != "UsrEffDate" && key != "usrEndDate"  && key != "roleId" && key != "CustId" && key != "client" && key != "internal"&& key != "clientIds"))
        formGroup.controls[key].setValue(formGroup.controls[key].value.trim())
    });
  }
  passwordConfirming(c: AbstractControl) {
    return  c.value.password  ===  c.value.ConfirmPwd ?  c.get('ConfirmPwd')!.setErrors(null) :c.get('ConfirmPwd')!.setErrors({'mismatch': true});
     
  }
  onNoClick(): void {
    this.dialogRef.close();
  }

  getCutomerRoles()
  {
    this.userService.getCustomerRoles()
    .subscribe(roles => {
      this.allRoles=roles.result;
      // console.log(roles);
    })
  }

  validateClientList()
  {
    if(this.isClient==true)
    {
      if(this.includeClient.length ==0)
      {
        this.addUserForm.get('client')?.setErrors({'atleastOneRequired': true})
      }
      else
      {
        this.addUserForm.get('client')?.setErrors(null)
      }
    }
    if(this.isInternal==true)
    {
      if(this.excludeClient.length == this.affiliatedClients.length)
      {
        this.addUserForm.get('internal')?.setErrors({'atleastOneSkip': true})
      }
      else
      {
        this.addUserForm.get('internal')?.setErrors(null)
      }
    }
  }
  saveUser() {
    
   this.validateClientList()
   this.addUserForm.markAllAsTouched()
    let clientIds: any = []
    this.excludeClient.forEach(function (client) {
      clientIds.push(client.clientId)     
    })
    this.includeClient.forEach(function (client) {
      clientIds.push(client.clientId)      
    })
    if (!this.addUserForm.valid) {
      return;
    }
    this.addUserForm.get("clientIds")?.setValue(clientIds.toString())
    this.trimFormValues(this.addUserForm);    
    this.submitted = true;
    var formData = this.addUserForm.value;
    this.userService.addUser(formData)
      .subscribe({
        next:
          (response: any) => {
            if (response.errorContent.statusCode == "200") {
              this.toastr.success('Data saved successfully');
              this.dialogRef.close(response.errorContent.statusCode);
            }
          },
        error: (e) => this.toastr.error(e.error.errorContent.message)
      });
  }
  resetForm() {
    this.addUserForm.reset();
  }
  // addExcludeClient(client: any) {
  //   this.excludeClient.push(client)
  // }
  addExcludeClient(client: any,selected: boolean) {
    if(selected && !this.excludeClient.includes(client))
    this.excludeClient.push(client)
    else
    this.excludeClient.splice(client,1)
  }

  removeExcludeClient(client: any) {

    for (let item = 0; item <= this.excludeClient.length; item++) {
      if (this.excludeClient[item].clientId === client.clientId) {
        this.excludeClient.splice(item, 1)
        break
      }
    }
    //const clients = this.excludeClient.values 
    this.addUserForm.get("internal")?.setValue(this.excludeClient as any)
  }

  addIncludeClient(client: any,selected: boolean) {
    if(selected && !this.includeClient.includes(client))
    this.includeClient.push(client)
    else
    this.includeClient.splice(client,1)
  }

  removeIncludeClient(client: any) {

    for (let item = 0; item <= this.includeClient.length; item++) {
      if (this.includeClient[item].clientId === client.clientId) {
        this.includeClient.splice(item, 1)
        break
      }
    }
    //const clients = this.excludeClient.values 
    this.addUserForm.get("client")?.setValue(this.includeClient as any)
  }

  onAffiliationChange(affiliation: any) {
    if (affiliation == affiliationTypes.client) {
      this.isClient = true
      this.isInternal = false
      this.includeClient = []
      this.excludeClient = []
      this.addUserForm.get("internal")?.reset()
    }
    else {
      this.isClient = false
      this.isInternal = true
      this.excludeClient = []
      this.includeClient = []
      this.addUserForm.get("client")?.reset()
    }

  }

  getAffiliationTypes() {
    this.userService.getAllAffiliationTypes().subscribe(affiliationType => {
      this.allAffiliationTypes = affiliationType.result;
      this.addUserForm.get("affiliation")?.setValue(affiliationTypes.internal as any)
    })
  } 

  callAllApi() {
    let activeClients = this.clientService.getClientsByCustomer()
    let customerRoles = this.userService.getCustomerRoles()
    let allAffiliationTypes = this.userService.getAllAffiliationTypes()  
    return forkJoin([activeClients, customerRoles, allAffiliationTypes])
  }

}




