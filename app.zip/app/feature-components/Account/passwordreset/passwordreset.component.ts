import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/Services/auth.service';
import { Router } from '@angular/router';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-passwordreset',
  templateUrl: './passwordreset.component.html',
  styleUrls: ['./passwordreset.component.css']
})
export class PasswordresetComponent implements OnInit {

  
  constructor(private toastr:ToastrService,private authService: AuthService, private router :Router,private fb: FormBuilder)  {
      
  }

 

  resetPwdForm = this.fb.group({    
    EmailId: ['', [Validators.required, Validators.email, Validators.maxLength(50)]],     
  })
  ngOnInit(): void {    

  }

  sendResetPasswordNotification()
  {
    if (this.resetPwdForm.invalid) {
      return;
    }
    let emailId = this.resetPwdForm.controls['EmailId'].value!
    //alert('in Component');
     this.authService.sendResetPasswordNotification(emailId)
    .subscribe(
        (response: any)=>{   
          if(response.errorContent.statusCode =="200")
        {
          this.toastr.success('Password Reset Instructions have been sent to the registered e-mail address provided')
          this.router.navigate(['/login'])
          
        }
        }
    );     
}


}
