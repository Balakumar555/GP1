import { HttpResponse } from '@angular/common/http';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AuthService } from 'src/app/Services/auth.service';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  encapsulation: ViewEncapsulation.None


})
export class LoginComponent implements OnInit {
  currentRoute: string = ""


  get isLogInPage(): boolean {
    return (this.currentRoute == "" || this.currentRoute.toLowerCase().indexOf("login") >= 0)
  }
  constructor(private toastr: ToastrService, private authService: AuthService, private router: Router, private fb: FormBuilder

  )


  {

    this.router.events.pipe(

      filter((event: any) => event instanceof NavigationEnd)
    )

      .subscribe((ev: any) => {

        var currentUrl: string = ev.url;

        if (currentUrl.indexOf("?") >= 0) {

          this.currentRoute = currentUrl.substring(0, currentUrl.indexOf("?"));
          //alert(this.currentRoute);
        }
        else {
          this.currentRoute = currentUrl;
        }
      })
  }

  loginForm = this.fb.group({

    loginId: ['', [Validators.required]],

    password: ['', [Validators.required]]

  })


  Pwd: any = "";
  LoginId: any = "";
  LoginResp = [];

  ngOnInit() {



  }

  LoginReq: any;
  parsedJson: any;
  test: any;

  getLogin() {
    this.LoginId = this.loginForm.controls.loginId.value;
    this.Pwd = this.loginForm.controls.password.value
    this.authService.getLogin(this.LoginId, this.Pwd)
      .subscribe({
        next:
          (response: any) => {
            if (response.errorContent.statusCode == "200") {
              localStorage.setItem('otp', response.result.otp)
              localStorage.setItem('emailId', response.result.email)
              localStorage.setItem('access_token', response.result.access_token)
              localStorage.setItem('refresh_token', response.result.refresh_token)
              localStorage.setItem('expires_in', response.result.expires_in)
              localStorage.setItem('emailOtpStatus', response.result.emailOtpStatus)
              localStorage.setItem('isExpired', response.result.isExpired)
              localStorage.setItem('fName', response.result.fname)
              localStorage.setItem('lName', response.result.lname)
              localStorage.setItem('customerId', response.result.custId)
              localStorage.setItem('userId', response.result.userId)
              localStorage.setItem('loginId', response.result.loginId)
              this.loginForm.reset();
              if (response.result.isExpired != "Y") {
                //this.router.navigate(['/user-management']);
                this.router.navigate(['/']);
              }
              else {
                this.router.navigate(['/login/pwdexp'])
              }
            }
          },
        error: (e) => this.toastr.error(e.error.errorContent.message)
      });
    return true;
  }


}



