import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/Services/auth.service';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';

@Component({
  selector: 'app-newpassword',
  templateUrl: './newpassword.component.html',
  styleUrls: ['./newpassword.component.css']
})
export class NewpasswordComponent implements OnInit {

  constructor(private toastr:ToastrService,private authService: AuthService, private router :Router,private fb: FormBuilder) { }
  newPwdForm = this.fb.group({    
    NewPwd: ['',[Validators.required]],
    ConfirmPwd: ['',[Validators.required]]
  }, {validator:this.passwordConfirming})
  
 passwordConfirming(c: AbstractControl) {
  return  c.value.NewPwd  ===  c.value.ConfirmPwd ?  c.get('ConfirmPwd')!.setErrors(null) :c.get('ConfirmPwd')!.setErrors({'mismatch': true});
   
}
  ngOnInit() {


let URL = window.location.href

//alert(URL);

const searchParams = new URLSearchParams(URL)
let params: string[] = [];
searchParams.forEach((value, key) => {
  params.push(value);
})

let lid= params[0];
let tkn= params[1];

localStorage.setItem('lid',lid)
localStorage.setItem('access_token',tkn)

  }
  get ConfirmPwd() { return this.newPwdForm.get('ConfirmPwd'); }
  resetPwd()
  {
    if (this.newPwdForm.invalid) {
      return ;
    }
    const LoginId =localStorage.getItem("lid")!
    const Token = localStorage.getItem("access_token")!
    var customerId = localStorage.getItem("customerId");
    //alert(NewPwd)
    //alert(LoginId)
    //alert(Token)

    this.authService.resetPwd(this.newPwdForm.controls['NewPwd'].value!, LoginId, Token,customerId)
    .subscribe({
        next:(response: any)=>{   
      // alert('inside component upon successful Service Call')
        if(response.errorContent.statusCode =="200")
        {                  
        //alert('New Password has been updated. Please log in with new credentials.')
         //this.router.navigate(['/user-management']); 
         this.toastr.success('Password reset successfully')
        this.router.navigate(['/login']); 
        }
        },
        error:(e) => this.toastr.error(e.error.errorContent.message)
      }
    );
}

checkPasswords() { // here we have the 'passwords' group
  
  //return this.NewPwd === this.ConfirmPwd ? true : false
}
}
