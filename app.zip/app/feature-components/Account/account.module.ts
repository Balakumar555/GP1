import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MaterialModule } from 'src/app/material.module';
import { ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { NewpasswordComponent } from './newpassword/newpassword.component';
import { PasswordExpirationComponent } from './password-expiration/password-expiration.component';
import { PasswordresetComponent } from './passwordreset/passwordreset.component';
import { HeaderComponent} from 'src/app/feature-components/Grievance-Lib/header/header.component'
import { SharedModule } from 'src/app/shared/shared.module';
//import { NavigationComponent } from 'src/app//feature-components/navigation/navigation.component';
const routes: Routes = [
  // {path:'', component:LoginComponent, children:
  // [
  //   {path: 'passwordreset',pathMatch: 'full', component:PasswordresetComponent}
  // ]} ,
  {path:'login',pathMatch: 'full',component:LoginComponent},
  {path:'newpwd',pathMatch: 'full',component:NewpasswordComponent},
  {path:'pwdexp',pathMatch: 'full',component:PasswordExpirationComponent},
 {path: 'passwordreset', pathMatch: 'full',component:PasswordresetComponent},
 {path: '**',component: LoginComponent }     
   
];
@NgModule({
  declarations: [LoginComponent,NewpasswordComponent,PasswordExpirationComponent,PasswordresetComponent,HeaderComponent],
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    FormsModule,
    MaterialModule,
    //CoreModule,
    SharedModule,
    ReactiveFormsModule,
  ],
  providers:[]
})

export class AccountManagementModule { }
