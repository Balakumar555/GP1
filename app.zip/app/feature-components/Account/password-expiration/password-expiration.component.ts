import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/Services/auth.service';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';

@Component({
  selector: 'app-password-expiration',
  templateUrl: './password-expiration.component.html',
  styleUrls: ['./password-expiration.component.css']
})

export class PasswordExpirationComponent implements OnInit {

  constructor(private toastr: ToastrService, private authService: AuthService, private router: Router, private fb: FormBuilder) { }


  EmailId: string = "";
  CustId: string = "";
  UserId: string = "";
  LoginId: string = "";
  Token: string = "";


  ngOnInit(): void {
  }

  expirationPwdForm = this.fb.group({
    OldPwd: ['', [Validators.required]],
    NewPwd: ['', [Validators.required]],
    ConfirmPwd: ['', [Validators.required]]
  }, { validator: this.passwordConfirming })

  passwordConfirming(c: AbstractControl) {
    return c.value.NewPwd === c.value.ConfirmPwd ? c.get('ConfirmPwd')!.setErrors(null) : c.get('ConfirmPwd')!.setErrors({ 'mismatch': true });

  }

  get ConfirmPwd() { return this.expirationPwdForm.get('ConfirmPwd'); }

  updatePwd() {
    if (this.expirationPwdForm.invalid) {
      return;
    }
    this.EmailId = localStorage.getItem("emailId")!;
    this.Token = localStorage.getItem("access_token")!;
    this.CustId = localStorage.getItem("customerId")!;
    this.UserId = localStorage.getItem("userId")!;
    let newPwd = this.expirationPwdForm.controls['NewPwd'].value!
    let oldPwd = this.expirationPwdForm.controls['OldPwd'].value!
    this.authService.updatePwd(Number(this.CustId), Number(this.UserId), oldPwd, newPwd, this.EmailId, this.Token!)
      .subscribe({
        next:
          (response: any) => {

            if (response.errorContent.statusCode == "200") {
              this.toastr.success('Password Changed Successfully')
              this.router.navigate(['/login'])
            }
          },
        error: (e) => this.toastr.error(e.error.errorContent.message)
      });
  }


}
