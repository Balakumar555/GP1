import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PasswordExpirationComponent } from './password-expiration.component';

describe('PasswordExpirationComponent', () => {
  let component: PasswordExpirationComponent;
  let fixture: ComponentFixture<PasswordExpirationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PasswordExpirationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PasswordExpirationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
