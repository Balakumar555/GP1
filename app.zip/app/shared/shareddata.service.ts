import { Subject, BehaviorSubject, of, Observable } from 'rxjs';
import { CONFIG } from '../shared/config';
import { ControlConfig, FormGroup } from '@angular/forms';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ActivatedRouteSnapshot } from '@angular/router';
import * as moment from 'moment';
import { takeUntil, shareReplay, tap, map, share, publishReplay, refCount } from 'rxjs/operators';
import { User } from './model/user';
import { MemberDetail } from './model/memberDetail';



@Injectable({
    providedIn: 'root',
  })
export class SharedDataService {
    private config:{ [key: string]: {'custId':'','fname':'','lname':'','privileges':[],'access_token':'','userId':'','loginId':'','email':'','roleId':0,'userPrivileges':string [], 'userRoleData':User[], 'memberDetail':MemberDetail} } = {};
    private data = {};      
    public allUserRoles: any;     
    

    constructor(private http: HttpClient) {
       
    }

    
    clearOption(...option: any[]) {
        option.forEach(o => delete this.config[o]);
    }
    setOption(option: any, value: any) {
        this.config[option] = value;  
       // this.data[option] = value;      
        
    }
    getConfig() {
        return this.config;
    }

    getCurrentUser() {
     return this.config[CONFIG.setOption.loggedUser];        
    }

    getUserRoleData()
    {
        return this.config['userRoleData'].userRoleData 
    }
    getCurrentUserPrivileges(): string [] {

        return this.config['loggedUser'].userPrivileges;
    }

    getCurrentUserFirstName() :string {
        return this.config['loggedUser'].fname;
    }

    getCurrentUserLasttName() :string {
        return this.config['loggedUser'].lname;
    }

    getLoginId() {
        return this.config['loggedUser'].loginId;
        ;
    }

    getAccessToken() {
        if(this.getCurrentUser())
         return this.config['loggedUser'].access_token;
         else return '';
    }

    getEmail() {
        return this.config['loggedUser'].email;
        ;
    }

    getCustomerId() {
        return this.config['loggedUser'].custId;
        ;
    }

    getUserId() {
        return this.config['loggedUser'].userId;
        ;
    }

    getRole() :number {
        return this.config['loggedUser'].roleId;
        ;
    }

    getMemberDetail():any
    {
        return this.config['memberDetail'];
    }

    getEligibilityMemberId():any
    {
        return this.config['eligibilityMemberId'];
    }
 getUserPrivileges()
{
       return this.http.get('/GetUserPrivilegesByUserId');
       
}
getUserRole() {
       return this.http.get('/GetRolesByUserId');
      
    }

    hasPermission(privilege:string, privileges:any) : boolean
    {
        if(privileges.indexOf(privilege)===-1)
        {
          return false;
        }
        return true;
    }
      

    encodeURI(uri: string) {
        uri = uri.replace('&', 'ampersand');
        uri = uri.replace('.', 'dotchar');
        uri = uri.replace('+', 'pluschar');
        uri = uri.replace('*', 'starchar');
        uri = uri.replace('-', 'hyphenchar');
        uri = uri.replace('<', 'ltchar');
        uri = uri.replace('>', 'gtchar');
        uri = uri.replace(':', 'colonchar');
        return uri;
    }

   

    // getFormattedDate(date: Date) {
    //     return moment(new Date(date)).format(CONFIG.Dateformat);
    // }

    

   

    getTitleCase(title: string) {
        return title.replace(/\w\S*/g, function (txt) { return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase(); });
    }

  

   

    // GetLoggedUserRole() {
    //    // const delegateDsid = this.getDelegateUserDsid();
    //     const dsId = this.getConfig()[CONFIG.setOption.userId].dsId;

    //    // const userDsid = delegateDsid ? delegateDsid : dsId;
    //     const params = { dsId: userDsid };

    //     // const params = { dsId: this.getConfig()[CONFIG.setOption.loggedUser].dsId };
    //     const loggedUserRole = this.http.get('/api/admin/UserRole', { params: params });

    //     return loggedUserRole;
    // }
  

}
