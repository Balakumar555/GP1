import { ViewContainerRef, Injectable } from '@angular/core';
import { ToastaService, ToastOptions, ToastData } from 'ngx-toasta';
//import { ToastrService } from 'ngx-toastr';

@Injectable()
export class ToastrService {
    constructor(private toastr: ToastaService) {
    }

    setViewComponent(vcr: ViewContainerRef) {
        // this.toastr.setRootViewContainerRef(vcr);
    }

    success(message: string, header?: string, options?: any) {

        const toastOptions: ToastOptions  = {
            title: header || "",
            msg: message,
            showClose: true,
            timeout: 8000,
            theme: 'default',
            onAdd: (toast: ToastData) => {
                const toastid = toast.id;
                if (toastid > 1) {
                    this.toastr.clear(toastid - 1);
                }
            },
            onRemove: function (toast: ToastData) {
                const toastid = toast.id;
            }
        };

        this.toastr.success(toastOptions);
    }

    error(message: string) {
        this.toastr.error(message);
    }

    info(message: string) {
        this.toastr.info(message);
    }
}
