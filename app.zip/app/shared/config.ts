//export let BASEURL : 'http://localhost:61215'   // 'http://goazr1app254d.godevazure1.kpmg.com:8090/Services'

export const CONFIG = {
    baseUrls: {
        // Session Creation 
        sessionUrl: "/api/session",
        // Prefilter Creation 
        prefilterUrl: "/api/prefilter"

    },
    role: {
        Administrator : "Administrator",
        Management:"Management",
        CaseWorker:"Case Worker",
        Triage:"Triage"
    },
    permissions: {
        CreateNewUser: "Create new user",
        EditExistingUser: "Edit existing user",
        CreateNewCase: "Create new case",
        EnterBasicCaseDetails: "Enter basic case details during case creation",
        ManuallyAddMember: "Manually add a member",
        AssignCaseWorker: "Assign case worker",
        EnterCaseNotes: "Enter case notes",
        ClinicalComponentDecision: "Clinical component decision",
        EliminationOfGrievanceOrInquiry: "Elimination of a grievance or inquiry",
        InquiryDetermination: "Inquiry determination",
        EnterCaseWorkerFields: "Enter case worker fields",
        ExtendCase: "Extend a case",
        OralNotificationProcess: "Oral notification process",
        CreateWrittenNotification: "Create written notification",
        DismissCase: "Dismiss a case",
        WithdrawCase: "Withdraw a case",
        CloseCase: "Close a case",
        AccessDashboards: "Access to dashboards",
        RunStandardReportingOptions: "Run standard reporting options",
        CreateNonStandardReporting: "Create non-standard reporting",
        DefineTATRules: "Define turnaround time (TAT) rules",
        DefineLetterTtemplates: "Define letter templates",
        DefineLetterRules: "Define letter rules",
        DefineClient: "Define Client",
        DefineGroup: "Define Group"
    },
    
    setOption: {
        otp: "otp",
        emailId: "emailId",
        accessToken: "accessToken",
        refreshToken: "refreshToken",
        expiresIn: "expiresIn",
        emailOtpStatus: "emailOtpStatus",
        isExpired: "isExpired",
        fName: "fName",
        lName: "lName",
        customerId: "customerId",
        userId: "userId",
        loginId: "loginId",
        loggedUser:"loggedUser"
       
    }
    
    
}
