import { NgModule } from '@angular/core';
import { LoadingDialogComponent } from './loading/loading-dialog/loading-dialog.component';
import { ErrorDialogComponent } from './errors/error-dialog/error-dialog.component';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ErrorDialogService } from './errors/error-dialog.service';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { LoadingDialogService } from './loading/loading-dialog.service';
import { MaterialModule } from '../material.module';
//import { ToastaModule } from 'ngx-toasta';
import { ToastrService } from './Toastr/toastr.service';
import { NoWhitespaceDirective } from './directives/no-whitespace.directive';
import { TextCountDirective } from './directives/text-count.directive';
import { InvalidControlScrollDirective } from './directives/app-invalid-control-scroll.directive';
import { BlurClearGarbageValue } from './directives/blur-clear-garbage-value.directive';
import { DndDirective } from './directives/dragndrop.directive';
import { UploadComponent } from './upload/upload.component';
import { ProgressComponent } from './progress/progress.component';
import { ShortenPipe } from './shorten.pipe';


const sharedComponents = [LoadingDialogComponent, ErrorDialogComponent];

@NgModule({
  declarations: [...sharedComponents, NoWhitespaceDirective, TextCountDirective, InvalidControlScrollDirective, BlurClearGarbageValue, DndDirective, UploadComponent, ProgressComponent, ShortenPipe],
  imports: [CommonModule, RouterModule, MaterialModule],// ,ToastrModule.forRoot() ToastaModule.forRoot()
  exports: [...sharedComponents,NoWhitespaceDirective,BlurClearGarbageValue,InvalidControlScrollDirective,TextCountDirective, DndDirective, UploadComponent, ProgressComponent, ShortenPipe],
  providers: [ErrorDialogService, LoadingDialogService, ToastrService],
  entryComponents: [...sharedComponents],
})
export class SharedModule {}
