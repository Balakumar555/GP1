//  export class FileUploadModal {       
 
//      constructor(public ID: number, public FileName: string, public file: File,
//          public Extension: string, public DocType: string,public CreatedBy: number) {
//         this.ID = ID;
//          this.FileName = FileName;
//         this.file=file;
//         this.Extension=Extension;
//         this.DocType=DocType;
//         this.CreatedBy=CreatedBy;
//       }
// }


// export interface FileUploadModal {       
//   DocId: number;
//   file: File      
// }

 export class FileUploadModal {
     public progress: number;       
 
     constructor(public ID: number, public FileName: string,public OnlyFileName: string, public file: File|null,public uploadedBy:string,public uploadedDate:string) {
        this.ID = ID;
        this.FileName = FileName;
        this.file=file;
        this.progress=0;
        this.uploadedBy=uploadedBy;
        this.uploadedDate=uploadedDate;
        this.OnlyFileName=OnlyFileName;
      }
}