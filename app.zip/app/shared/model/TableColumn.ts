//declare module namespace {
    export interface TableColumn {       
        ColumnHeader:string;
        ColumnValue:string;
        IsVisible:boolean;
        IsSearchable:boolean;      
    }
//}
