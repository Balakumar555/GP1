

    export interface PlanInfo {
        altMemberId: string;
        memberNumber: string;
        MBI: string;
        relationCode: string;       
        personNumber: string;
        groupNumber: string;
        eligibilityEndDate: Date;
        eligibilityEffectiveDate: Date;
        cardHolderContractNumber: string;
        cmsContractNumber: string;
        clientId: string;
        planId: string;
    }

    export interface MemberInfo {
        firstName: string;
        middleName: string;
        lastName: string;
        dateOfBirth: Date;
        gender: string;
        addressLine1: string;
        addressLine2: string;
        state: string;
        city: string;
        zip: string;
        homePhone: string;
        workPhone: string;
        fax: string;
        cellPhone: string;
        communicationPrefrence: string;
        email: string;
        languagePrefrence: string;
    }

    export interface AorInfo {
        aorFirstName: string;
        aorMiddleName?: any;
        aorLastName: string;
        aorEmail?: any;
        memberSignatureDate: Date;
        apointeeSignatureDate: Date;
        aorCity: string;
        aorAddressLine1: string;
        aorAddressLine2: string;
        aorPhone: string;
        aorZip?: any;
        aorState: string;
        aorRelationship: string;
        formReceived?: any;
        aorFormReceivedDate: Date;
        aorFormReceivedTime?: any;
        representativeType: string;
        aorGroupName: string;
    }

    export interface MemberDetail {
        planInfo: PlanInfo;
        memberInfo: MemberInfo;
        isAor: boolean;
        createdDate: Date;
        lastModifiedBy?: any;
        lastModifiedDate?: any;
        aorForm: AorInfo;
        customerId: string;
        createdBy: string;
    }



