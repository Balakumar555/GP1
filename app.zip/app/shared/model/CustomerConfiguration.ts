//declare module namespace {
    export interface CustomerConfiguration {       
        key: number;
        value: string;        
    }
//}

