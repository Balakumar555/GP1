//declare module namespace {
    export interface LookUp {       
        key: number;
        value: string;        
    }
//}
