export interface ClientDetail {
    clientId: string,
    clientTypeId: string,
    customerId: string,
    clientName: string,
    clientCode: string,
    description: string,
    effectiveDate: Date,
    endDate: Date,
    createdDate: Date,
    createdBy: string,
    lastModifiedBy:string,
    lastModifiedDate:Date,
    status:string
}