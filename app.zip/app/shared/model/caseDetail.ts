
export interface AorInfo {
    aorFirstName: string;
    aorMiddleName?: any;
    aorLastName: string;
    aorEmail?: any;
    memberSignatureDate: Date;
    apointeeSignatureDate: Date;
    aorCity: string;
    aorAddressLine1: string;
    aorAddressLine2?: any;
    aorPhone?: any;
    aorZip: string;
    aorState: string;
    aorRelationship: string;
    aorFormReceivedDate?: any;
    aorFormReceivedTime: string;
    stateName:string;

}
export interface CaseDetail {
    firstName: string;
    middleName: string;
    lastName: string;
    dateOfBirth: Date;
    gender: string;
    addressLine1: string;
    addressLine2: string;
    state: string;
    city: string;
    zip: string;
    homePhone: string;
    workPhone: string;
    fax: string;
    cellPhone: string;
    communicationPrefrence: string;
    email: string;
    status: string;
    incidentDate: Date;
    dueDate: Date;
    receivedDate: Date;
    method: string;
    requestor: string;
    requestType: string;
    category: string;
    subCategory: string;
    source: string;
    urgency: string;
    highPriority: boolean;
    extension: boolean;
    partType: string;
    complianceCase: boolean;
    goodCause: boolean;
    description: string;
    isAOR: boolean;
    firstTier: string;
    aorForm: AorInfo;
    CustId: string;
    receivedTime: string;
    caseId: string;
    categoryName: string;
    planName: string;
    planType:string;
    stateName:string;
    caseDetailId:string;
}
export interface CaseSummary {
    requestor: string;
    categoryName: string;
    receivedDate: string;
    planName: string;
    method: string;
    requestType: string;
    receivedTime: string;
    status: string;
    description: string;
    urgency: string;
}
export interface MemberSummary {
    member: string;
    memberId: string;
    mbi: string;
    phone: string;
    homePhone:string;
    workPhone:string;
    address: string;
    city: string;
    state: string;
    dob: string;
    planType: string;
    communicationPrefrence: string;
}
export interface AORSummary {
    aorName: string;    
    phone: string;
    address: string;
    city: string;
    state: string;   
    email: string;
    homePhone:string;
    workPhone:string;
}
export interface CaseStatus {
    CaseStatusId: any;
    Status: string;

}
export interface NMIInfo{
    nmiReason:string,
    nmiDescription:string    
}

export interface NMIOutcome{   
    outcomeDescription:string,
    outcome:string
}

export interface Category {
    CategoryId: any;
    CategoryName: string;

}

export interface CommentsElements {
    ID: number;
    comment: string;
}


export interface VerbalNotification {
    description: any;
}