//declare module namespace {
    export interface User {
        userId: number;
        custId: number;
        loginId: string;
        fname: string;
        lname: string;
        usrEffectiveDate: Date;
        usrEndDate: Date;
        email: string;
        mobile: string;
        mfaEnabled: boolean;       
        modifyby: number;
        modifiedDate: Date;
        mname: string;
        status: string;      
        userInitial: string;
        roleId: number; 
        access_token?: any;
        refresh_token?: any;       
        isExpired?: any;
        roleName:string;
        affiliation:number;
        name:string;
        internal:any[]
        client:any[];
        clientIds:any[];
        //userTypeId:number
    }
//}

