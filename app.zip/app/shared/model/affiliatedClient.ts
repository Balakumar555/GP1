export interface AffiliatedClient {
    clientId: string,    
    clientName: string
    
}