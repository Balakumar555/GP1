//import { MatDialogRef } from '@angular/material';
import { Component, HostListener } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
    selector: 'model-dialog',
    templateUrl: './model-dialog.component.html'

})
export class ModelDialog {

    public title: string | undefined;
    public message: object | undefined;
    public cancelButton: boolean =true;
    public buttons: Array<String> =[];

    constructor(public dialogRef: MatDialogRef<ModelDialog>) {
        //this.buttons = ["OK", "Cancel"];
    }

    @HostListener('document:keyup', ['$event']) public handleKeyup(evt: KeyboardEvent) {

        if (evt.keyCode === 8) {
            evt.preventDefault();
            evt.stopPropagation();
        }
    }
}
