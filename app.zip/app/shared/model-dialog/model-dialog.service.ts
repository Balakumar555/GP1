
import { ModelDialog } from './model-dialog.component';
import { Observable } from 'rxjs';
//import { MatDialogRef, MatDialog } from '@angular/material';
import { Injectable } from '@angular/core';
import { DomSanitizer } from "@angular/platform-browser";
import { MatDialog, MatDialogRef } from '@angular/material/dialog';

@Injectable({
    providedIn: 'root'
  })
export class ModelDialogsService {

    constructor(private dialog: MatDialog, private sanitized: DomSanitizer) { }

    public confirm(title: string, message: string, cancelButton: boolean = true, disableClose: boolean = true, buttons: Array<string> = ["OK", "Cancel"]): Observable<boolean> {

        let dialogRef: MatDialogRef<ModelDialog>;

        const msg = this.sanitized.bypassSecurityTrustHtml(message);

        dialogRef = this.dialog.open(ModelDialog);

        dialogRef.componentInstance.title = title;
        dialogRef.componentInstance.message = msg;
        dialogRef.componentInstance.cancelButton = cancelButton;
        dialogRef.componentInstance.buttons = buttons;
        dialogRef.disableClose = disableClose;

        // dialogRef.hasBackdrop = true;

        return dialogRef.afterClosed();
    }


}
