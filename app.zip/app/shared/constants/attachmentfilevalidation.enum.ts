
export enum attachmentfilevalidation {
  isDefault = 0,
  isFilenotsupported = 1,
  isFilesizeexceed = 2,
  isUploadsuccess = 3
}



export enum fileType {
  png='png',
  jgp='jgp',
  jpeg='jpeg',
  tif='tiff',
  pdf='pdf',
  xlsx='xlsx'

}

export enum contentType {
  png='image/png',
  jgp='image/jgp',
  jpeg='image/jpeg',
  tif='image/tiff',
  pdf='application/pdf'

}

export enum LookUpNames {
  AttachmentFileTypes='AttachmentFileTypes',
  AttachmentSize='AttachmentSize'
}