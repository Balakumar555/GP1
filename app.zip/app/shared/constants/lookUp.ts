export enum LookUps {
    AORRelationShip="AORRelationShip",
    CaseStatus="Case Status",
	Category="Category",
	CommunicationPreference="Communication Preference",
	Gender="Gender",
	LanguagePreference="Language Preference",
	RelationCode="Relation Code",
	RepresentativeType="RepresentativeType",
    RequestType ="Request Type",
    Source ="Source",
    State ="State",
	SubCategory="Sub Category",
	BenefitDetermination="Benefit Determination",
	MethodReceived="Method Received",
	Requestor="Requestor"
}
