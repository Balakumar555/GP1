export enum Permissions
{
CreateNewUser="Create new user",
EditExistingUser="Edit existing user",
CreateNewCase="Create new case",
EnterBasicCaseDetails="Enter basic case details during case creation",
ManuallyAddMember="Manually add a member",
AssignCaseWorker="Assign case worker",
EnterCaseNotes="Enter case notes",
ClinicalComponentDecision="Clinical component decision",
EliminationOfGrievanceOrInquiry="Elimination of a grievance or inquiry",
InquiryDetermination="Inquiry determination" ,
EnterCaseWorkerFields="Enter case worker fields",
ExtendCase="Extend a case",
OralNotificationProcess="Oral notification process",
CreateWrittenNotification="Create written notification",
DismissCase="Dismiss a case",
WithdrawCase="Withdraw a case",
CloseCase="Close a case",
AccessDashboards="Access to dashboards",
RunStandardReportingOptions="Run standard reporting options",
CreateNonStandardReporting="Create non-standard reporting",
DefineTATRules="Define turnaround time (TAT) rules",
DefineLetterTtemplates="Define letter templates",
DefineLetterRules="Define letter rules",
DefineClient="Define Client",
DefineGroup="Define Group"

}