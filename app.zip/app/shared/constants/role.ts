export enum Roles {
    Administrator = 1,
    Management,
    CaseWorker,
    Triage
}
export enum Affilation {
    Internal = 1,
    External
}