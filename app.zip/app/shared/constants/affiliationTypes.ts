
export enum affiliationTypes {
  client = 1,
  internal = 2,
  
}
