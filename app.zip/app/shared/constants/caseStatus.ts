
export enum caseStatus {
Pending=1,
Open=2,
Resolved=3,
Withdrawn=4,
Dismissed=5,
NeedMoreInformation=6,
ResolveNMI=7,
TakeExtension=8
    
  }