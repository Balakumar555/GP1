import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpEvent,HttpParams } from '@angular/common/http';
import { BehaviorSubject, map, Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class FileUpload {

files: any[] = [];


constructor(private httpClient: HttpClient) {


 }
UploadAttachement(file: File, caseId:any): Observable<HttpEvent<any>> {
  const formData: FormData = new FormData();
  formData.append('file', file);
  formData.append('docType', 'Case Doc');
  formData.append('extension',file.type);
  formData.append('createdBy', localStorage.getItem("userId")!);
  formData.append('caseId', caseId);
  formData.append('fileName', file.name);

  
    return this.httpClient.post<any>('/UploadDocument', formData);
}

GetDocumentDetails(docId: any): Observable<HttpEvent<any>> {
    return this.httpClient.get<any>('/GetDocumentDetails?docId='+docId).pipe(
      map((response: any) => response.result)
    );
  }


deleteAttachment(docId:any) : Observable<any>
{
  const params = new HttpParams()
    .set('docId', docId)

  return this.httpClient.post<any>('/DeleteDocument', '', { params: params });

}

GetCaseAttachments(caseId: any): Observable<HttpEvent<any>> { 

  const params = new HttpParams()
    .set('CaseId', caseId)
  return this.httpClient.get('/GetCaseAttachments',{params:params}).pipe(
    map((response: any) => response.result)
  );
}

}



