import { ConfirmDialogComponent } from './../confirm-dialog/confirm-dialog.component';
import { Component, Input } from '@angular/core';
import { AddCaseDetailsComponent } from 'src/app/feature-components/case-management/add-case-details/add-case-details.component';
//import { MatDialogRef, MatDialog, MatSnackBar, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { formatDate } from '@angular/common';
import { Output, EventEmitter } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { FileUpload } from './file-upload.service';
import { CommonService } from 'src/app/shared/services/Common.service';
import { attachmentfilevalidation } from '../constants/attachmentfilevalidation.enum';
import { fileType } from '../constants/attachmentfilevalidation.enum';
import { contentType } from '../constants/attachmentfilevalidation.enum';
import { LookUpNames } from '../constants/attachmentfilevalidation.enum';
import { ModelDialogsService } from 'src/app/shared/model-dialog/model-dialog.service';
import { CustomerConfiguration } from 'src/app/shared/model/CustomerConfiguration';
import { FileUploadModal } from 'src/app/shared/model/FileUploadModal';
import { BehaviorSubject, map, Observable } from 'rxjs';
import b64toBlob from 'b64-to-blob';
import { SharedDataService } from 'src/app/shared/shareddata.service';
import { version } from 'moment';
import { ToastrService } from 'src/app/shared/Toastr/toastr.service';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css'],
})
export class UploadComponent {

  isProgressHide:any=true;
  fileModal: FileUploadModal;
  files: FileUploadModal[] = [];
  docId: any;
  CustomerConfig  !: any[];
  fileValidation: number = 0;
  attachmentfilevalidation = attachmentfilevalidation;
  customerId = localStorage.getItem("customerId")!;
  userId = localStorage.getItem("userId")!;
  attachmentFileTypes!: any[];
  fleSize!: number;
  @Input() caseId: any
  @Input() enableUpload: boolean=false
  constructor(public dialog: MatDialog, private uploadService: FileUpload, private commonService: CommonService,private toastr: ToastrService) {
    this.fileModal = new FileUploadModal(0, '','', null,'','');
  }
  ngOnInit(): void {
    this.getCustomerConfiguration();
    this.getCaseAtachmentsByCaseId();

  }
  getCustomerConfiguration() {
    // if (customerId === null)
    //   customerId = 1;
    this.commonService.getCustomerConfiguration().subscribe((data: CustomerConfiguration[]) => {
      this.CustomerConfig = data;
      const attachmentTypes = this.CustomerConfig.filter((obj) => {
        return obj.key === LookUpNames.AttachmentFileTypes;
      });
      const fileSizeInfo = this.CustomerConfig.filter((obj) => {
        return obj.key === LookUpNames.AttachmentSize;
      });
      this.attachmentFileTypes = attachmentTypes[0].value.split(',');
      this.fleSize = fileSizeInfo[0].value;

    })
  }

  /** on file drop handler **/

  onFileDropped($event: any[]): void {
    this.isProgressHide=false;
    this.prepareFilesList($event);
  }

  /**
   * handle file from browsing
   */
  fileBrowseHandler(data: any) {
    this.isProgressHide=false;
    this.prepareFilesList(data.target.files);

  }


  deleteFile(index: number) {
    this.fileValidation = 0;
    this.files.splice(index, 1);
  }

  /**
   * Simulate the upload process
   */
  uploadFilesPanel(index: number) {
    setTimeout(() => {
      if (index === this.files.length) {
        return;
      } else {
        const progressInterval = setInterval(() => {
          if (this.files[index].progress === 100) {
            clearInterval(progressInterval);
            this.fileValidation = attachmentfilevalidation.isUploadsuccess;
            this.uploadFilesPanel(index + 1);
          } else {
            this.files[index].progress += 5;
          }
        }, 200);
      }
    }, 1000);
  }

  /**
   * Convert Files list to normal array list
   * @param files (Files List)
   */
  prepareFilesList(files: Array<any>) {
    for (const item of files) {
      // console.log('File: '+item);
      //const values='text/plain,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/pdf,image/png,image/tiff,image/jpeg'

      var attachmentFileTypesarray = this.attachmentFileTypes;
      if (this.attachmentFileTypes.indexOf(item.type) > -1) {
        if (item.size > (this.fleSize) * 1024) {
          this.fileValidation = attachmentfilevalidation.isFilesizeexceed;
          item.progress = 0;
        } else {

          this.docId = 0;
          item.progress = 0;
          let uploadedBy = localStorage.getItem('fName')! + ' ' + localStorage.getItem('lName');
          let uploadedDate = formatDate(new Date(), 'MM/dd/yyyy', 'en-US');
          this.fileModal = new FileUploadModal(0, item.name,item.name.split('.',2)[0], item,uploadedBy,uploadedDate);
          this.files.push(this.fileModal);
          this.fileValidation = attachmentfilevalidation.isDefault;
          this.uploadFilesPanel(0);
          this.uploadAttachment(item);

        }
      } else {
        this.fileValidation = 1;
        item.progress = -1;
        return;
      }
    }
  }


  /**
   * format bytes
   * @param bytes (File size in bytes)
   * @param decimals (Decimals point)
   */
  formatBytes(bytes: any, decimals: any) {
    if (bytes === 0) {
      return '0 Bytes';
    }
    const k = 1024;
    const dm = decimals <= 0 ? 0 : decimals || 2;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }
  getCaseAtachmentsByCaseId() {
    this.isProgressHide=true;
    this.uploadService.GetCaseAttachments(this.caseId).subscribe({
      next:
        (response: any) => {
          if (response) {

            response.forEach((element:any)=>{

              var fcontentType = '';
              if (element.extension == fileType.png || element.extension == fileType.jgp || element.extension == fileType.tif || element.extension == fileType.jpeg)
                fcontentType = 'image/' + response[0].extension;
              else
                fcontentType = contentType.pdf;

           // let blob=new Blob(element.doc_FILE,{type: fcontentType}) ;
            var blob = b64toBlob(element.doC_FILE, fcontentType);
            let file=new File([blob] ,element.fileName ,{type: fcontentType,lastModified:new Date().getDate()});
            this.fileModal = new FileUploadModal(element.docId,element.fileName,element.fileName.split('.',2)[0], file,element.uploadedBy,element.uploadedDate);
            this.fileModal.progress=100;
            this.files.push(this.fileModal);

            //this.uploadFilesPanel(0);

            });
          }
        }
    });
  }

  previewAttachment(file: any) {

    const fileAttachment = this.files.filter((obj) => {
      return obj.FileName === file.name;
    });

    this.uploadService.GetDocumentDetails(fileAttachment[0].ID).subscribe({
      next:
        (response: any) => {
          var fcontentType = '';
          if (response[0].extension == fileType.png || response[0].extension == fileType.jgp || response[0].extension == fileType.tif || response[0].extension == fileType.jpeg)
            fcontentType = 'image/' + response[0].extension;
          else
            fcontentType = contentType.pdf;
          var blob = b64toBlob(response[0].docFile, fcontentType);
          var blobUrl = URL.createObjectURL(blob);
          window.open(blobUrl);
        }
    });
  }

  uploadAttachment(file: any) {
    this.uploadService.UploadAttachement(file, this.caseId).subscribe({
      next:
        (response: any) => {
          if (response.errorContent.statusCode == "200") {
            this.docId = response.result;

            this.files = this.files.map((item) => {
              if (item.FileName === file.name) {
                item.ID = response.result;
              }
              return item;
            })
          }
        }
    });


  }

  deleteAttachment(file: any) {
    const confirmDialog = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: 'Delete Attachment',
        message: 'Are you sure you want to delete this attachment? '
      }
    });
    confirmDialog.afterClosed().subscribe(result => {
      if (result === true) {

        const fileAttachment = this.files.filter((obj) => {
          return obj.FileName === file.name;
        });

        this.uploadService.deleteAttachment(fileAttachment[0].ID).subscribe({
          next:
            (response: any) => {
              if (response.errorContent.statusCode == "200") {

                let index = this.files.findIndex(e => e.ID === fileAttachment[0].ID);
                if (index !== -1) {
                  this.files.splice(index, 1);
                }
                this.toastr.success('Attachment deleted successfully');
              }
            }
        });

      }
    });

  }
}
