
import { CONFIG } from '../config';
import { ControlConfig, FormGroup } from '@angular/forms';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ActivatedRouteSnapshot } from '@angular/router';
import { BehaviorSubject, map, Observable } from 'rxjs';
import { CustomerConfiguration } from 'src/app/shared/model/CustomerConfiguration';


@Injectable({
  providedIn: 'root'
})
export class CommonService {
    
  constructor(private httpClient: HttpClient) {
       
  }

  getCustomerConfiguration() {
    return this.httpClient.get<any>("/GetCustomerConfiguration")
    .pipe(map((response: any) => {
      const result = Object.keys(response.result).map(x => ({
          key: response.result[x].key,
          value: response.result[x].value
      })) as CustomerConfiguration[]
      return result;
    }));
  }
  
}
