
import { CONFIG } from '../../shared/config';
import { ControlConfig, FormGroup } from '@angular/forms';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ActivatedRouteSnapshot } from '@angular/router';
import { BehaviorSubject, map, Observable } from 'rxjs';
import { LookUp } from 'src/app/shared/model/LookUp';


@Injectable({
  providedIn: 'root'
})
export class LookUpService {
    
  constructor(private httpClient: HttpClient) {
       
  }

  geLookUpsByLookUpName(lookUpName: any) {
    return this.httpClient.get<any>("/GetLookUpValues?lookUpName=" + lookUpName)
    .pipe(map((response: any) => {
      const result = Object.keys(response.result).map(x => ({
          key: response.result[x].key,
          value: response.result[x].value
      })) as LookUp[]
      return result;
    }));
  }
  
}
