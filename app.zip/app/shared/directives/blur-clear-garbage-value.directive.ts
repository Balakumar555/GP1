import { Renderer2, ElementRef, Directive, Output, EventEmitter } from "@angular/core";
import { NgControl } from "@angular/forms";

@Directive({
    selector: '[onBlurClearGarbage]',
    
})

export class BlurClearGarbageValue {
    @Output() eventEmitterBlur = new EventEmitter();

    constructor(private elementRef: ElementRef, private renderer: Renderer2, private control: NgControl) {
    }

    ngOnInit(): void {
        if ((this.elementRef.nativeElement.attributes["formcontrolname"] && this.elementRef.nativeElement.attributes["formcontrolname"].value) || (this.elementRef.nativeElement.attributes["formControlTargetName"] && this.elementRef.nativeElement.attributes["formControlTargetName"].value))
            this.renderer.listen(this.elementRef.nativeElement, 'blur', (event: any) => {
                let formControl = this.control.control;
                let tagName;
                if (event.relatedTarget)
                    tagName = event.relatedTarget && event.relatedTarget.hasAttributes("tagName") ? event.relatedTarget.tagName : "";
                //for support in ie
                else {                    
                    let currentOption = document.querySelectorAll(":focus");
                    for (var k = 0; k < currentOption.length; k++) {
                        if (currentOption[k].nodeName == "mat-OPTION" || currentOption[k].nodeName =="BODY") {
                            tagName = "mat-OPTION";
                            break;
                        }
                    }
                }

                if (!(formControl!.value instanceof Object) && tagName != "mat-OPTION") {
                    formControl!.setValue('');
                    this.eventEmitterBlur.emit(true);
                }

            });
    }

}