import { BlurClearGarbageValueDirective } from './blur-clear-garbage-value.directive';

describe('BlurClearGarbageValueDirective', () => {
  it('should create an instance', () => {
    const directive = new BlurClearGarbageValueDirective();
    expect(directive).toBeTruthy();
  });
});
