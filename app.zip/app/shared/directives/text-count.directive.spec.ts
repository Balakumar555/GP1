import { TextCountDirective } from './text-count.directive';

describe('TextCountDirective', () => {
  it('should create an instance', () => {
    const directive = new TextCountDirective();
    expect(directive).toBeTruthy();
  });
});
